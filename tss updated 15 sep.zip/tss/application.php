<?php include 'incl/header.php'; ?>

    <main class="page__wrap">

        <main>
        <!-- <canvas id="canvas"> </canvas> -->

        <div class="page-banner-wrapper marketing-page-banner">

<div class="container-md">
<div class="page-banner-inner">
<div class="page-banner-title">
        <div class="banner-title-inner">
        <h2>Mobile <span class="tg-lineare">Application</span> <br> <span class="tg-lineare-reverse">Development</span> <span>Company. </span></h2>
        <p>Our experienced app developers create modern, high end apps that put your business right in front of your audience's hands.  </p>
            <!-- <a href="#" class="theme-btn">Start Your Project</a> -->

            <!-- <a href="#" class="theme-btn">
  <div class="btn-circle border-primary" >
    <div class="btn-circle border-primary">
    Start Your Project
    </div>  
  </div>
</a> -->

            <div class="anim-cirlce xl-hide">
            <svg viewBox="0 0 100 100" width="100" height="100">
                <defs>
                    <path id="circle" d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"/>
                </defs>
                <text>
                    <textPath xlink:href="#circle">
                    We Create Fast websites
                    </textPath>
                </text>
                </svg>
            </div><!-- /.anim-cirlce -->
       
        </div>
</div><!-- /.page-banner-title -->
</div><!-- /.page-banner-inner -->
</div><!-- /.container-md -->

<span class="site-page-title">Mobile Application</span>
</div><!-- /.page-banner-wrapper -->

<div class="web-design-process section-space">
        <div class="container-md">
            <div class="web-design-porcess-inner">
                <div class="process-col">
                    <img src="assets/icons/project.svg" alt="">
                    <p>Apps concept <br> & roadmap</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/prototyping.svg" alt="">
                    <p>App design <br> & prototyping</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/development.svg" alt="">
                    <p>Apps development <br> process</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/testing.svg" alt="">
                    <p>User testing of <br> the app and fixes</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/app-launch.svg" alt="">
                    <p>App launch <br> & support</p>
                </div>
               
            </div><!-- /.web-design-porcess-inner -->
        </div><!-- /.container-md -->
    </div><!-- /.web-design-process -->



    <div class="web-types-section mobile-app">
        <div class="container-lg">
            <div class="web-types-section-inner">
                <div class="container-md">
                <div class="section-pod-title text-center">
                    <h4>Best app developers in UK</h4>
                    <p>We consider ourselves as the top app developers in UK because have a passion to develope and code beautiful apps. We work with all types of business that are in need of their business app and development and unlike other app development companies we give value to our client and their needs.</p>
                </div>
                </div>
                <div class="type-pods-wrpper section-space">
                <div class="type-pod">
                    <div class="type-pod-hover">
                    <div class="type-pod-inner">
                    <div class="type-col col-left">
                        <div class="section-pod-title">
                        <h4>Native Mobile</h4>
                        <p>Native app development is created and optimised for a specific platform, resulting in higher performance, and more security.</p>
                        </div>

                    </div>

                    <div class="type-col col-right">
                    <img src="assets/icons/native.svg" alt="">
                    </div>
                </div><!-- /.type-pod-inner -->
                    </div><!-- /.type-pod-hover -->
                </div><!-- /.type-pod -->
                <div class="type-pod">
                    <div class="type-pod-hover">
                    <div class="type-pod-inner">
                    <div class="type-col col-left">
                        <div class="section-pod-title">
                        <h4>Hybrid Mobile Apps</h4>
                        <p>Native app development is created and optimised for a specific platform, resulting in higher performance, and more security.</p>
                        </div>

                    </div>

                    <div class="type-col col-right">
                    <img src="assets/icons/hybrid.svg" alt="">
                    </div>
                </div><!-- /.type-pod-inner -->
                    </div><!-- /.type-pod-hover -->
                </div><!-- /.type-pod -->
                <div class="type-pod">
                    <div class="type-pod-hover">
                    <div class="type-pod-inner">
                    <div class="type-col col-left">
                        <div class="section-pod-title">
                        <h4>Web Apps</h4>
                        <p>Native app development is created and optimised for a specific platform, resulting in higher performance, and more security.</p>
                        </div>

                    </div>

                    <div class="type-col col-right">
                    <img src="assets/icons/web-apps.svg" alt="">
                    </div>
                </div><!-- /.type-pod-inner -->
                    </div><!-- /.type-pod-hover -->
                </div><!-- /.type-pod -->
         
   
           
          
        
                </div><!-- /.type-pods-wrpper -->
            </div><!-- /.web-types-section-inner -->
        </div><!-- /.container-lg -->
    </div><!-- /.web-types-section -->

    <div class="seo-services-detail-section">
        <div class="container-md">
            <div class="seo-services-detail-inner">
            <div class="section-pod-title text-center">
                        <h4>What we do for you?</h4>
                        <p>SEO is not straightforward and not an easy process. It's takes time to rank a website on top of Google searches. We use agile SEO techniques to rank websites and what we do is amazing. SEO need regular work to stay on top of your competition, and every website needs a digital marketing strategy; otherwise, it will fall behind and not generate any business. We use industry-leading tools for reporting and daily optimization. Our specialists monitor the campaign's performance every day and make changes to the strategy wherever required.</p>
                        </div>

                <div class="seo-services-cols">
                    <div class="seo-services-cols-inner">
                        <div class="svc-col">
                        <img src="assets/icons/travel-app.svg" alt="">
                        <p>Travel & Booking <br> Apps</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/delivery-app.svg" alt="">
                        <p>Food Delivery <br> Apps</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/realestate-app.svg" alt="">
                        <p>Real Estate <br> Apps</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/taxi-app.svg" alt="">
                        <p>Taxi Apps</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/trading-app.svg" alt="">
                        <p>Forex Trading <br> Apps</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/ecommerce-app.svg" alt="">
                        <p>eCommerce <br> Apps</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/educational-app.svg" alt="">
                        <p>Learning& <br> Education Apps</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/health-app.svg" alt="">
                        <p>Health & <br> Wellness Apps</p>
                        </div>
                    </div><!-- /.seo-services-cols-inner -->
                </div><!-- /.seo-services-cols -->
            </div><!-- /.seo-services-detail-inner -->
        </div><!-- /.container-md -->
    </div><!-- /.seo-services-detail-section -->




        <div class="testimonial-section section-space">
            <div class="container-lg">
                <div class="testimonial-section-inner">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="usre-reviews-col col-left">
                            <div class="section-title">
                            <h4>Our Consistant 5 Star Reviews</h4>
                            </div><!-- /.section-title -->
                            <div class="reviews-content">
                                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Alias sequi optio maxime! Hic aut possimus temporibus delectus accusantium ratione voluptatibus modi error, corporis, tenetur et molestiae. Obcaecati veritatis voluptate omnis.</p>
                            </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="usre-reviews-col col-right">
                            <div class="swiper">

                                <div class="swiper-wrapper">

                                    <div class="swiper-slide">
                                        <div class="review-wrap">
                                        <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                               <div class="swiper-nav-icons">
                                        <div class="swiper-button-prev icon-arrow-left swiper-nav"></div>
                                        <div class="swiper-button-next icon-arrow-right swiper-nav"></div>
                               </div><!-- /.swiper-nav-icons -->

                        </div><!--/.swiper-->

                            </div>
                        </div>
                    </div>
                </div><!-- /.testimonial-section-inner -->
            </div><!-- /.container-lg -->
        </div><!-- /.testimonial-section -->


   

        </main>

    </main><!--/.page__wrap-->


    <!-- <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br> -->

<?php include 'incl/footer.php'; ?>

