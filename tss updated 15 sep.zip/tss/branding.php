<?php include 'incl/header.php'; ?>

    <main class="page__wrap">

        <main>
        <!-- <canvas id="canvas"> </canvas> -->

        <div class="page-banner-wrapper webdesign-page-banner">

<div class="container-md">
<div class="page-banner-inner">
<div class="page-banner-title">
        <div class="banner-title-inner">
        <h2>Creative <span class="tg-lineare">Design</span> <br> <span>Agency London. </span></h2>
        <p>Great design means great online presence. People buy what they see so if you want to sell more then give your brand a strong online identity.</p>
            <!-- <a href="#" class="theme-btn">Start Your Project</a> -->

            <!-- <a href="#" class="theme-btn">
  <div class="btn-circle border-primary" >
    <div class="btn-circle border-primary">
    Start Your Project
    </div>  
  </div>
</a> -->

            <div class="anim-cirlce xl-hide">
            <svg viewBox="0 0 100 100" width="100" height="100">
                <defs>
                    <path id="circle" d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"/>
                </defs>
                <text>
                    <textPath xlink:href="#circle">
                    We Create Fast websites
                    </textPath>
                </text>
                </svg>
            </div><!-- /.anim-cirlce -->
       
        </div>
</div><!-- /.page-banner-title -->
</div><!-- /.page-banner-inner -->
</div><!-- /.container-md -->

<span class="site-page-title">BRANDING&nbsp& &nbspUI-&nbspUX&nbspDESIGN</span>
</div><!-- /.page-banner-wrapper -->

    <div class="web-design-process section-space">
        <div class="container-md">
            <div class="web-design-porcess-inner">
                <div class="process-col">
                    <img src="assets/icons/project.svg" alt="">
                    <p>Design Briefs <br> & Meetings</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/prototyping.svg" alt="">
                    <p>Sketching & <br> Prototyping</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/development.svg" alt="">
                    <p>Design <br> Presentations</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/testing.svg" alt="">
                    <p>Changes & <br> Revisions</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/deliver.svg" alt="">
                    <p>Delivery & <br> Impleme tation</p>
                </div>
               
            </div><!-- /.web-design-porcess-inner -->
        </div><!-- /.container-md -->
    </div><!-- /.web-design-process -->


    <div class="seo-services-detail-section branding-details">
        <div class="container-md">
            <div class="seo-services-detail-inner">
            <div class="section-pod-title text-center">
                        <h4>How a branding & UI experts can help?</h4>
                        <p>At Web Buds, we deliver great brand experiences and designs to some of the industry leaders in tech, finance, retail and professional sectors. From business branding to rebuilding websites and designs our deep understanding, experience and market research means we can dedicate our creative energy in producing creative designs and deliver distinctive designing solutions.</p>
                        </div>

              
            </div><!-- /.seo-services-detail-inner -->
        </div><!-- /.container-md -->
    </div><!-- /.seo-services-detail-section -->


    <div class="seo-services-detail-section branding-details">
        <div class="container-md">
            <div class="seo-services-detail-inner">
            <div class="section-pod-title text-center">
                        <h4>What we do for you?</h4>
                        <p>SEO is not straightforward and not an easy process. It's takes time to rank a website on top of Google searches. We use agile SEO techniques to rank websites and what we do is amazing. SEO need regular work to stay on top of your competition, and every website needs a digital marketing strategy; otherwise, it will fall behind and not generate any business. We use industry-leading tools for reporting and daily optimization. Our specialists monitor the campaign's performance every day and make changes to the strategy wherever required.</p>
                        </div>

                <div class="seo-services-cols">
                    <div class="seo-services-cols-inner">
                        <div class="svc-col">
                        <img src="assets/icons/uiux.svg" alt="">
                        <p>UI/UX Design</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/brand-identity.svg" alt="">
                        <p>Logos & <br> Brand Identy</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/development.svg" alt="">
                        <p>Website Design</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/app.svg" alt="">
                        <p>Mobile Apps <br> Design</p>
                        </div>
                    </div><!-- /.seo-services-cols-inner -->
                </div><!-- /.seo-services-cols -->
            </div><!-- /.seo-services-detail-inner -->
        </div><!-- /.container-md -->
    </div><!-- /.seo-services-detail-section -->








      

   

        <div class="testimonial-section section-space">
            <div class="container-lg">
                <div class="testimonial-section-inner">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="usre-reviews-col col-left">
                            <div class="section-title">
                            <h4>Our Consistant 5 Star Reviews</h4>
                            </div><!-- /.section-title -->
                            <div class="reviews-content">
                                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Alias sequi optio maxime! Hic aut possimus temporibus delectus accusantium ratione voluptatibus modi error, corporis, tenetur et molestiae. Obcaecati veritatis voluptate omnis.</p>
                            </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="usre-reviews-col col-right">
                            <div class="swiper">

                                <div class="swiper-wrapper">

                                    <div class="swiper-slide">
                                        <div class="review-wrap">
                                            <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                               <div class="swiper-nav-icons">
                                        <div class="swiper-button-prev icon-arrow-left swiper-nav"></div>
                                        <div class="swiper-button-next icon-arrow-right swiper-nav"></div>
                               </div><!-- /.swiper-nav-icons -->

                        </div><!--/.swiper-->

                            </div>
                        </div>
                    </div>
                </div><!-- /.testimonial-section-inner -->
            </div><!-- /.container-lg -->
        </div><!-- /.testimonial-section -->


   

        </main>

    </main><!--/.page__wrap-->


    <!-- <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br> -->

<?php include 'incl/footer.php'; ?>

