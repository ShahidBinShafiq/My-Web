<?php include 'incl/header.php'; ?>

    <main class="page__wrap">
    <div class="page-banner contact-banner">
        <div class="page-banner-inner">


        <div class="contact-banner-cols">
          <div class="contact-banner-col col-left">
            
          <div class="banner-title">
                <h1>Get in touch</h1>
                
            </div><!-- /.banner-title -->

            <div class="contact-modes">
                    <div class="mode-col">
                    <img src="assets/images/icons/calendar-ico.svg" alt="">
                    <span>07904 837030</span>
                    </div>
                    <div class="mode-col">
                    <img src="assets/images/icons/calendar-ico.svg" alt="">
                    <span>info@getslikk.co.uk</span>
                    </div>
                </div><!-- /.contact-modes -->

                <div class="email-form">
                  <div class="form-title">
                    <b>Send us an email</b>
                  </div>
                  <form action="">
                  <div class="mb-3">
                <input type="text" class="form-control form-pod"  placeholder="Your Name">
              </div>

              <div class="mb-3">
                <input type="text" class="form-control form-pod"  placeholder="Contact Number">
              </div>

              <div class="mb-3">
                <input type="email" class="form-control form-pod"  placeholder="Address" required>
              </div>

              <div class="mb-4">
                <textarea class="form-control message-pod"  rows="5" placeholder="Address"></textarea>
              </div>

              <div class="message-btn">
              <button type="submit" class="theme-btn btn-black-theme">Send Message</button>
              </div>
                  </form>

                </div><!-- /.email-form -->


          </div>


          <div class="contact-banner-col col-right">
          <img src="assets/images/student-banner.jpg" alt="">

          </div>
        </div>

        </div><!-- /.page-banner-inner -->
    </div><!-- /.page-banner -->

    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>