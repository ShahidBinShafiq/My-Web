<?php include 'incl/header.php'; ?>

    <main class="page__wrap">

      <div class="order-section form-wizard" id="order-sec">
        <div class="order-steps">

            <div class="form-wizard-header">
                <ul class="list-unstyled form-wizard-steps clearfix">
                    <li data-title="Address" data-step="1" class="active">
                        <span>1</span>


                    </li>
                    <li data-title="Item Selection" data-step='2' data-steps='2'>
                        <span>2</span>
                    </li>
                    <li data-title="Collection & Delivery" data-step="3">
                        <span>3</span>

                    </li>
                    <li data-title="Contact Details" data-step="4">
                        <span>4</span>
                    </li>
                </ul>
                <div class="form-group clearfix">
                    <a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a>
                    <a href="javascript:;" class="form-wizard-next-btn float-right">Next</a>
                </div>
            </div>



        </div><!-- /.order-steps -->
          <div class="order-container">
              <div class="order-section-inner">
                  <div class="order-col order-col-left">
                   

                  <div>
        <form action="" method="post" role="form">

            <fieldset class="wizard-fieldset show">
                <div class="step-title">
                <h4>Address</h4>
                </div><!-- /.step-title -->
                <div class="form-group">
                <label for="fname" class="wizard-form-text-label">PostCode</label>
                    <input type="text" class="form-control wizard-required" id="fname" placeholder="E13 9EJ">
                    <div class="wizard-form-error">
                        <!-- <span>this is required</span> -->
                    </div>
                </div>
                <div class="form-group">
                <label for="lname" class="wizard-form-text-label">Select Your Address</label>
                <label for="inputState" class="form-label">State</label>
                  <select id="inputState" class="form-select form-control wizard-required select-placeholder">
                    <option selected>Please select your address</option>
                    <option>Address Line One</option>
                  </select>
                    <div class="wizard-form-error"></div>
                </div>
                <!-- <div class="form-group">
                    Gender
                    <div class="wizard-form-radio">
                        <input name="radio-name" id="radio1" type="radio">
                        <label for="radio1">Male</label>
                    </div>
                    <div class="wizard-form-radio">
                        <input name="radio-name" id="radio2" type="radio">
                        <label for="radio2">Female</label>
                    </div>
                </div> -->
                <div class="form-group">

                    <label for="zcode" class="wizard-form-text-label">Address Line 2</label>
                    <input type="text" class="form-control wizard-required" id="zcode" placeholder="Please specify any extra address details">
                    <div class="wizard-form-error"></div>
                </div>
<!--                <div class="form-group clearfix">-->
<!--                    <a href="javascript:;" class="form-wizard-next-btn float-right">Next</a>-->
<!--                </div>-->
            </fieldset>	
            <fieldset class="wizard-fieldset">
                <h5>Account Information</h5>
                <div class="form-group">
                    <input type="email" class="form-control wizard-required" id="email">
                    <label for="email" class="wizard-form-text-label">Email*</label>
                    <div class="wizard-form-error"></div>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control wizard-required" id="username">
                    <label for="username" class="wizard-form-text-label">User Name*</label>
                    <div class="wizard-form-error"></div>
                </div>
                <div class="form-group">
                    <input type="password" class="form-control wizard-required" id="pwd">
                    <label for="pwd" class="wizard-form-text-label">Password*</label>
                    <div class="wizard-form-error"></div>
                    <span class="wizard-password-eye"><i class="far fa-eye"></i></span>
                </div>
                <div class="form-group">
                    <input type="password" class="form-control wizard-required" id="cpwd">
                    <label for="cpwd" class="wizard-form-text-label">Confirm Password*</label>
                    <div class="wizard-form-error"></div>
                </div>
<!--                <div class="form-group clearfix">-->
<!--                    <a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a>-->
<!--                    <a href="javascript:;" class="form-wizard-next-btn float-right">Next</a>-->
<!--                </div>-->
            </fieldset>	
            <fieldset class="wizard-fieldset">
                <h5>Bank Information</h5>
                <div class="form-group">
                    <input type="text" class="form-control wizard-required" id="bname">
                    <label for="bname" class="wizard-form-text-label">Bank Name*</label>
                    <div class="wizard-form-error"></div>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control wizard-required" id="brname">
                    <label for="brname" class="wizard-form-text-label">Branch Name*</label>
                    <div class="wizard-form-error"></div>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control wizard-required" id="acname">
                    <label for="acname" class="wizard-form-text-label">Account Name*</label>
                    <div class="wizard-form-error"></div>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control wizard-required" id="acon">
                    <label for="acon" class="wizard-form-text-label">Account Number*</label>
                    <div class="wizard-form-error"></div>
                </div>

            </fieldset>	
            <fieldset class="wizard-fieldset">
                <h5>Field</h5>
                
            </fieldset>	
            <fieldset class="wizard-fieldset">
                <h5>Payment Information</h5>
                <div class="form-group">
                    Payment Type
                    <div class="wizard-form-radio">
                        <input name="radio-name" id="mastercard" type="radio">
                        <label for="mastercard">Master Card</label>
                    </div>
                    <div class="wizard-form-radio">
                        <input name="radio-name" id="visacard" type="radio">
                        <label for="visacard">Visa Card</label>
                    </div>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control wizard-required" id="honame">
                    <label for="honame" class="wizard-form-text-label">Holder Name*</label>
                    <div class="wizard-form-error"></div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="form-group">
                            <input type="text" class="form-control wizard-required" id="cardname">
                            <label for="cardname" class="wizard-form-text-label">Card Number*</label>
                            <div class="wizard-form-error"></div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="form-group">
                            <input type="text" class="form-control wizard-required" id="cvc">
                            <label for="cvc" class="wizard-form-text-label">CVC*</label>
                            <div class="wizard-form-error"></div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">Expiry Date</div>
                    <div class="col-lg-4 col-md-4 col-sm-4">
                        <div class="form-group">
                            <select class="form-control">
                                <option value="">Date</option>
                                <option value="">1</option>
                                <option value="">2</option>
                                <option value="">3</option>
                                <option value="">4</option>
                                <option value="">5</option>
                                <option value="">6</option>
                                <option value="">7</option>
                                <option value="">8</option>
                                <option value="">9</option>
                                <option value="">10</option>
                                <option value="">11</option>
                                <option value="">12</option>
                                <option value="">13</option>
                                <option value="">14</option>
                                <option value="">15</option>
                                <option value="">16</option>
                                <option value="">17</option>
                                <option value="">18</option>
                                <option value="">19</option>
                                <option value="">20</option>
                                <option value="">21</option>
                                <option value="">22</option>
                                <option value="">23</option>
                                <option value="">24</option>
                                <option value="">25</option>
                                <option value="">26</option>
                                <option value="">27</option>
                                <option value="">28</option>
                                <option value="">29</option>
                                <option value="">30</option>
                                <option value="">31</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4">
                        <div class="form-group">
                            <select class="form-control">
                                <option value="">Month</option>
                                <option value="">jan</option>
                                <option value="">Feb</option>
                                <option value="">March</option>
                                <option value="">April</option>
                                <option value="">May</option>
                                <option value="">June</option>
                                <option value="">Jully</option>
                                <option value="">August</option>
                                <option value="">Sept</option>
                                <option value="">Oct</option>
                                <option value="">Nov</option>
                                <option value="">Dec</option>	
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4">
                        <div class="form-group">
                            <select class="form-control">
                                <option value="">Years</option>
                                <option value="">2019</option>
                                <option value="">2020</option>
                                <option value="">2021</option>
                                <option value="">2022</option>
                                <option value="">2023</option>
                                <option value="">2024</option>
                                <option value="">2025</option>
                                <option value="">2026</option>
                                <option value="">2027</option>
                                <option value="">2028</option>
                                <option value="">2029</option>
                                <option value="">2030</option>
                                <option value="">2031</option>
                                <option value="">2032</option>
                                <option value="">2033</option>
                                <option value="">2034</option>
                                <option value="">2035</option>
                                <option value="">2036</option>
                                <option value="">2037</option>
                                <option value="">2038</option>
                                <option value="">2039</option>
                                <option value="">2040</option>	
                            </select>
                        </div>
                    </div>
                </div>
<!--                <div class="form-group clearfix">-->
<!--                    <a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a>-->
<!--                    <a href="javascript:;" class="form-wizard-submit float-right">Submit</a>-->
<!--                </div>-->
            </fieldset>	
        </form>

    </div>







                  </div>
                  <div class="order-col order-col-right" id="order-details">

                        <ul>
                            <li class="step-details" data-step="1">
                                <div class="custom-checkbox">
                                    <input type="checkbox" id="weekday-1" name="weekday-1" value="Address" checked>
                                    <label for="weekday-1">Address</label>
                                </div><!-- /.custom-chekbox -->
                            </li>
                            <li class="step-details" data-step="2">
                                <div class="custom-checkbox">
                                    <input type="checkbox"  name="weekday-1" value="Item Selection" checked>
                                    <label for="weekday-1">Item Selection</label>
                                </div><!-- /.custom-chekbox -->
                            </li>
                            <li class="step-details" data-step="3">
                                <div class="custom-checkbox">
                                    <input type="checkbox" name="weekday-1" value="Collection & Delivery" checked>
                                    <label for="weekday-1">Collection & Delivery</label>
                                </div><!-- /.custom-chekbox -->
                            </li>

                            <li class="step-details" data-step="4">
                                <div class="custom-checkbox">
                                    <input type="checkbox"  name="weekday-1" value="Contact Details" checked>
                                    <label for="weekday-1">Contact Details</label>
                                </div><!-- /.custom-chekbox -->
                            </li>
                      
                        </ul>

                </div>
              </div><!-- /.order-section-inner -->
          </div><!-- /.order-container -->
      </div><!-- /.order-section -->



        
    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>