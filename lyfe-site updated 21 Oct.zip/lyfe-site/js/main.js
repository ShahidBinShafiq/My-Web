
$(document).ready(function(){


// Steps wizard JS

 // click on next button
 jQuery(".form-wizard-next-btn").click(function () {
  var cartSection = $("#order-sec");
  var parentFieldset = cartSection.find(".wizard-fieldset.show");
  // console.log(parentFieldset, cartSection)
  var currentActiveStep = cartSection.find(".form-wizard-steps .active");
  var nextWizardStep = true;

  parentFieldset.find(".wizard-required").each(function () {
    var thisValue = jQuery(this).val();
    if (thisValue == "") {
      jQuery(this).parent('.form-group').addClass("wizard-form-error");
      nextWizardStep = false;
    } else {
      jQuery(this).parent('.form-group').removeClass("wizard-form-error");
    }
  });
  if (nextWizardStep && currentActiveStep.attr("data-step")) {
    const currentStep = Number(currentActiveStep.attr("data-step"));
    const totalSteps = Number(currentActiveStep.attr("data-steps")) || 0;
    const currentacStep =
      (totalSteps > 0 && Number(currentActiveStep.attr("data-current"))) || 1;
    if (currentStep > 0) {
      $(".form-wizard-previous-btn").addClass("activatedBtn");
    }
    const existingStep = currentActiveStep.next().attr("data-step") != null;
    const lastStep =
      currentActiveStep.next().attr("data-step") == null &&
      currentActiveStep.attr("data-step") != null;
    if (
      currentStep != null &&
      totalSteps !== 0 &&
      totalSteps > currentacStep
    ) {
      currentActiveStep.attr("data-current", currentacStep + 1);
    } else if (existingStep || lastStep) {
      currentActiveStep.removeClass("active");
      currentRightActiveStep(Number(currentActiveStep.attr("data-step")));
      if (existingStep) {
        currentActiveStep
          .addClass("activated")
          .next()
          .addClass("active", "400");
      } else {
        currentActiveStep.addClass("activated lastactive");
        $(".form-wizard-next-btn").removeClass("activatedBtn");
        return;
      }
      console.log(Number(currentActiveStep.attr("data-step")));
    } else {
      return;
    }

    cartSection.find(".wizard-fieldset").removeClass("show", "400");
    parentFieldset.next(".wizard-fieldset").addClass("show", "400");
  }
});
//click on previous button
jQuery(".form-wizard-previous-btn").click(function () {
  var cartSection = $("#order-sec");
  const lastActive = cartSection.find(".form-wizard-steps .lastactive");
  var currentActiveStep =
    lastActive?.length > 0
      ? lastActive
      : cartSection.find(".form-wizard-steps .active");
  const currentelTotalSteps =
    Number(currentActiveStep.attr("data-steps")) || 0;
  const currentelcurrentStep =
    Number(currentActiveStep.attr("data-current")) || 0;

  var currentWizard = cartSection.find(".wizard-fieldset.show");
  const prevElementTotalSteps =
    Number(currentActiveStep.prev().attr("data-steps")) || 0;
  const prevElementCurrentStep =
    Number(currentActiveStep.prev().attr("data-current")) || 0;
  const currentStep = Number(currentActiveStep.attr("data-step"));
  if (currentStep && currentStep - 1 > 1) {
    $(".form-wizard-next-btn").addClass("activatedBtn");
    
  } else {
    $(".form-wizard-previous-btn").removeClass("activatedBtn");
  }

  const prevElementCondition =
    prevElementTotalSteps !== 0 && prevElementCurrentStep >= 1;
  const currentElementCondition =
    currentActiveStep.prev().attr("data-step") != null;
  if (currentelTotalSteps !== 0 && currentelcurrentStep > 1) {
    currentActiveStep.removeClass("lastactive").removeClass("activated");
    currentActiveStep.attr("data-current", currentelcurrentStep - 1);
  } else if (prevElementCondition || currentElementCondition) {
    currentActiveStep.removeClass("lastactive").removeClass("activated");
    if (prevElementTotalSteps === prevElementCurrentStep) {
      var currentPrev = currentActiveStep
        .removeClass("active")
        .removeClass("lastactive");

      if (prevElementCondition) {
        currentPrev.prev().removeClass("activated").addClass("active", "400");
      } else {
        currentPrev
          .removeClass("activated")
          .prev()
          .removeClass("activated")
          .addClass("active", "400");
        }
        currentRightActiveStep(Number(currentPrev.attr("data-step")) - 2);
    }
  } else {
    return;
  }
  if (lastActive?.length > 0) {
    currentActiveStep
      .removeClass("lastactive")
      .removeClass("activated")
      .removeClass("activated");
  }
  currentWizard.removeClass("show", "400");
  currentWizard.prev(".wizard-fieldset").addClass("show", "400");

  // cartSection.find('.wizard-fieldset').each(function(){
  // 	if(jQuery(this).hasClass('show')){
  // 		var formAtrr = jQuery(this).attr('data-tab-content');
  // 		console.log(formAtrr)
  // 		jQuery(document).find('.form-wizard-steps .form-wizard-step-item').each(function(){
  // 			if(jQuery(this).attr('data-attr') == formAtrr){
  // 				jQuery(this).addClass('active');
  // 				var innerWidth = jQuery(this).innerWidth();
  // 				var position = jQuery(this).position();
  // 				jQuery(document).find('.form-wizard-step-move').css({"left": position.left, "width": innerWidth});
  // 				currentRightActiveStep(jQuery(this), "remove");
  // 			}else{
  // 				jQuery(this).removeClass('active');
  // 				currentRightActiveStep(jQuery(this), "add");
  // 			}
  // 		});
  // 	}
  // });
});
// Active right side
function currentRightActiveStep(step = 0) {
  const orderdetails = $("#order-details");
  orderdetails.find(".step-details").each(function () {
    const currentItem = $(this);
    const itemstep = Number(currentItem.attr("data-step"));
console.log({itemstep, step})
    if (itemstep <= step) {
      currentItem.addClass("order-detail-checked");
    } else {
      currentItem.removeClass("order-detail-checked");
    }
  });
}
//click on form submit button
jQuery(document).on("click", ".form-wizard .form-wizard-submit", function () {
  var parentFieldset = jQuery(this).parents(".wizard-fieldset");
  var currentActiveStep = jQuery(this)
    .parents(".form-wizard")
    .find(".form-wizard-steps .active");
  parentFieldset.find(".wizard-required").each(function () {
    var thisValue = jQuery(this).val();
    if (thisValue == "") {
      jQuery(this).parent('.form-group').addClass("wizard-form-error");
    } else {
      jQuery(this).parent('.form-group').removeClass("wizard-form-error");
    }
  });
});
// focus on input field check empty or not
jQuery(".form-control")

  .on("focus", function () {
    var tmpThis = jQuery(this).val();
    jQuery(this).parent('.form-group').removeClass("wizard-form-error");      
    if (tmpThis == "") {
      jQuery(this).parent().addClass("focus-input");
    } else if (tmpThis != "") {
      jQuery(this).parent().addClass("focus-input");


    }
  })
  .on("blur", function () {
    var tmpThis = jQuery(this).val();
    if (tmpThis == "") {
      jQuery(this).parent().removeClass("focus-input");
      jQuery(this).parent('.form-group').addClass("wizard-form-error");
    } else if (tmpThis != "") {
      jQuery(this).parent().addClass("focus-input");
      jQuery(this).parent('.form-group').removeClass("wizard-form-error");      }
  });


// Steps wizard JS ends










    $(".password-toggle").click(function () {

        let passbtn = $('.password-toggle').html();

        if(passbtn == "Show"){
            $('.password-toggle').html("Hide");
            $('#loginPass').attr('type','text');

        }else{
            $('.password-toggle').html("Show");
            $('#loginPass').attr('type','password');

        }
    });


    $(".c-password-toggle").click(function () {

        let passbtn = $('.c-password-toggle').html();

        if(passbtn == "Show"){
            $('.c-password-toggle').html("Hide");
            $('#confirmPass').attr('type','text');

        }else{
            $('.c-password-toggle').html("Show");
            $('#confirmPass').attr('type','password');

        }
    });

        $("#mega-nav-item1").hover(function(){
            $("#mega-nav").slideToggle(400);
         });

         $("#mega-nav-item2").hover(function(){
            $("#mega-nav2").slideToggle(400);
         });
    

         $('.owl-carousel').owlCarousel({
          loop:false,
          margin:10,
          nav:true,
          dots: false,
          mouseDrag: false,
          responsive:{
              0:{
                  items:1
              },
              600:{
                  items:1
              },
              1000:{
                  items:1
              }
          }
      })



    //   checkout stages
    $("#new-delivery-address").hide();
    $("#manual-delivery-address").hide();
      $("#new-billing-address").hide();
     
      $("#c-out-new-address").hide();

      $("#cOut-new-addressBtn").click(function(){
        $("#c-out-delivery-address").hide();
        $("#c-out-new-address").show();

      });


      $("#c-out-manual-address").hide();

      $("#cOut-manual-addressBtn").click(function(){
        $("#c-out-new-address").hide();
        $("#c-out-manual-address").show();

      });




      $("#c-out-step2").hide();

      // $("#c-out-next1").click(function(){
      //   $("#c-out-step2").show();
      //   $("#c-out-next1").hide();

      // });


      $("#c-out-step3").hide();

      $("#enter-othr-adrs").click(function(){
        $("#c-out-step3").show();
        $("#billing-address-pod").hide();
        $("#new-billing-adrs").show();
        $("#payment-pods").hide();

      });


      $("#use-delivery-address").click(function(){
        $("#billing-address-pod").show();
        $("#new-billing-adrs").hide();
        // $("#c-out-next3").hide();
        $("#c-out-step3").show();

      });




      $("#c-out-step4").hide();

      $("#c-out-next3").click(function(){
        $("#c-out-step3").hide();
        $("#billing-address-pod").hide();
        $("#c-out-step4").show();

      });




      $("#paypal-pay").click(function(){
        $("#card-pay").hide();

      });


      $("#credit-card-pay").click(function(){
        $("#card-pay").show();

      });

      $("#payment-pods").click(function(){
        $("#c-out-step4").show();
        $("#c-out-step2").hide();

      });







      // text fields number validation

      // Only allow number keys + number pad

$('input[name="num-field"]').keypress
(
    function(event)
    {
        if (event.keyCode == 46 || event.keyCode == 8)
        {
        //do nothing
        }
        else 
        {
            if (event.keyCode < 48 || event.keyCode > 57 ) 
            {
			    event.preventDefault();	
			}	
        }
    }
);









     
     
     
    });

    var numInput;
var number = 0;
var numberInput = 0;

$(".increment").on("click",function(){
  numInput = $(this).parent(".control-buttons").siblings("input");
  number = parseInt($(numInput).val());
  if (isNaN(number)){
    number = 0;
  }
  $(numInput).val(parseInt(number)+1);
  numInput = null; number = 0; numInput = 0;
});

$(".decrement").on("click",function(){
  numInput = $(this).parent(".control-buttons").siblings("input");
  number = parseInt($(numInput).val());

  if ( (isNaN(number) ) || (number < 0) ) {
    number = 0;
    $(numInput).val(number);
  } else if ($(numInput).val() > 0) {
    $(numInput).val(parseInt(number)-1);
  }
  numInput = null; number = 0; numInput = 0;
});




// checkout-forms validation

let fieldRequired = document.getElementById('field-required');
let cOutBtn1 = document.getElementById('c-out-next1');

cOutBtn1.addEventListener('click', function(){
  if(fieldRequired.value==""){
    fieldRequired.classList.add('field-error');
  }else{
       $(this).hide();
       $("#c-out-step2").show();
      
       fieldRequired.classList.remove('field-error');
  }
})








// checkout-page validation


// function formValidation() {
//     const submitButton = document.querySelector(".form-submit");
//     submitButton.addEventListener("click", function () {
//       validateFormonSubmit();
//     });
//     validateForm();
//   }
//   function inputValidate(target, input) {
//     const parent = target.parentElement;
//     const value = target.value;
//     const inputClasses = Array.from(input.classList);
//     const isRequired = inputClasses.find(function (cls) {
//       return cls === "field-required";
//     });
//     if (isRequired) {
//       if (value == "") {
//         parent.classList.add("error");
//       } else {
//         parent.classList.remove("error");
//         $("#c-out-next1").click(function(){
//           $(this).hide();
//           $("#c-out-step2").show();
  
//         });
//       }
//     }
//   }
//   function validateForm(params) {
//     const formPod = document.querySelector(".form-pod");
//     const inputs = formPod.getElementsByClassName("form-control");
//     if (inputs) {
//       const inputFields = Array.from(inputs);
//       inputFields.forEach(function (input) {
//         input.addEventListener("input", function (e) {
//           inputValidate(e.target, input);
//         });
//         input.addEventListener("blur", function (e) {
//           inputValidate(e.target, input);
//         });
//       });
//     }
//   }
//   function validateFormonSubmit(params) {
//     const formPod = document.querySelector(".form-pod");
//     const inputs = formPod.getElementsByClassName("form-control");
//     if (inputs) {
//       const inputFields = Array.from(inputs);
//       inputFields.forEach(function (input) {
//         inputValidate(input, input);
//       });
//     }
//   }
//   formValidation();