<?php include 'incl/header.php'; ?>

    <main class="page__wrap">

        <main>
        <!-- <canvas id="canvas"> </canvas> -->
        <div class="about-page-wrap">
        <div class="container-md">
            <div class="about-page-inner">
            <div class="page-heading-title">
                <h4>A team of young and <br> <span class="tg-lineare">talented digital experts</span></h4>
                </div><!-- /.page-heading-title -->
                <div class="about-page-description">
                    <p>The Site Space is a spectacular team of specialists that are proficient at what they do. Including SEO, web design & development, application development, digital marketing, and content creation, we do it all. </p>
                    <p>Based in the heart of London, our agency is devoted to helping you stand out in today’s competitive market. Our passion for creativity and innovation keeps us going.</p>
                    <p>Eager to learn new trends and modern tools, our team is always ready to offer you the best of the best. We ensure transparent communication with our clients and keep them in the loop regarding the progress of our projects together. </p>
                    <p>Our strategies are intended to achieve real business goals and provide optimal solutions to your online business matters. So, whether you are looking for a smart, fast, and appealing website or a way to promote your business digitally, hit us up anytime.</p>
                    <p>We will make it happen!</p>
                </div><!-- /.about-page-description -->
            </div><!-- /.about-page-inner -->
        </div><!-- /.container-md -->
        </div><!-- /.about-page-wrap -->


        </main>

    </main><!--/.page__wrap-->


    <!-- <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br> -->

<?php include 'incl/footer.php'; ?>

