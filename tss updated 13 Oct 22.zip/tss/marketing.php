<?php include 'incl/header.php'; ?>

    <main class="page__wrap">

        <main>
        <!-- <canvas id="canvas"> </canvas> -->

        <div class="page-banner-wrapper marketing-page-banner">

<div class="container-md">
<div class="page-banner-inner">
<div class="page-banner-title">
        <div class="banner-title-inner">
          
        <h2>Revolutionary <br> <span class="tg-lineare">Digital Marketing</span> <br> in London</h2>
        <p>As a dynamic agency, our goal is to make an everlasting impression on our clients so that they don’t forget about us. And this is exactly what we want for our clients. </p>
            <!-- <a href="#" class="theme-btn">Start Your Project</a> -->

            <!-- <a href="#" class="theme-btn">
  <div class="btn-circle border-primary" >
    <div class="btn-circle border-primary">
    Start Your Project
    </div>  
  </div>
</a> -->

            <div class="anim-cirlce xl-hide">
            <svg viewBox="0 0 100 100" width="100" height="100">
                <defs>
                    <path id="circle" d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"/>
                </defs>
                <text>
                    <textPath xlink:href="#circle">
                    We Create Fast websites
                    </textPath>
                </text>
                </svg>
            </div><!-- /.anim-cirlce -->
       
        </div>
</div><!-- /.page-banner-title -->
</div><!-- /.page-banner-inner -->
</div><!-- /.container-md -->

<span class="site-page-title">Digital Marketing</span>
</div><!-- /.page-banner-wrapper -->

    <div class="web-design-process section-space">
        <div class="container-md">
            <div class="web-design-porcess-inner">
                <div class="process-col">
                    <img src="assets/icons/technical.svg" alt="">
                    <p>Technical SEO <br>& Website Analysis</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/analysis.svg" alt="">
                    <p>Keywords & <br> Competitor Analysis</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/integration.svg" alt="">
                    <p>On-Page SEO & <br> Metas Integration</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/submission.svg" alt="">
                    <p>Off-Page SEO & <br> Google Submission</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/report.svg" alt="">
                    <p>Monthly <br> Reporting</p>
                </div>
               
            </div><!-- /.web-design-porcess-inner -->
        </div><!-- /.container-md -->
    </div><!-- /.web-design-process -->



    <div class="web-types-section seo-types">
        <div class="container-lg">
            <div class="web-types-section-inner">
                <div class="container-md">
                <div class="section-pod-title text-center">
                    <h4>SEO Services a few clicks away</h4>
                    <p>Our performance-driven workforce specialises in designing customised marketing 
                    campaigns for brands that don’t shy from being a little unorthodox. With our economical 
                    packages, you can outshine the brands with traditional marketing methods. Our highly-
                    skilled staff ensures high quality results.</p>
                </div>
                </div>
                <div class="type-pods-wrpper section-space">
                <div class="type-pod">
                    <div class="type-pod-hover">
                    <div class="type-pod-inner">
                    <div class="type-col col-left">
                        <div class="section-pod-title">
                        <h4>Technical SEO</h4>
                        <p>A website’s architecture is the first step to ensuring a higher ranking on SERPs.</p>
                        </div>

                    </div>

                    <div class="type-col col-right">
                    <img src="assets/icons/seo.svg" alt="">
                    </div>
                </div><!-- /.type-pod-inner -->
                    </div><!-- /.type-pod-hover -->
                </div><!-- /.type-pod -->
                <div class="type-pod">
                    <div class="type-pod-hover">
                    <div class="type-pod-inner">
                    <div class="type-col col-left">
                        <div class="section-pod-title">
                        <h4>On-Page SEO</h4>
                        <p>A website gains organic traffic and higher SERPs ranking through proper On-Page SEO.</p>
                        </div>

                    </div>

                    <div class="type-col col-right">
                    <img src="assets/icons/onpageseo.svg" alt="">
                    </div>
                </div><!-- /.type-pod-inner -->
                    </div><!-- /.type-pod-hover -->
                </div><!-- /.type-pod -->
                <div class="type-pod">
                    <div class="type-pod-hover">
                    <div class="type-pod-inner">
                    <div class="type-col col-left">
                        <div class="section-pod-title">
                        <h4>Off-Page SEO</h4>
                        <p>A website gets more exposure through Off-Page SEO.</p>
                        </div>

                    </div>

                    <div class="type-col col-right">
                    <img src="assets/icons/offpageseo.svg" alt="">
                    </div>
                </div><!-- /.type-pod-inner -->
                    </div><!-- /.type-pod-hover -->
                </div><!-- /.type-pod -->
         
   
           
          
        
                </div><!-- /.type-pods-wrpper -->
            </div><!-- /.web-types-section-inner -->
        </div><!-- /.container-lg -->
    </div><!-- /.web-types-section -->

    <div class="seo-services-detail-section">
        <div class="container-md">
            <div class="seo-services-detail-inner">
            <div class="section-pod-title text-center">
                        <h4>What makes us better than the rest?</h4>
                        <p>A fusion of creativity, experience, and dedication is what sets us apart. Our digital 
                            marketing team specialises in creating spectacular marketing campaigns that connect 
                            our clients to their targeted audience. We put extra hard work into tracking performance 
                            and optimisation of marketing campaigns so that you can stay ahead of the curve.</p>
                        </div>

                <div class="seo-services-cols">
                    <div class="seo-services-cols-inner">
                        <div class="svc-col">
                        <img src="assets/icons/technical.svg" alt="">
                        <p>SEO</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/app.svg" alt="">
                        <p>Social Media <br> Marketing</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/submission.svg" alt="">
                        <p>Local SEO</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/google-ads.svg" alt="">
                        <p>PPC Google <br> Ads</p>
                        </div>
                    </div><!-- /.seo-services-cols-inner -->
                </div><!-- /.seo-services-cols -->
            </div><!-- /.seo-services-detail-inner -->
        </div><!-- /.container-md -->
    </div><!-- /.seo-services-detail-section -->




        <div class="testimonial-section section-space">
            <div class="container-lg">
                <div class="testimonial-section-inner">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="usre-reviews-col col-left">
                            <div class="section-title">
                            <h4>Don’t leave out our 5-star reviews</h4>
                            </div><!-- /.section-title -->
                            <div class="reviews-content">
                                <p>Our utter devotion to our clients and their work plays a vital role in our success. We 
                                obsess over creating something unique and fresh that can do everything you want it to 
                                do. If you want class, we are your guys!</p>
                            </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="usre-reviews-col col-right">
                            <div class="swiper">

                                <div class="swiper-wrapper">

                                    <div class="swiper-slide">
                                        <div class="review-wrap">
                                        <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="reviews-footer">
                                    <div>
                                        <b>2021</b>
                                    </div>
                                    <div class="swiper-nav-icons">
                                        <div class="swiper-button-prev icon-arrow-left swiper-nav"></div>
                                        <div class="swiper-button-next icon-arrow-right swiper-nav"></div>
                               </div><!-- /.swiper-nav-icons -->
                                </div><!-- /.reviews-footer -->

                        </div><!--/.swiper-->

                            </div>
                        </div>
                    </div>
                </div><!-- /.testimonial-section-inner -->
            </div><!-- /.container-lg -->
        </div><!-- /.testimonial-section -->


   

        </main>

    </main><!--/.page__wrap-->


    <!-- <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br> -->

<?php include 'incl/footer.php'; ?>

