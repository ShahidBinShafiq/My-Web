<?php include 'incl/header.php'; ?>

    <main class="page__wrap">

        <main>
        <!-- <canvas id="canvas"> </canvas> -->

        <div class="page-banner-wrapper marketing-page-banner">

<div class="container-md">
<div class="page-banner-inner">
<div class="page-banner-title">
        <div class="banner-title-inner">
        <h2>Web <span class="tg-lineare">Application</span> <br> <span class="tg-lineare-reverse">Development</span> <span>Agency. </span></h2>
        <p>Websites alone are no longer it. Web applications are one of the few essentials needed for a successful online presence.</p>
            <!-- <a href="#" class="theme-btn">Start Your Project</a> -->

            <!-- <a href="#" class="theme-btn">
  <div class="btn-circle border-primary" >
    <div class="btn-circle border-primary">
    Start Your Project
    </div>  
  </div>
</a> -->

            <div class="anim-cirlce xl-hide">
            <svg viewBox="0 0 100 100" width="100" height="100">
                <defs>
                    <path id="circle" d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"/>
                </defs>
                <text>
                    <textPath xlink:href="#circle">
                    We Create Fast websites
                    </textPath>
                </text>
                </svg>
            </div><!-- /.anim-cirlce -->
       
        </div>
</div><!-- /.page-banner-title -->
</div><!-- /.page-banner-inner -->
</div><!-- /.container-md -->

<span class="site-page-title">Website Application</span>
</div><!-- /.page-banner-wrapper -->

<div class="web-design-process section-space">
        <div class="container-md">
            <div class="web-design-porcess-inner">
                <div class="process-col">
                    <img src="assets/icons/project.svg" alt="">
                    <p>Discovery & <br> Analysis</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/uiux-tech.svg" alt="">
                    <p>UI/UX & Tech <br> Design</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/development.svg" alt="">
                    <p>Development & <br> Programming</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/plagiarism.svg" alt="">
                    <p>Testing & <br> Final QA</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/app-launch.svg" alt="">
                    <p>Launch & <br> Support</p>
                </div>
               
            </div><!-- /.web-design-porcess-inner -->
        </div><!-- /.container-md -->
    </div><!-- /.web-design-process -->



    <div class="web-types-section mobile-app">
        <div class="container-lg">
            <div class="web-types-section-inner">
                <div class="container-md">
                <div class="section-pod-title text-center">
                    <h4>Web applications are a game-changer</h4>
                    <p>Brilliant, fun, and interactive web applications can be revolutionary for your online 
                    business. Your web application should represent your products and services in a way 
                    that convinces the user to buy them without thinking twice. A state of the art web 
                    application can be your dream come true with no limitations to hold you back.</p>
                </div>
                </div>
                <div class="type-pods-wrpper section-space">
                <div class="type-pod">
                    <div class="type-pod-hover">
                    <div class="type-pod-inner">
                    <div class="type-col col-left">
                        <div class="section-pod-title">
                        <h4>Saas Applications</h4>
                        <p>SAAS or Software As A Service applications are leased apps that are hosted by a third 
                            party. SAAS apps are great for on-budget clients.</p>
                        </div>

                    </div>

                    <div class="type-col col-right">
                    <img src="assets/icons/web-ortals.svg" alt="">
                    </div>
                </div><!-- /.type-pod-inner -->
                    </div><!-- /.type-pod-hover -->
                </div><!-- /.type-pod -->
                <div class="type-pod">
                    <div class="type-pod-hover">
                    <div class="type-pod-inner">
                    <div class="type-col col-left">
                        <div class="section-pod-title">
                        <h4>Business Applications</h4>
                        <p>An application that is full of functionalities and represents and allows access to your 
                        business. It offers effortless tracking of productivity, performance, and revenues.</p>
                        </div>

                    </div>

                    <div class="type-col col-right">
                    <img src="assets/icons/business-app.svg" alt="">
                    </div>
                </div><!-- /.type-pod-inner -->
                    </div><!-- /.type-pod-hover -->
                </div><!-- /.type-pod -->
                <div class="type-pod">
                    <div class="type-pod-hover">
                    <div class="type-pod-inner">
                    <div class="type-col col-left">
                        <div class="section-pod-title">
                        <h4>Web Portals</h4>
                        <p>Web-based systems that gather user data and credentials and retrieve information according to that data.</p>
                        </div>

                    </div>

                    <div class="type-col col-right">
                    <img src="assets/icons/saas.svg" alt="">
                    </div>
                </div><!-- /.type-pod-inner -->
                    </div><!-- /.type-pod-hover -->
                </div><!-- /.type-pod -->
         
   
           
          
        
                </div><!-- /.type-pods-wrpper -->
            </div><!-- /.web-types-section-inner -->
        </div><!-- /.container-lg -->
    </div><!-- /.web-types-section -->

    <div class="seo-services-detail-section">
        <div class="container-md">
            <div class="seo-services-detail-inner">
            <div class="section-pod-title text-center">
                        <h4>Why Web Applications?</h4>
                        <p>Web applications give you the freedom to implement all your ideas no matter how 
                        bizarre. With this freedom to be creative, you can make your business the next big 
                        thing. Our team of specialists carefully design and develop web applications to be what 
                        you want them to be. All your ideas are of utmost importance when it comes to 
                        designing; all we do is implement them.</p>
                        </div>

                <div class="seo-services-cols">
                    <div class="seo-services-cols-inner">
                        <div class="svc-col">
                        <img loading="lazy" src="assets/icons/travel-app.svg" alt="">
                        <p>Travel & Holiday <br> Portals</p>
                        </div>
                        <div class="svc-col">
                        <img loading="lazy" src="assets/icons/news.svg" alt="">
                        <p>News <br> Portals</p>
                        </div>
                        <div class="svc-col">
                        <img loading="lazy" src="assets/icons/realestate-app.svg" alt="">
                        <p>Real Estate <br> Apps</p>
                        </div>
                        <div class="svc-col">
                        <img loading="lazy" src="assets/icons/hiring.svg" alt="">
                        <p>Taxi Apps</p>
                        </div>
                        <div class="svc-col">
                        <img loading="lazy" src="assets/icons/b2b.svg" alt="">
                        <p>Forex Trading <br> Apps</p>
                        </div>
                        <div class="svc-col">
                        <img loading="lazy" src="assets/icons/ecommerce-app.svg" alt="">
                        <p>eCommerce <br> Apps</p>
                        </div>
                        <div class="svc-col">
                        <img loading="lazy" src="assets/icons/auction.svg" alt="">
                        <p>Learning& <br> Education Apps</p>
                        </div>
                        <div class="svc-col">
                        <img loading="lazy" src="assets/icons/corporate.svg" alt="">
                        <p>Health & <br> Wellness Apps</p>
                        </div>
                    </div><!-- /.seo-services-cols-inner -->
                </div><!-- /.seo-services-cols -->
            </div><!-- /.seo-services-detail-inner -->
        </div><!-- /.container-md -->
    </div><!-- /.seo-services-detail-section -->




        <div class="testimonial-section section-space">
            <div class="container-lg">
                <div class="testimonial-section-inner">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="usre-reviews-col col-left">
                            <div class="section-title">
                            <h4>Don’t leave out our 5-star reviews</h4>
                            </div><!-- /.section-title -->
                            <div class="reviews-content">
                                <p>Our utter devotion to our clients and their work plays a vital role in our success. We 
                                obsess over creating something unique and fresh that can do everything you want it to 
                                do. If you want class, we are your guys!</p>
                            </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="usre-reviews-col col-right">
                            <div class="swiper">

                                <div class="swiper-wrapper">

                                    <div class="swiper-slide">
                                        <div class="review-wrap">
                                        <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="reviews-footer">
                                    <div>
                                        <b>2021</b>
                                    </div>
                                    <div class="swiper-nav-icons">
                                        <div class="swiper-button-prev icon-arrow-left swiper-nav"></div>
                                        <div class="swiper-button-next icon-arrow-right swiper-nav"></div>
                               </div><!-- /.swiper-nav-icons -->
                                </div><!-- /.reviews-footer -->

                        </div><!--/.swiper-->

                            </div>
                        </div>
                    </div>
                </div><!-- /.testimonial-section-inner -->
            </div><!-- /.container-lg -->
        </div><!-- /.testimonial-section -->


   

        </main>

    </main><!--/.page__wrap-->


    <!-- <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br> -->

<?php include 'incl/footer.php'; ?>

