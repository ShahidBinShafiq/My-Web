<?php include 'incl/header.php'; ?>

    <main class="page__wrap">
       
        <div class="user_panel-wrap">
            <div class="user_panel-Inner">
                <div class="left-col side-bar">
                   <div class="user-panel-sidebar-inner">
                        <div class="user-item-order-list">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                               
                               
                                <button class="nav-link active" id="item1" data-bs-toggle="tab" data-bs-target="#tab1" type="button" role="tab" aria-controls="tab1" aria-selected="true"> <i class="icon-my-orders"></i> My Orders</button>
                            </li>
                            <li class="nav-item" role="presentation">
                           
                                <button class="nav-link" id="item2" data-bs-toggle="tab" data-bs-target="#tab2" type="button" role="tab" aria-controls="tab2" aria-selected="false">  <i class="icon-seting"></i> Account Settings</button>
                            </li>
                            <li class="nav-item" role="presentation">
                           
                                <button class="nav-link" id="item3" data-bs-toggle="tab" data-bs-target="#tab3" type="button" role="tab" aria-controls="tab3" aria-selected="false">  <i class="icon-payment-card"></i> Payments Card</button>
                            </li>
                            <li class="nav-item" role="presentation">
                           
                                <button class="nav-link" id="item4" data-bs-toggle="tab" data-bs-target="#tab4" type="button" role="tab" aria-controls="tab4" aria-selected="false">  <i class="icon-discount"></i> Discount History</button>
                            </li>
                            <li class="nav-item" role="presentation">
                           
                                <button class="nav-link" id="item5" data-bs-toggle="tab" data-bs-target="#tab5" type="button" role="tab" aria-controls="tab5" aria-selected="false">  <i class="icon-loyalty"></i> Loyalty History</button>
                            </li>
                            <li class="nav-item">
                          
                                <button class="nav-link">   <i class="icon-logout"></i> Logout</button>
                            </li>
                        </ul>
                        </div><!-- /.user-item-order-list -->
                            <div class="side-bar-footer">
                               <div class="sidebar-loyalty-points">
                               <p>Loyalty Points&nbsp&nbsp  <span>00</span></p>
                               </div><!-- /.sidebar-loyalty-points -->
                               <div class="discount-referal-code">
                                    <b> <small>Referral Code</small> JohnDoe20</b>
                               </div><!-- /.discount-referal-code -->
                            </div><!-- /.side-bar-footer -->
                   </div><!-- /.user-panel-sidebar-inner -->

                </div><!-- /.left-col -->
                <div class="right-col">
                    <div class="user_order-detail-inner">
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="tab1" role="tabpanel" aria-labelledby="tab1">
                            <div class="user-panel-tc-inner">
                                <div class="tc-topstrip">
                                    <div class="tc-title">
                                    <h4><small>Welcome</small>John Doe</h4>
                                    </div>
                                    <div class="user-order-btn">
                                        <a href="#" class="theme-btn btn-black-theme place-order-btn">Place new order? <i class="icon-item-collection"></i> </a>
                                    </div>
                                </div><!-- /.tc-topstrip -->
                                <div class="user-order-cols order-details">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="order-col">
                                                    <h4>01<small>Live Orders</small></h4>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="order-col">
                                                    <h4>05<small>Completed Orders</small></h4>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="order-col">
                                                    <h4>02<small>Cancelled Orders</small></h4>
                                                </div>
                                            </div>
                                        </div>
                                </div><!-- /.user-order-cols -->
                            </div><!-- /.user-panel-tc-inner -->
                        </div>
                        <div class="tab-pane fade" id="tab2" role="tabpanel" aria-labelledby="tab2">
                        <div class="user-panel-tc-inner">
                                <div class="tc-topstrip">
                                    <div class="tc-title">
                                    <h4><small>Welcome</small>John Doe</h4>
                                    </div>
                                    <div class="user-order-btn">
                                        <a href="#" class="theme-btn btn-black-theme place-order-btn">Place new order? <i class="icon-item-collection"></i> </a>
                                    </div>
                                </div><!-- /.tc-topstrip -->
                                <div class="user-contact-details order-details">
                                    <form action="">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <div class="user-contact-col order-details-pod">
                                            <div class="step-title">
                                        <h4>Contact Details</h4>
                                    </div><!-- /.step-title -->
                                    <div class="pod-inner">
                                       <div class="row">
                                       <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="wizard-form-text-label">First Name</label>
                                                    <input type="text" class="form-control" placeholder="John">

                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="wizard-form-text-label">Last Name</label>
                                                    <input type="text" class="form-control" placeholder="Doe">

                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="wizard-form-text-label">Email Address</label>
                                                    <input type="email" class="form-control" placeholder="johndoe@gmail.com">

                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="wizard-form-text-label">Phone</label>
                                                    <input type="text" class="form-control" placeholder="123 456 789">

                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="wizard-form-text-label">Referral Code</label>
                                                    <p class="form-control referral-code">JohnDoe20</p>

                                                </div>
                                            </div>
                                       </div>
                                    </div><!-- /.pod-inner -->
                                            </div>
                                            
                                        </div>
                                        <div class="col-md-4">
                                            <div class="account-col order-details-pod">
                                            <div class="step-title">
                                        <h4>Change Password</h4>
                                    </div><!-- /.step-title -->
                                    <div class="pod-inner">
                                    <div class="form-group">
                                                    <label class="wizard-form-text-label">New Password</label>
                                                    <div class="fieldwd-icon">
                                                    <input type="password" class="form-control form-password-field"  placeholder="New Password*">
                                                    <i class="icon-eye-view form-field-icon toggle-password"></i>
                                                    </div><!-- /.fieldwd-icon -->
                                                </div>
                                                <div class="form-group">
                                                    <label class="wizard-form-text-label">Confirm New Password</label>
                                                     <div class="fieldwd-icon">
                                                     <input type="password" class="form-control form-password-field"  placeholder="Re-enter your new password*">
                                                    <i class="icon-eye-view form-field-icon toggle-password"></i>
                                                     </div><!-- /.fieldwd-icon -->
                                                </div>

                                                <button type="button" class="theme-btn btn-black-theme user-account-btn">Update</button>
                                    </div><!-- /.pod-inner -->
                                            </div>
                                            
                                        </div>
                                    </div>
                                    </form>
                                </div><!-- /.user-account-setting -->
                            </div><!-- /.user-panel-tc-inner -->
                        </div>
                        <div class="tab-pane fade" id="tab3" role="tabpanel" aria-labelledby="tab3">
                        <div class="user-panel-tc-inner">
                                <div class="tc-topstrip">
                                    <div class="tc-title">
                                    <h4><small>Welcome</small>John Doe</h4>
                                    </div>
                                    <div class="user-order-btn">
                                        <a href="#" class="theme-btn btn-black-theme place-order-btn">Place new order? <i class="icon-item-collection"></i> </a>
                                    </div>
                                </div><!-- /.tc-topstrip -->
                                <div class="payment-method-pod order-details-pod order-details">
                                    <div class="step-title">
                                        <h4>My Payment Cards</h4>
                                    </div><!-- /.step-title -->
                                    <div class="pod-inner">
                                        <i class="icon-no-card-record card-icon"></i>
                                        <p>No Card Records Found<a href="#" data-bs-toggle="modal" data-bs-target="#payCard"><b> Add Card</b></a></p>
                                    </div><!-- /.pod-inner -->
                                </div><!-- /.payment-method-pod -->
                            </div><!-- /.user-panel-tc-inner -->
                        </div>
                        <div class="tab-pane fade" id="tab4" role="tabpanel" aria-labelledby="tab4">
                        <div class="user-panel-tc-inner">
                                <div class="tc-topstrip">
                                    <div class="tc-title">
                                    <h4><small>Welcome</small>John Doe</h4>
                                    </div>
                                    <div class="user-order-btn">
                                        <a href="#" class="theme-btn btn-black-theme place-order-btn">Place new order? <i class="icon-item-collection"></i> </a>
                                    </div>
                                </div><!-- /.tc-topstrip -->
                                <div class="payment-method-pod order-details-pod order-details">
                                    <div class="step-title">
                                        <h4>Used Discount Codes</h4>
                                    </div><!-- /.step-title -->
                                    <div class="pod-inner">
                                        <p>No Discount Codes Used</p>
                                    </div><!-- /.pod-inner -->
                                </div><!-- /.payment-method-pod -->
                            </div><!-- /.user-panel-tc-inner -->
                        </div>
                        <div class="tab-pane fade" id="tab5" role="tabpanel" aria-labelledby="tab5">
                        <div class="user-panel-tc-inner">
                                <div class="tc-topstrip">
                                    <div class="tc-title">
                                    <h4><small>Welcome</small>John Doe</h4>
                                    </div>
                                    <div class="user-order-btn">
                                        <a href="#" class="theme-btn btn-black-theme place-order-btn">Place new order? <i class="icon-item-collection"></i> </a>
                                    </div>
                                </div><!-- /.tc-topstrip -->
                                <div class="payment-method-pod order-details-pod order-details">
                                    <div class="step-title">
                                        <h4>Loyalty program gives 25% discount every 6th wash</h4>
                                    </div><!-- /.step-title -->
                                    <div class="pod-inner">
                                        <p>No Discount Codes Used</p>
                                    </div><!-- /.pod-inner -->
                                </div><!-- /.payment-method-pod -->
                                <div class="payment-method-pod order-details-pod order-details">
                                    <div class="step-title">
                                        <h4>Loyality History</h4>
                                    </div><!-- /.step-title -->
                                    <div class="pod-inner">
                                        <p>No Loyalty Points</p>
                                    </div><!-- /.pod-inner -->
                                </div><!-- /.payment-method-pod -->
                            </div><!-- /.user-panel-tc-inner -->
                        </div>
                       
                    </div>
                    </div><!-- /.user_order-detail-inner -->
                </div><!-- /.right-col -->
            </div><!-- /.user_panel-Inner -->
        </div><!-- /.user_panel-wrap -->





        <!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade popup-pod" id="payCard" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
    <div class="modal-header">
        <h4 class="modal-title" id="staticBackdropLabel">Add New Card</h4>
        <i class="icon-cross btn-close-icon" data-bs-dismiss="modal" aria-label="Close"></i>
        <!-- <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
      </div>
      <div class="modal-body">
        <div class="new-card-details">
                            <div class="row">
                                       <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label class="wizard-form-text-label mb-1">Address Line 1</label>
                                                    <input type="text" class="form-control" placeholder="Address Line 1">

                                                </div>
                                            </div>
                                       <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label class="wizard-form-text-label mb-1">Address Line 2</label>
                                                    <input type="text" class="form-control" placeholder="Address Line 2">

                                                </div>
                                            </div>


                                            <div class="col-md-12">
                                                <div class="form-group mb-3">
                                                    <label class="wizard-form-text-label mb-1">Card Number</label>
                                                    <input type="text" class="form-control" placeholder="0000 0000 0000 0000">

                                                </div>
                                            </div>


                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label class="wizard-form-text-label mb-1">Expiry Date</label>
                                                    <input type="text" class="form-control" placeholder="MM / YY">

                                                </div>
                                            </div>
                                       <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label class="wizard-form-text-label mb-1">CVC</label>
                                                    <input type="text" class="form-control" placeholder="CVC">

                                                </div>
                                            </div>





                            </div>
      </div>
      <div class="modal-footer">
        <!-- <button type="button" class="theme-btn btn-green-theme" data-bs-dismiss="modal">Close</button> -->
        <button type="button" class="theme-btn btn-black-theme">Save</button>
      </div>
    </div>
  </div>
</div>







    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>