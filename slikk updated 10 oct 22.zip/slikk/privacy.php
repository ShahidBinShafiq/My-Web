<?php include 'incl/header.php'; ?>

    <main class="page__wrap">
        <div class="term-cond-wrap section-space">
           <div class="container-md">
               <div class="tac-wrap-inner">
                   <div class="tac-pag-title">
                       <h2>Privacy Policy</h2>
                   </div><!-- /.tac-pag-title -->
                   <div class="tac-description">
                        <p>This privacy policy applies to you, the User of this Website and Love2Laundry Ltd, the owner and provider of this Website and Application. Love2Laundry Ltd takes the privacy of your information very seriously. This privacy policy applies to our use of any and all Data collected by us or provided by you in relation to your use of the Website. <strong> Please read this privacy policy carefully.</strong></p>
                   </div><!-- /.tac-description -->

                   <div class="faq-accordions-wrap">
                    <div class="accordion" id="tac-accordion">
  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item1">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse1" aria-expanded="true" aria-controls="tac-collapse1">
      Definitions and interpretation
      </button>
    </h2>
    <div id="tac-collapse1" class="accordion-collapse collapse show" aria-labelledby="tac-item1" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item2">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse2" aria-expanded="false" aria-controls="tac-collapse2">
      The scope of this privacy policy
      </button>
    </h2>
    <div id="tac-collapse2" class="accordion-collapse collapse" aria-labelledby="tac-item2" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item3">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse3" aria-expanded="false" aria-controls="tac-collapse3">
      Data collected
      </button>
    </h2>
    <div id="tac-collapse3" class="accordion-collapse collapse" aria-labelledby="tac-item3" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item4">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse4" aria-expanded="false" aria-controls="tac-collapse4">
      Third party websites and services
      </button>
    </h2>
    <div id="tac-collapse4" class="accordion-collapse collapse" aria-labelledby="tac-item4" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>
  

  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item5">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse5" aria-expanded="false" aria-controls="tac-collapse5">
      Links to other websites
      </button>
    </h2>
    <div id="tac-collapse5" class="accordion-collapse collapse" aria-labelledby="tac-item5" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item6">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse6" aria-expanded="false" aria-controls="tac-collapse6">
      Changes of business ownership and control
      </button>
    </h2>
    <div id="tac-collapse6" class="accordion-collapse collapse" aria-labelledby="tac-item6" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item7">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse7" aria-expanded="false" aria-controls="tac-collapse7">
      Controlling use of your Data
      </button>
    </h2>
    <div id="tac-collapse7" class="accordion-collapse collapse" aria-labelledby="tac-item7" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item8">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse8" aria-expanded="false" aria-controls="tac-collapse8">
      Functionality of the Website
      </button>
    </h2>
    <div id="tac-collapse8" class="accordion-collapse collapse" aria-labelledby="tac-item8" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item9">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse9" aria-expanded="false" aria-controls="tac-collapse9">
      Accessing your own Data
      </button>
    </h2>
    <div id="tac-collapse9" class="accordion-collapse collapse" aria-labelledby="tac-item9" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item10">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse10" aria-expanded="false" aria-controls="tac-collapse10">
      Security
      </button>
    </h2>
    <div id="tac-collapse10" class="accordion-collapse collapse" aria-labelledby="tac-item10" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item11">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse11" aria-expanded="false" aria-controls="tac-collapse11">
      Cookies
      </button>
    </h2>
    <div id="tac-collapse11" class="accordion-collapse collapse" aria-labelledby="tac-item11" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item12">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse12" aria-expanded="false" aria-controls="tac-collapse12">
      Transfers outside the European Economic Area
      </button>
    </h2>
    <div id="tac-collapse12" class="accordion-collapse collapse" aria-labelledby="tac-item12" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item13">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse13" aria-expanded="false" aria-controls="tac-collapse13">
      General
      </button>
    </h2>
    <div id="tac-collapse13" class="accordion-collapse collapse" aria-labelledby="tac-item13" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item14">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse14" aria-expanded="false" aria-controls="tac-collapse14">
      Changes to this privacy policy
      </button>
    </h2>
    <div id="tac-collapse14" class="accordion-collapse collapse" aria-labelledby="tac-item14" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


 


</div>
                   </div><!-- /.faq-accordions-wrap-->
               </div><!-- /.tac-wrap-inner -->
           </div><!-- /.container-md -->
        </div><!-- /.term-cond-wrap -->
    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>