<?php include 'incl/header.php'; ?>

    <main class="page__wrap">
    <div class="page-banner contact-banner">
        <div class="page-banner-inner">


        <div class="contact-banner-cols">
          <div class="contact-banner-col col-left container-half">
            
          <div class="banner-title">
                <h1>Get in touch</h1>
                
            </div><!-- /.banner-title -->

            <div class="contact-modes">
                    <div class="mode-col">
                      <div class="mode-content">
                        <div class="mode-contact-inner">
                        <small>Connect to WhatsApp</small>
                        <b>07904 837030</b>
                        <small>WhatsApp 24/7</small>
                      </div>
                      <i class="icon-whatsapp"></i>
                      </div>
                    </div>
                    <div class="mode-col">
                      <div class="mode-content">
                        <div class="mode-contact-inner">
                        <small>Connect to Email</small>
                        <b>info@getslikk.co.uk</b>
                      </div>
                      <i class="icon-email"></i>
                      </div>
                    </div>
                    <div class="mode-col">
                      <div class="mode-content">
                        <div class="mode-contact-inner">
                        <small>Opening Hours</small>
                        <div class="days-timings">
                          <table>
                            <tr>
                              <td> <span>Mon-Fri</span></td>
                              <td> <b>8am-6pm</b></td>
                            </tr>
                            <tr>
                              <td> <span>Saturday</span></td>
                              <td> <b>9am-5pm</b></td>
                            </tr>
                            <tr>
                              <td> <span>Sunday</span></td>
                              <td> <b>Closed</b></td>
                            </tr>
                          </table>
                        </div>
                      </div>
                      <i class="icon-hours"></i>
                      </div>
                    </div>
                
                </div><!-- /.contact-modes -->

                <div class="email-form">
                  <div class="form-title">
                    <b>Send us an email</b>
                  </div>
                  <form action="">
                  <div class="mb-3">
                <input type="text" class="form-control form-pod"  placeholder="Your Name">
              </div>

              <div class="mb-3">
                <input type="text" class="form-control form-pod"  placeholder="Order Number">
              </div>

              <div class="mb-3">
                <input type="email" class="form-control form-pod"  placeholder="Email Address" required>
              </div>

              <div class="mb-4">
                <textarea class="form-control message-pod"  rows="5" placeholder="Message"></textarea>
              </div>

              <div class="message-btn">
              <button type="submit" class="theme-btn btn-black-theme">Send Message</button>
              </div>
                  </form>

                </div><!-- /.email-form -->


          </div>


          <div class="contact-banner-col col-right">
            <figure class="preview-item">

              <img class="img-view" src="assets/images/contact-img.png" alt="">
            </figure>

          </div>
        </div>

        </div><!-- /.page-banner-inner -->
    </div><!-- /.page-banner -->

    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>