<?php include 'incl/header.php'; ?>

    <main class="page__wrap">
            <!-- <canvas id="canvas"> </canvas> -->

        <div class="page-banner-wrapper">

                <div class="container-md">
                <div class="page-banner-inner">
                <div class="page-banner-title">
                        <div class="banner-title-inner">
                        <h2>Creative <span class="tg-lineare">Web Design &</span> <span class="tg-lineare-reverse">Digital </span>Agency London.</h2>
                        <p>Web Buds is a creative website design agency in London. A <b>team of talented web designers</b> in London.</p>
                            <a href="#">Start Your Project</a>


                            <div class="anim-cirlce">
                            <svg viewBox="0 0 100 100" width="100" height="100">
                                <defs>
                                    <path id="circle" d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"/>
                                </defs>
                                <text>
                                    <textPath xlink:href="#circle">
                                    We Create Fast websites
                                    </textPath>
                                </text>
                                </svg>
                            </div><!-- /.anim-cirlce -->
                       
                        </div>
                </div><!-- /.page-banner-title -->
                </div><!-- /.page-banner-inner -->
            </div><!-- /.container-md -->

            <span class="site-page-title">The&nbspSite Space</span>
        </div><!-- /.page-banner-wrapper -->

    </main><!--/.page__wrap-->


    <!-- <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br> -->

<?php include 'incl/footer.php'; ?>

