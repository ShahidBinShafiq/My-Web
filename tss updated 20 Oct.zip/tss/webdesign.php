<?php include 'incl/header.php'; ?>

    <main class="page__wrap">

        <main>
        <!-- <canvas id="canvas"> </canvas> -->

        <div class="page-banner-wrapper webdesign-page-banner cursor glow-one">
        <div class="cursor-glow"></div>


<div class="container-md">
<div class="page-banner-inner">
<div class="page-banner-title">
        <div class="banner-title-inner">
          
        <h2>Unparalleled <span class="tg-lineare">Customised</span> <span>Web Design. </span></h2>
        <p>We aim to make your dreams come true with our extensive experience and mad talent.</p>
            <!-- <a href="#" class="theme-btn">Start Your Project</a> -->

            <!-- <a href="#" class="theme-btn">
  <div class="btn-circle border-primary" >
    <div class="btn-circle border-primary">
    Start Your Project
    </div>  
  </div>
</a> -->

            <div class="anim-cirlce xl-hide">
            <svg viewBox="0 0 100 100" width="100" height="100">
                <defs>
                    <path id="circle" d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"/>
                </defs>
                <text>
                    <textPath xlink:href="#circle">
                    We Create Fast websites
                    </textPath>
                </text>
                </svg>
            </div><!-- /.anim-cirlce -->
       
        </div>
</div><!-- /.page-banner-title -->
</div><!-- /.page-banner-inner -->
</div><!-- /.container-md -->
<div class="site-page-title">
<span class="title-line1">CREATIVE</span>
<span class="title-line2">WEBSITE</span>
</div><!-- /.site-page-title -->
</div><!-- /.page-banner-wrapper -->

    <div class="web-design-process section-space cursor glow-one">
    <div class="cursor-glow"></div>

        <div class="container-md">
            <div class="web-design-porcess-inner">
                <div class="process-col">
                    <img src="assets/icons/project.svg" alt="">
                    <p>Project</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/prototyping.svg" alt="">
                    <p>Prototyping</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/development.svg" alt="">
                    <p>Development</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/testing.svg" alt="">
                    <p>Testing</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/deliver.svg" alt="">
                    <p>Delivery</p>
                </div>
               
            </div><!-- /.web-design-porcess-inner -->
        </div><!-- /.container-md -->
    </div><!-- /.web-design-process -->



    <div class="web-types-section">
        <div class="container-lg">
            <div class="web-types-section-inner">
                <div class="container-md">
                <div class="section-pod-title text-center">
                    <h4>We create all kinds of websites.</h4>
                    <p>A highly-skilled and experienced team that understands your requirements and turns them into online masterpieces.</p>
                </div>
                </div>
                <div class="type-pods-wrpper section-space">
                <div class="type-pod">
                    <div class="type-pod-hover">
                    <div class="type-pod-inner">
                    <div class="type-col col-left">
                        <div class="section-pod-title">
                        <h4>Brochure Websites</h4>
                        <p>A website to describe your business and services to your clients.</p>
                        </div>

                    </div>

                    <div class="type-col col-right">
                    <img src="assets/icons/brochure.svg" alt="">
                    </div>
                </div><!-- /.type-pod-inner -->
                    </div><!-- /.type-pod-hover -->
                </div><!-- /.type-pod -->
                <div class="type-pod">
                    <div class="type-pod-hover">
                    <div class="type-pod-inner">
                    <div class="type-col col-left">
                        <div class="section-pod-title">
                        <h4>Portfolio & Catalogue</h4>
                        <p>A website to exhibit your products without taking payment through it.</p>
                        </div>

                    </div>

                    <div class="type-col col-right">
                    <img src="assets/icons/portfolio.svg" alt="">
                    </div>
                </div><!-- /.type-pod-inner -->
                    </div><!-- /.type-pod-hover -->
                </div><!-- /.type-pod -->
                <div class="type-pod">
                    <div class="type-pod-hover">
                    <div class="type-pod-inner">
                    <div class="type-col col-left">
                        <div class="section-pod-title">
                        <h4>eCommerce Websites</h4>
                        <p>Switch your business online and relax. Enjoy a vast reach and higher sales.</p>
                        </div>

                    </div>

                    <div class="type-col col-right">
                    <img src="assets/icons/ecommerce.svg" alt="">
                    </div>
                </div><!-- /.type-pod-inner -->
                    </div><!-- /.type-pod-hover -->
                </div><!-- /.type-pod -->
                <div class="type-pod">
                    <div class="type-pod-hover">
                    <div class="type-pod-inner">
                    <div class="type-col col-left">
                        <div class="section-pod-title">
                        <h4>Blog & Magazine</h4>
                        <p>Write whatever you are passionate about and publish it online for the world to see.</p>
                        </div>

                    </div>

                    <div class="type-col col-right">
                    <img src="assets/icons/blog.svg" alt="">
                    </div>
                </div><!-- /.type-pod-inner -->
                    </div><!-- /.type-pod-hover -->
                </div><!-- /.type-pod -->
                <div class="type-pod">
                    <div class="type-pod-hover">
                    <div class="type-pod-inner">
                    <div class="type-col col-left">
                        <div class="section-pod-title">
                        <h4>Booking & Reservation</h4>
                        <p>Let your visitors book your services of hotels, salons, studios, transportation, etc., online. Taking online payments is optional.</p>
                        </div>

                    </div>

                    <div class="type-col col-right">
                    <img src="assets/icons/booking.svg" alt="">
                    </div>
                </div><!-- /.type-pod-inner -->
                    </div><!-- /.type-pod-hover -->
                </div><!-- /.type-pod -->
                <div class="type-pod">
                    <div class="type-pod-hover">
                    <div class="type-pod-inner">
                    <div class="type-col col-left">
                        <div class="section-pod-title">
                        <h4>Custom Applications</h4>
                        <p>A personalised web design to the tiniest bit, entirely built from scratch to suit your taste and requirements. A top-notch package for tip-top brands.</p>
                        </div>

                    </div>

                    <div class="type-col col-right">
                    <img src="assets/icons/applications.svg" alt="">
                    </div>
                </div><!-- /.type-pod-inner -->
                    </div><!-- /.type-pod-hover -->
                </div><!-- /.type-pod -->
                </div><!-- /.type-pods-wrpper -->
            </div><!-- /.web-types-section-inner -->
        </div><!-- /.container-lg -->
    </div><!-- /.web-types-section -->







        <div class="work-cols-wrapper section-space cursor circle-one">
        <div class="cursor-glow"></div>

            <div class="container-lg">
                         <div class="section-title section-title-white">
                            <h4><span>Our</span> Work</h4>
                        </div><!-- /.section-title -->
                    <div class="work-cols-inner">
           
                    <div class="figure-col work-col">
                      
                    <figure class="figure-item">
                            <img class="justifier__thumb" loading="lazy" src="assets/images/work-img-1.jpg" alt="">
                        </figure>
                    </div>
                    <div class="content-col work-col">

                        <div class="col-title">
                            <h4>Slice Ping Pong</h4>
                            <p>A great venue for ping pong, Table Foosball and Beer Pong Games</p>
                        </div><!-- /.col-title -->

                        <a href="#" id="theme-btn" class="theme-btn-move theme-btn-white">
                            <div class="slide one">View Project</div>
                            <div class="slide two"></div>
                        </a>
                    </div>
                </div><!-- /.work-cols-inner -->




                <div class="work-cols-inner flex-row-reverse">
           
           <div class="figure-col work-col">
             
                        <figure class="figure-item">
                            <img class="justifier__thumb" loading="lazy" src="assets/images/work-img-2.jpg" alt="">
                        </figure>
           </div>
           <div class="content-col work-col">

               <div class="col-title">
                   <h4>Team Triad</h4>
                   <p>Cultivating cultures of leadership excellence</p>
               </div><!-- /.col-title -->

               <a href="#" id="theme-btn" class="theme-btn-move theme-btn-white">
                            <div class="slide one">View Project</div>
                            <div class="slide two"></div>
                        </a>
           </div>
       </div><!-- /.work-cols-inner -->


                <div class="work-cols-inner">
           
           <div class="figure-col work-col">
             
                        <figure class="figure-item">
                            <img class="justifier__thumb" loading="lazy" src="assets/images/work-img-3.jpg" alt="">
                        </figure>
           </div>
           <div class="content-col work-col">

               <div class="col-title">
                   <h4>Apres Furniture</h4>
                   <p>We developed a beautiful eCommerce website for Après Furniture with lots of custom features.</p>
               </div><!-- /.col-title -->

                        <a href="#" id="theme-btn" class="theme-btn-move theme-btn-white">
                            <div class="slide one">View Project</div>
                            <div class="slide two"></div>
                        </a>
           </div>
       </div><!-- /.work-cols-inner -->


                <div class="work-cols-inner flex-row-reverse">
           
           <div class="figure-col work-col">
             
                        <figure class="figure-item">
                            <img class="justifier__thumb" loading="lazy" src="assets/images/work-img-4.jpg" alt="">
                        </figure>
           </div>
           <div class="content-col work-col">

               <div class="col-title">
                   <h4>Celsius Dynamics</h4>
                   <p>Revolutionary logistics solutions and cold chain distributions services</p>
               </div><!-- /.col-title -->

               <a href="#" id="theme-btn" class="theme-btn-move theme-btn-white">
                            <div class="slide one">View Project</div>
                            <div class="slide two"></div>
                        </a>
           </div>
       </div><!-- /.work-cols-inner -->
        <div class="view-projects-btn">

            <a href="#">View All Projects</a>
        </div>

            </div><!-- /.conainer-lg -->
        </div><!-- /.work-cols-wrapper -->

   

        <div class="testimonial-section section-space cursor glow-one">
        <div class="cursor-glow"></div>

            <div class="container-lg">
                <div class="testimonial-section-inner">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="usre-reviews-col col-left">
                            <div class="section-title">
                            <h4>Don’t leave out our 5-star reviews</h4>
                            </div><!-- /.section-title -->
                            <div class="reviews-content">
                                <p>Our utter devotion to our clients and their work plays a vital role in our success. We 
                                obsess over creating something unique and fresh that can do everything you want it to 
                                do. If you want class, we are your guys!</p>
                            </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="usre-reviews-col col-right">
                            <div class="swiper">

                                <div class="swiper-wrapper">

                                    <div class="swiper-slide">
                                        <div class="review-wrap">
                                            <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="reviews-footer">
                                    <div>
                                        <b>2021</b>
                                    </div>
                                    <div class="swiper-nav-icons">
                                        <div class="swiper-button-prev icon-arrow-left swiper-nav"></div>
                                        <div class="swiper-button-next icon-arrow-right swiper-nav"></div>
                               </div><!-- /.swiper-nav-icons -->
                                </div><!-- /.reviews-footer -->
                        </div><!--/.swiper-->

                            </div>
                        </div>
                    </div>
                </div><!-- /.testimonial-section-inner -->
            </div><!-- /.container-lg -->
        </div><!-- /.testimonial-section -->


   

        </main>

    </main><!--/.page__wrap-->


    <!-- <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br> -->

<?php include 'incl/footer.php'; ?>

