<div class="header-border">
<?php include 'incl/header.php'; ?>

</div>
    <main class="page__wrap">

        <main>
        <div class="contact-page-wrap">
            <img class="contact-bg" src="./assets/images/contact-bg.jpg" alt="">
            <div class="container-md">
                <div class="contact-inner">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="contact-col col-left">
                                <div class="contact-col-title">
                                    <h4>Feel free to <br> get in touch</h4>
                                </div>
                                <div class="social-links">
                                    <ul>
                                        <li>
                                            <a href="#" class="social-link">
                                                <i class="icon-instagram"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#" class="social-link">
                                                <i class="icon-linked-in"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#" class="social-link">
                                                <i class="icon-twitter"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#" class="social-link">
                                                <i class="icon-facebook"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="email-link">
                                    <a href="#">enquiries@thesitespace.com</a>
                                </div><!-- /.email-link -->
                                <div class="address-pod">
                                    <b>London</b>
                                        
                                    <span>Unit 208</span>
                                    <span>Pill Box Studios</span>
                                    <span>115 Coventry Rd</span>
                                    <span>London</span>
                                    <span>E2 6GG</span>
                                </div><!-- /.address-pod -->
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="contact-col col-right">
                            <div class="contact-col-title">
                                    <h4>Let's Create <br> Something Megical</h4>
                                </div>
                            <div class="cunsultation-form">
                        <form action="">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="floatingInput" placeholder="Name">
                            <label for="floatingInput">Name</label>
                            </div>
                            <div class="form-floating">
                            <input type="email" class="form-control" id="floatingPassword" placeholder="Email">
                            <label for="floatingPassword">Email</label>
                            </div>
                            <div class="form-floating">
                            <input type="text" class="form-control" id="floatingInput" placeholder="Name">
                            <label for="floatingInput">Contact number</label>
                            </div>
                            <div class="form-floating">
                            <input type="text" class="form-control" id="floatingInput" placeholder="Name">
                            <label for="floatingInput">Business name</label>
                            </div>
                            <div class="form-floating">
                            <input type="text" class="form-control" id="floatingInput" placeholder="Name">
                            <label for="floatingInput">Current website</label>
                            </div>
                            <div class="form-floating">
                            <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea"></textarea>
                            <label for="floatingTextarea">Type your message</label>
                            </div>


                            <a href="#" id="theme-btn" class="theme-btn-move">
                            <div class="slide one">Submit</div>
                            <div class="slide two"></div>
                        </a>
                        </form>
                    </div><!-- /.cunsultation-form -->
                            </div>
                        </div>
                    </div>
                </div><!-- /.contact-inner -->
            </div><!-- /.container md -->
        </div><!-- /.contact-page-wrap -->


        </main>

    </main><!--/.page__wrap-->



    <div class="no-footer">
    <?php include 'incl/footer.php'; ?>
    </div>

