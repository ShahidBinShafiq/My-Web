<?php include 'incl/header.php'; ?>

    <main class="page__wrap">

        <main>
        <!-- <canvas id="canvas"> </canvas> -->

        <div class="page-banner-wrapper home-page-banner">
        <!-- <div class="cursor-glow"></div> -->
<div class="container-md">
<div class="page-banner-inner">
<div class="page-banner-title">
        <div class="banner-title-inner">
        <h2>Creative <span class="tg-lineare">Web Design & </span> <span class="tg-lineare-reverse">Digital </span>Agency London.</h2>
        <p>The Site Space is a London-based agency that combines the skills and talent of web designers and developers to create fresh and classy websites.</p>


<a href="javascript:void(0);" id="theme-btn" class="theme-btn-move">
  <div class="slide one">Start Your Project</div>
  <div class="slide two"></div>
</a>



            <div class="anim-cirlce xl-hide">
            <svg viewBox="0 0 100 100" width="100" height="100">
                <defs>
                    <path id="circle" d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"/>
                </defs>
                <text>
                    <textPath xlink:href="#circle">
                    We Create Fast websites
                    </textPath>
                </text>
                </svg>
            </div><!-- /.anim-cirlce -->
       
        </div>
</div><!-- /.page-banner-title -->

</div><!-- /.page-banner-inner -->
</div><!-- /.container-md -->
<div class="container-lg">
    <div class="anim-arrows">
    <figure class="arrow-group-down">
<img src="assets/icons/arrow-group-down.svg" alt="">
</figure>
    </div>
</div>
<span class="site-page-title">The&nbspSite Space</span>
</div><!-- /.page-banner-wrapper -->

    <div class="brand-info-wrapper section-space">
        <div class="brand-info-inner agency-info-cols">
            <div class="info-content-col info-col container-lg-half ms-auto">
                <div class="info-col-title">
                    <h4><small>ALL IN ONE</small>Web Design, App Development, and Digital Services Agency.</h4>
                </div>
                <p>We are based in the city of dreams - London, where no dream is too big to follow. Make an impression with our bespoke websites that define your business accurately. If your clients can relate to your website, half your work is done.</p>
            </div>
            <div class="info-figure-col info-col">
                <figure class="figure-item">
                    <img class="justifier__thumb" loading="lazy" src="assets/images/brand-info-fig.jpg" alt="">
                </figure>
            </div>
        </div><!-- /.brand-info-inner -->
    </div><!-- /.brand-info-wrapper -->

        <div class="work-cols-wrapper section-space bg-body-black">
            <div class="container-lg">
                         <div class="section-title section-title-white">
                            <h4><span>Our</span> Work</h4>
                        </div><!-- /.section-title -->
                    <div class="work-cols-inner">
           
                    <div class="figure-col work-col">
                      
                        <figure class="figure-item">
                            <img class="justifier__thumb" loading="lazy" src="assets/images/work-img-1.jpg" alt="">
                        </figure>
                    </div>
                    <div class="content-col work-col">

                        <div class="col-title">
                            <h4>Slice Ping Pong</h4>
                            <p>A delightful venue for Ping Pong, Table Foosball, and Beer Pong games</p>
                        </div><!-- /.col-title -->

                 
                        <a href="javascript:void(0);" id="theme-btn" class="theme-btn-move theme-btn-white">
                            <div class="slide one">View Project</div>
                            <div class="slide two"></div>
                        </a>

                        

                        
                    </div>
                </div><!-- /.work-cols-inner -->




                <div class="work-cols-inner flex-row-reverse">
           
           <div class="figure-col work-col">
             
               <figure class="figure-item">
                   <img class="justifier__thumb" loading="lazy" src="assets/images/work-img-2.jpg" alt="">
               </figure>
           </div>
           <div class="content-col work-col">

               <div class="col-title">
                   <h4>Team Triad</h4>
                   <p>Nurturing leadership skills to procure excellence</p>
               </div><!-- /.col-title -->

               <a href="javascript:void(0);" id="theme-btn" class="theme-btn-move theme-btn-white">
                            <div class="slide one">View Project</div>
                            <div class="slide two"></div>
                        </a>
           </div>
       </div><!-- /.work-cols-inner -->


                <div class="work-cols-inner">
           
           <div class="figure-col work-col">
             
               <figure class="figure-item">
                   <img class="justifier__thumb" loading="lazy" src="assets/images/work-img-3.jpg" alt="">
               </figure>
           </div>
           <div class="content-col work-col">

               <div class="col-title">
                   <h4>Apres Furniture</h4>
                   <p>Developing bespoke furniture that portrays your personality</p>
               </div><!-- /.col-title -->

                        <a href="javascript:void(0);" id="theme-btn" class="theme-btn-move theme-btn-white">
                            <div class="slide one">View Project</div>
                            <div class="slide two"></div>
                        </a>
           </div>
       </div><!-- /.work-cols-inner -->


                <div class="work-cols-inner flex-row-reverse">
           
           <div class="figure-col work-col">
             
               <figure class="figure-item">
                   <img class="justifier__thumb" loading="lazy" src="assets/images/work-img-4.jpg" alt="">
               </figure>
           </div>
           <div class="content-col work-col">

               <div class="col-title">
                   <h4>Celsius Dynamics</h4>
                   <p>Assisting you with ingenious logistics solutions and cold chain distribution services</p>
               </div><!-- /.col-title -->

               <a href="javascript:void(0);" id="theme-btn" class="theme-btn-move theme-btn-white">
                            <div class="slide one">View Project</div>
                            <div class="slide two"></div>
                        </a>
           </div>
       </div><!-- /.work-cols-inner -->
        <div class="view-projects-btn">

            <a href="javascript:void(0);">View All Projects</a>
        </div>

            </div><!-- /.conainer-lg -->
        </div><!-- /.work-cols-wrapper -->

        <div class="svc-info-wrapper section-space brand-svcs-wrap">
            <div class="container-lg">
                <div class="section-title">
                            <h4><span>Our</span> Services</h4>
                        </div><!-- /.section-title -->
                </div><!-- /.container-lg -->

        <div class="brand-info-inner svc-info-inner agency-info-cols flex-row-reverse">
            <div class="info-content-col info-col container-lg-half me-auto">
                <div class="svcs-list" id="our-services">



                   <ul>
                        <li  data-img='./assets/images/svc-img-1.jpg'>
                        <div class='sv-item'>
                                <span>Custom Web Design.<small>WordPress, Laravel, React JS, WooCommerce, Shopify, Magento</small></span>
                            </div>
                        </li>
                        <li  data-img='./assets/images/svc-img-2.jpg'>
                        <div class='sv-item'>
                                <span>Digital Marketing.<small>Search Engine Optimization (SEO), Social Media, PPC, Video Marketing</small></span>
                            </div>
                        </li  >
                        <li data-img='./assets/images/svc-img-3.jpg'>
                            <div class='sv-item'>
                                <span>Branding & UI/UX Design.<small>UI/UX Design, Brand Identity, Social Media Designs</small></span>
                            </div>
                        </li >
                        <li data-img='./assets/images/svc-img-4.jpg'>
                            <div class='sv-item'>
                                <span>Mobile App Development<small>Wordpress, Laravel. Shopify, WooCommerce, React JS, Magento</small></span>
                            </div>
                        </li>
                        <li data-img='./assets/images/svc-img-5.jpg'>
                            <div class='sv-item'>
                                <span>Content Creation.<small>Website Content, Blog Posts, Article Writing, Guest Posts</small></span>
                            </div>
                        </li>
                        <li data-img='./assets/images/svc-img-6.jpg'>
                            <div class='sv-item'>
                                <span>Web App Development<small>UI/UX Design, Brand Identity, Social Media Designs</small></span>
                            </div>
                        </li>
                    </ul>
                </div><!-- /.svcs-list -->
            </div>
            <div class="info-figure-col info-col" id="sv-item-preview">
                <figure class="figure-item">
                    <img id='previewItem' class="justifier__thumb" loading="lazy" src="" alt="">
                </figure>
            </div>
        </div><!-- /.brand-info-inner -->
    </div><!-- /.svc-info-wrapper -->

        <div class="testimonial-section">
            <div class="container-lg">
                <div class="testimonial-section-inner">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="usre-reviews-col col-left">
                            <div class="section-title">
                            <h4>Don’t leave out our 5-star reviews</h4>
                            </div><!-- /.section-title -->
                            <div class="reviews-content">
                                <p>Our utter devotion to our clients and their work plays a vital role in our success. We 
                                obsess over creating something unique and fresh that can do everything you want it to 
                                do. If you want class, we are your guys!</p>
                            </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="usre-reviews-col col-right">
                            <div class="swiper">

                                <div class="swiper-wrapper">

                                    <div class="swiper-slide">
                                        <div class="review-wrap">
                                            <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                             
                                <div class="reviews-footer">
                                    <div>
                                        <b>2021</b>
                                    </div>
                                    <div class="swiper-nav-icons">
                                        <div class="swiper-button-prev icon-arrow-left swiper-nav"></div>
                                        <div class="swiper-button-next icon-arrow-right swiper-nav"></div>
                               </div><!-- /.swiper-nav-icons -->
                                </div><!-- /.reviews-footer -->
                        </div><!--/.swiper-->
                        
                            </div>
                        </div>
                    </div>
                </div><!-- /.testimonial-section-inner -->
            </div><!-- /.container-lg -->
        </div><!-- /.testimonial-section -->


            <div class="blogs-section section-space">
                <div class="container-lg">
                    <div class="blogs-section-inner">
                        <div class="title-pod">
                        <div class="section-title">
                            <h4><span>Our Latest</span>Blogs</h4>
                        </div><!-- /.section-title -->
                            <div class="blog-btn-pod">
                            <a href="javascript:void(0);" id="theme-btn" class="theme-btn-move">
                            <div class="slide one">View All Blogs</div>
                            <div class="slide two"></div>
                        </a>
                                <!-- <a href="#" class="theme-btn">View All Blogs</a> -->
                            </div>
                        </div>

                        <div class="blogs-cols">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="blog-col">
                                        <figure class="figure-item">
                                            <img class="justifier__thumb" loading="lazy" src="assets/images/blog-img-1.jpg" alt="">
                                            <div class="circle-complete-anim">
                               
                                                    <svg version="1.1" id="social-icons" class="svg-circle" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
                                                    y="0px" viewBox="0 0 24 24" style="enable-background:new 0 0 24 24;" xml:space="preserve">
                                               
                                                <circle id="circle" class="st0" cx="12" cy="12" r="10.5"/>

                                                </svg>
                                            </div><!-- /.circle-complete-anim -->
                                        </figure>
                                        <div class="blog-post-cols">
                                            <div class="post-time-col">
                                                <b>19:03</b><sup>2022</sup>
                                            </div>
                                            <div class="post-content-col">
                                                <p>7 Key Benefits of Pay Monthly Website : Your business doesn’t get the representation it needs in today’s world without a website.</p>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="blog-col">

                                    <figure class="figure-item">
                                        <img class="justifier__thumb" loading="lazy" src="assets/images/blog-img-2.jpg" alt="">
                                        <div class="circle-complete-anim">
                             
                                                    <svg version="1.1" id="social-icons" class="svg-circle" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
                                                    y="0px" viewBox="0 0 24 24" style="enable-background:new 0 0 24 24;" xml:space="preserve">
                                            
                                                <circle id="circle" class="st0" cx="12" cy="12" r="10.5"/>

                                                </svg>
                                            </div><!-- /.circle-complete-anim -->
                                    </figure>

                                        <div class="blog-post-cols">
                                            <div class="post-time-col">
                                                <b>05:10</b><sup>2021</sup>
                                            </div>
                                            <div class="post-content-col">
                                                <p>Bad Website Design: Are You Making These Web Design Mistakes? You spend hours designing the perfect website.</p>
                                            </div>
                                        </div>

                              

                                    </div>
                                </div>
                             
                            </div>
                        </div><!-- /.blogs-cols -->

                    </div><!-- /.blogs-section-inner -->
                </div><!-- /.congainer-lg -->
            </div><!-- /.blogs-section -->

        </main>

    </main><!--/.page__wrap-->


    <!-- <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br> -->

<?php include 'incl/footer.php'; ?>

