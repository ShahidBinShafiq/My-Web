<?php include 'incl/header.php'; ?>

    <main class="page__wrap">
        <div class="page-banner-wrapper">
            <div class="container-md">
                <div class="page-banner-inner">
                <div class="page-banner-title">
                        <div class="banner-title-inner">
                        <h2>Creative <span>Web Design &</span> <span>Digital </span>Agency London.</h2>
                        <p>Web Buds is a creative website design agency in London. A team of talented web designers in London.</p>
                        
                        </div>
                </div><!-- /.page-banner-title -->
                </div><!-- /.page-banner-inner -->
            </div><!-- /.container-md -->
            <span class="site-page-title">The&nbspSite Space</span>
        </div><!-- /.page-banner-wrapper -->

    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>