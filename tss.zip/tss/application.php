<?php include 'incl/header.php'; ?>

    <main class="page__wrap">

        <main>
        <!-- <canvas id="canvas"> </canvas> -->

        <div class="page-banner-wrapper marketing-page-banner">

<div class="container-md">
<div class="page-banner-inner">
<div class="page-banner-title">
        <div class="banner-title-inner">

        <h2>Mobile <span class="tg-lineare">Application</span> <br> <span class="tg-lineare-reverse">Development</span> <span>Agency. </span></h2>
        <p>Mobile apps that offer effortless accessibility to your services without logging into a 
        computer. </p>
            <!-- <a href="#" class="theme-btn">Start Your Project</a> -->

            <!-- <a href="#" class="theme-btn">
  <div class="btn-circle border-primary" >
    <div class="btn-circle border-primary">
    Start Your Project
    </div>  
  </div>
</a> -->

            <div class="anim-cirlce xl-hide">
            <svg viewBox="0 0 100 100" width="100" height="100">
                <defs>
                    <path id="circle" d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"/>
                </defs>
                <text>
                    <textPath xlink:href="#circle">
                    We Create Fast websites
                    </textPath>
                </text>
                </svg>
            </div><!-- /.anim-cirlce -->
       
        </div>
</div><!-- /.page-banner-title -->
</div><!-- /.page-banner-inner -->
</div><!-- /.container-md -->
<div class="site-page-title">
<span class="title-line1">Mobile</span>
<span class="title-line2">Application</span>
</div><!-- /.site-page-title -->
</div><!-- /.page-banner-wrapper -->

<div class="web-design-process section-space">
        <div class="container-md">
            <div class="web-design-porcess-inner">
                <div class="process-col">
                    <img src="assets/icons/project.svg" alt="">
                    <p>Apps concept <br> & roadmap</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/prototyping.svg" alt="">
                    <p>App design <br> & prototyping</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/development.svg" alt="">
                    <p>Apps development <br> process</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/testing.svg" alt="">
                    <p>User testing of <br> the app and fixes</p>
                </div>
                <div class="process-col">
                    <img src="assets/icons/app-launch.svg" alt="">
                    <p>App launch <br> & support</p>
                </div>
               
            </div><!-- /.web-design-porcess-inner -->
        </div><!-- /.container-md -->
    </div><!-- /.web-design-process -->



    <div class="web-types-section mobile-app">
        <div class="container-lg">
            <div class="web-types-section-inner">
                <div class="container-md">
                <div class="section-pod-title text-center">
                    <h4>Unparalleled Application Development</h4>
                    <p>Mobile applications open new doors of digital success for your business. Our 
                        exceptional and smart mobile apps can do wonders for your business. The always-
                        increasing market of mobile users can access your business and services with a few 
                        taps on the screen. Mobile applications can be a highly effective marketing tool if done 
                        right. So don’t hold back and let the world be your oyster.</p>
                </div>
                </div>
                <div class="type-pods-wrpper section-space">
                <div class="type-pod">
                    <div class="type-pod-hover">
                    <div class="type-pod-inner">
                    <div class="type-col col-left">
                        <div class="section-pod-title">
                        <h4>Native Mobile</h4>
                        <p>With better quality and higher reliability, native mobile apps are designed for specific 
                        platforms ensuring excellence.</p>
                        </div>

                    </div>

                    <div class="type-col col-right">
                    <img src="assets/icons/native.svg" alt="">
                    </div>
                </div><!-- /.type-pod-inner -->
                    </div><!-- /.type-pod-hover -->
                </div><!-- /.type-pod -->
                <div class="type-pod">
                    <div class="type-pod-hover">
                    <div class="type-pod-inner">
                    <div class="type-col col-left">
                        <div class="section-pod-title">
                        <h4>Hybrid Mobile Apps</h4>
                        <p>A blend of native and web apps with no requirement of a specific platform to perform.</p>
                        </div>

                    </div>

                    <div class="type-col col-right">
                    <img src="assets/icons/hybrid.svg" alt="">
                    </div>
                </div><!-- /.type-pod-inner -->
                    </div><!-- /.type-pod-hover -->
                </div><!-- /.type-pod -->
                <div class="type-pod">
                    <div class="type-pod-hover">
                    <div class="type-pod-inner">
                    <div class="type-col col-left">
                        <div class="section-pod-title">
                        <h4>Web Apps</h4>
                        <p>Requiring a web browser, web apps are the opposite of native apps and much more 
                        cost-effective too.</p>
                        </div>

                    </div>

                    <div class="type-col col-right">
                    <img src="assets/icons/web-apps.svg" alt="">
                    </div>
                </div><!-- /.type-pod-inner -->
                    </div><!-- /.type-pod-hover -->
                </div><!-- /.type-pod -->
         
   
           
          
        
                </div><!-- /.type-pods-wrpper -->
            </div><!-- /.web-types-section-inner -->
        </div><!-- /.container-lg -->
    </div><!-- /.web-types-section -->

    <div class="seo-services-detail-section">
        <div class="container-md">
            <div class="seo-services-detail-inner">
            <div class="section-pod-title text-center">
                        <h4>Mobile applications and their superior intelligence</h4>
                        <p>Mobile app development is a massive market that keeps increasing. If done right, it can 
                        make your business. However, it is not as simple as one might think. Mobile app 
                        development is an art that fuses together design, strategy, marketing, analytics, and of 
                        course, development to create a masterpiece. Our developers add value to this artistry 
                        and make sure that our smart apps outshine all others. So, let’s get cracking.</p>
                        </div>

                <div class="seo-services-cols">
                    <div class="seo-services-cols-inner">
                        <div class="svc-col">
                        <img src="assets/icons/travel-app.svg" alt="">
                        <p>Travel & Booking <br> Apps</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/delivery-app.svg" alt="">
                        <p>Food Delivery <br> Apps</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/realestate-app.svg" alt="">
                        <p>Real Estate <br> Apps</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/taxi-app.svg" alt="">
                        <p>Taxi Apps</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/trading-app.svg" alt="">
                        <p>Forex Trading <br> Apps</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/ecommerce-app.svg" alt="">
                        <p>eCommerce <br> Apps</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/educational-app.svg" alt="">
                        <p>Learning& <br> Education Apps</p>
                        </div>
                        <div class="svc-col">
                        <img src="assets/icons/health-app.svg" alt="">
                        <p>Health & <br> Wellness Apps</p>
                        </div>
                    </div><!-- /.seo-services-cols-inner -->
                </div><!-- /.seo-services-cols -->
            </div><!-- /.seo-services-detail-inner -->
        </div><!-- /.container-md -->
    </div><!-- /.seo-services-detail-section -->




        <div class="testimonial-section section-space">
            <div class="container-lg">
                <div class="testimonial-section-inner">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="usre-reviews-col col-left">
                            <div class="section-title">
                            <h4>Don’t leave out our 5-star reviews</h4>
                            </div><!-- /.section-title -->
                            <div class="reviews-content">
                                <p>Our utter devotion to our clients and their work plays a vital role in our success. We 
                                obsess over creating something unique and fresh that can do everything you want it to 
                                do. If you want class, we are your guys!</p>
                            </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="usre-reviews-col col-right">
                            <div class="swiper">

                                <div class="swiper-wrapper">

                                    <div class="swiper-slide">
                                        <div class="review-wrap">
                                        <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                    <i class="icon-quotes"></i>
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="reviews-footer">
                                    <div>
                                        <b>2021</b>
                                    </div>
                                    <div class="swiper-nav-icons">
                                        <div class="swiper-button-prev icon-arrow-left swiper-nav"></div>
                                        <div class="swiper-button-next icon-arrow-right swiper-nav"></div>
                               </div><!-- /.swiper-nav-icons -->
                                </div><!-- /.reviews-footer -->

                        </div><!--/.swiper-->

                            </div>
                        </div>
                    </div>
                </div><!-- /.testimonial-section-inner -->
            </div><!-- /.container-lg -->
        </div><!-- /.testimonial-section -->


   

        </main>

    </main><!--/.page__wrap-->


    <!-- <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br> -->

<?php include 'incl/footer.php'; ?>

