import Banner from "../components/Banner"
import Header from "../components/Header"





const Home = ()=> {
  return (
    <div className="page-wrapper">
        <Header/>
        <Banner/>
        This is Home Page
    </div>
  )
}

export default Home