import Header from "../components/Header"





const Cart = ()=> {
  return (
    <div>
        <Header/>
        Cart</div>
  )
}

export default Cart