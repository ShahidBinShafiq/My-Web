import './App.css';
import Home from "./pages/Home"
import Contact from './pages/Contact';
import Services from './pages/Services';
import Gallery from './pages/Gallery';
import Blogs from './pages/Blogs';
import Products from './pages/Products';
import {BrowserRouter as Router, Routes, Route} from "react-router-dom";


function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/contact" element={<Contact/>}/>
          <Route path="/services" element={<Services/>}/>
          <Route path="/gallery" element={<Gallery/>}/>
          <Route path="/blogs" element={<Blogs/>}/>
          <Route path="/products" element={<Products/>}/>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
