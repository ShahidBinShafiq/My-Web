

import Headerstrip from "../components/header/Headerstrip"
import Cards from "../components/Cards"
import Slider from "../components/Slider"

const Services = () => {
  return (
    <div className="page-wrapper">
          <div className="header-component">
               <Headerstrip/>
            </div>
        <div className="services-wrap">
        <div className="container">
            <div className="services-inner">

                <h1>This is Services Page</h1>
            </div>
        </div>
    </div>

    <div className="card-pods">
      <Cards/>
    </div>

    <div className="site-slider">
              <Slider/>
          </div>

    </div>// .page-wrapper
  )
}

export default Services