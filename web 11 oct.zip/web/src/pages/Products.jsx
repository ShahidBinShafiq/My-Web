
import {useState} from "react";
import Headerstrip from "../components/header/Headerstrip"


const Products = () => {

    const [products, setProducts] = useState([
        {
            id: 1,
            title: "Single Bed Sheet",
            productImg: "../images/slider1.png",
            features:{
                  feature: "(Wash & iron) 2x Sheets",
                  feature: "D Cover & P Case"  
            },
            price: "£2.00",
            
            basicvalue: 0,
            
        },

        {
            id: 2,
            title: "Double Bed Sheet",
            productImg: "../images/slider2.jpg",
            features:{
                  feature: "(Wash & iron) B Sheet",
                  feature: "Wash & Iron (Hung)"  
            },
            price: "£1.87",
         
            basicvalue: 0,
        },

        {
            id: 3,
            title: "1x Bed Sheet",
            productImg: "../images/slider1.png",
            features:{
                  feature: "Dry Clean) 2 Piece Suit + 5 Shirts (Hung)",
                  feature: "D Cover & P Case"  
            },
            price: "£2.15",
           
            basicvalue: 0,
        },

        {
            id: 4,
            title: "2x Bed Sheets",
            productImg: "../images/slider1.png",
            features:{
                  feature: "(Dry Clean) Exl velvet, seq, silk & leather",
                  feature: "D Cover & P Case"  
            },
            price: "£3.00",
            basicvalue: 0,
        },

        


    ])
    

    function decrement(){
        // setProducts(products.basicvalue - 1)
    }

    function increment(){
        // setProducts(products.basicvalue + 1)
    }




  return (
    <div className="page-wrap">
           <div className="header-component">
               <Headerstrip/>
            </div>
        <div className="products-wrap section-space">
            <div className="container">
                <div className="products-inner">
                    
                    <div className="row">
                        {
                            products.map((product)=>{
                                return(
                                   <div className="col-md-3">
                                    <div class="card">
                                        <img src={product.productImg} class="card-img-top" alt="..."/>
                                        <div class="card-body">
                                
                                            <h5 class="card-title">{product.title}</h5>
                                            <ul>
                                                
                                              
                                                            <li>{product.features.feature}</li>
                                                        
                                                                                                  
                                                    
                                            </ul>
                                            <b>{product.price}</b>
                                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                             <button onClick={decrement}>-</button>
                                             <span>{product.basicvalue}</span>
                                             <button onClick={increment}>+</button>
                                        </div>
                                        </div>
                                   </div>
                                )
                            })
                        }
                    </div>





                </div>
            </div>
        </div>
    </div>
  )
}

export default Products