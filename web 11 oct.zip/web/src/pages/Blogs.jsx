
import Headerstrip from "../components/header/Headerstrip"
import Slider from "../components/Slider"
import Cards from "../components/Cards"


const Blogs = () => {
  return (
    <div className='page-wrapper'>

            <div className="header-component">
               <Headerstrip/>
            </div>


        <div className="blogs-wrap">
            <div className="container">
                <div className="blogs-inner">
                    <h1>This is Blogs Page</h1>
                </div>
            </div>
        </div>

      <div className="site-slider">
        <Slider/>
      </div>


      <div className="card-pods">
      <Cards/>
    </div>
    </div>
  )
}

export default Blogs