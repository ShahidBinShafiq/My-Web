import Headerstrip from "../components/header/Headerstrip"

import Slider from "../components/Slider"

import Cards from "../components/Cards"


const Home = ()=> {
  return (
    <div className="page-wrapper">

<div className="header-component">
               <Headerstrip/>
            </div>

        <div className="site-home-page">
        <div className="container">
            <div className="site-home-page-inner">
                <h1>This is Home Page</h1>
            </div>
        </div>
    </div>


          <div className="site-slider">
              <Slider/>
          </div>

        <div>
            <Cards/>
        </div>
    </div>
  )
}

export default Home
