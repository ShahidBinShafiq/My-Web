import { Link } from "react-router-dom"


const Logo = ()=> {
  return (
    <div>
        <h1>
            <Link to="/">Slikk</Link>
        </h1>
    </div>
  )
}

export default Logo