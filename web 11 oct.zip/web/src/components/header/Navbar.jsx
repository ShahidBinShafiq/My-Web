import { useState } from "react";
import { Link } from "react-router-dom";
import Logo from "./Logo";

const Navbar = () => {
  const [navitem, setNavitem] = useState([
    {
      title: "Home",
      path: "/",
    },
    {
      title: "Contact",
      path: "/contact",
    },
    {
      title: "Services",
      path: "/services",
    },
    {
      title: "Gallery",
      path: "/gallery",
    },
    {
      title: "Blogs",
      path: "/blogs",
    },
    {
      title: "Products",
      path: "/products",
    },
  ]);

  return (
    <div>
      <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">
            <Logo />
          </a>
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div className="site-nav">
              <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
                {navitem.map((i, index) => {
                  return (
                    <li className="nav-item">
                      <Link to={i.path} className="nav-link active">{i.title}</Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
