<?php include 'incl/header.php'; ?>

    <main class="page__wrap" id="home_page">
        <div class="home-page-banner">
            <div class="page-banner">
                <div class="container-md">
                    <div class="page-banner-inner">
                        <div class="banner-col banner-left-col">
                            <div class="banner-title">
                                <h1>Working? Studying? Haven’t got time? Slikk gets the washing done for you!</h1>
                                <p>An Affordable, Sustainable & Eco-Friendly Laundry Collection & Delivery Service</p>
                                <div class="section-btn">
                                    <a href="item-selection.php" class="theme-btn btn-green-theme section-icon-btn">Order Now <i class="icon-order-now"></i> </a>
                                </div><!-- /.search-box -->
                                <p>We collect, clean & return at a time and location of your choice.</p>
                            </div><!-- /.banner-title -->
                        </div><!-- /.banner-col -->

                        <div class="banner-col banner-right-col">
                            <div class="banner-figure">
                                <figure>
                                    <img src="assets/images/banner-img.png" alt="" class="banner-boy mb-hide">
                                </figure>
                            </div><!-- /.banner-figure -->
                        </div><!-- /.banner-col -->

                    </div><!-- /.page-banner-inner -->
                </div><!-- /.container -->
            </div><!-- /.page-banner -->
        </div><!-- /.home-page-banner -->


        <div class="reviews-section">
            <div class="container-md">
                <div class="reviews-section-inner">
                    <div class="section-title">
                        <h4>Excellent <br> Reviews</h4>
                        <img src="assets/images/five-star.svg" alt="">
                    </div>
                </div> <!-- /.reviews-section-inner -->
            </div><!-- /.container -->
        </div><!-- /.reviews-section -->

        <div class="work-section section-space">
            <div class="container-sm">
                <div class="work-section-inner">
                    <div class="section-title center-text">
                        <h4>How it works?</h4>
                    </div><!-- /.section-title -->

                    <div class="flow-cols">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="flow-col box-shadow">
                                    <figure>
                                        <img src="assets/images/collection.svg" alt="">
                                    </figure>
                                    <figcaption>
                                        <b>Collection</b>
                                        <p>Our easy-to-use booking system makes scheduling a collection for your items simple and convenient</p>
                                    </figcaption>
                                </div><!-- /.flow-col -->
                            </div>

                            <div class="col-md-4">
                                <div class="flow-col box-shadow">
                                    <figure>
                                        <img src="assets/images/w-machine.svg" alt="">
                                    </figure>
                                    <figcaption>
                                        <b>Cleaning</b>
                                        <p>The cleaning process begins: a sustainable washing process that uses only eco-friendly and cruelty-free products to refresh your items</p>
                                    </figcaption>
                                </div><!-- /.flow-col -->
                            </div>


                            <div class="col-md-4">
                                <div class="flow-col box-shadow">
                                    <figure>
                                        <img src="assets/images/completion.svg" alt="">
                                    </figure>
                                    <figcaption>
                                        <b>Completion</b>
                                        <p>Ta-da! Back at your doorstep clean & fresh in as quick as 24hrs”</p>
                                    </figcaption>
                                </div><!-- /.flow-col -->
                            </div>

                        </div>
                    </div><!-- /.flow-cols -->
                </div><!-- /.work-section-inner -->
            </div><!-- /.container-sm -->
        </div><!-- /.worksection -->


        <div class="packages-section bg-theme-lightblue">
            <div class="container">
                <div class="packages-section-inner">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="title-col">
                                <div class="section-title">
                                    <h4>Simple Laundry Packages</h4>
                                    <p>Pay for what you need with our affordable laundry packages</p>
                                </div>
                            </div>

                        </div>

                        <div class="col-md-3">
                            <div class="package-col box-shadow fig-col bg-white">
                                <figure>
                                    <img src="assets/images/icons/home-ico4.svg" alt="">
                                </figure>
                                <figcaption>
                                    <b>Basic</b>
                                    <p class="fig-para">WASH + TUMBLE-DRY ONLY</p>
                                    <p class="price-tag">from £9.95</p>
                                </figcaption>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="package-col box-shadow fig-col bg-white">
                                <figure>
                                    <img src="assets/images/icons/home-ico5.svg" alt="">
                                </figure>
                                <figcaption>
                                    <b>Standard</b>
                                    <p class="fig-para">WASH + TUMBLE-DRY + FOLD</p>
                                    <p class="price-tag">from £14.95</p>
                                </figcaption>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="package-col box-shadow fig-col bg-white">
                                <figure>
                                    <img src="assets/images/icons/home-ico6.svg" alt="">
                                </figure>
                                <figcaption>
                                    <b>Premium</b>
                                    <p class="fig-para">WASH + TUMBLE-DRY + STEAM IRON + FOLD</p>
                                    <p class="price-tag">from £24.95</p>
                                </figcaption>
                            </div>
                        </div>
                    </div>
                </div><!-- /.packages-section-inner -->
            </div><!-- /.container -->
        </div><!-- /.packages-section -->


        <div class="packages-section bg-theme-light">
            <div class="container">
                <div class="packages-section-inner">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="package-col title-col">
                                <div class="section-title">
                                    <h4>Shoe care packages</h4>
                                    <p>Professional shoe cleaning and restoration services that bring your kicks back to life</p>
                                </div>
                                <img src="assets/images/green-star.svg" alt="" class="star-bg">

                            </div>

                        </div>

                        <div class="col-md-3">
                            <div class="package-col box-shadow fig-col bg-white">
                                <figure>
                                    <img src="assets/images/shoe-standard.svg" alt="">
                                </figure>
                                <figcaption>
                                    <b>Standard</b>
                                    <p class="fig-para">A Deep Clean suitable for all brands (Adidas, Nike, Puma, etc)</p>
                                    <p class="price-tag">from £25</p>
                                </figcaption>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="package-col box-shadow fig-col bg-white">
                                <figure>
                                    <img src="assets/images/shoe-premium.svg" alt="">
                                </figure>
                                <figcaption>
                                    <b>Premium</b>
                                    <p class="fig-para">A Delicate Deep Clean recommended for designer brands (Chanel, Gucci, LV, etc)</p>
                                    <p class="price-tag">from £35</p>
                                </figcaption>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="package-col box-shadow fig-col bg-white">
                                <figure>
                                    <img src="assets/images/shoe-luxry.svg" alt="">
                                </figure>
                                <figcaption>
                                    <b>Luxury</b>
                                    <p class="fig-para">Get the ultimate cleaning package with some light restoration work</p>
                                    <p class="price-tag">from £45</p>
                                </figcaption>
                            </div>
                        </div>
                    </div>
                </div><!-- /.packages-section-inner -->
            </div><!-- /.container -->
        </div><!-- /.packages-section -->


        <div class="price-banner-section">
            <div class="price-banner-inner">
                <div class="row">
                    <div class="col-md-6">
                        <div class="price-col col-left">
                            <img src="assets/images/best-price-banner.svg" alt="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="price-col col-right">
                            <div class="section-title">
                                <h4><small>Refer a friend</small>Get £5 off <span>Your next wash</span></h4>
                                <a href="#" class="theme-btn btn-green-theme section-icon-btn">Send Referral link <i class="icon-referral-link"></i> </a>
                            </div><!-- /.section-title -->
                            <img src="assets/images/grey-star.svg" alt="">
                        </div>
                    </div>
                </div>
            </div><!-- /.price-banner-inner -->
        </div><!-- /.price-banner-section -->


        <button data-bs-target="cookieModal"></button>


        <div class="cookies-modal-popup">

            <!-- Modal -->
            <div class="modal fade hm_cookie-modal" id="cookieModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">

                        <div class="modal-body">
                            <p>This site uses cookies. By continuing to browse the site you are agreeing to our use of cookies.</p>
                            <a href="#">Find out more here</a>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="theme-btn btn-green-theme cookeis-modal-colose" data-bs-dismiss="modal">Accept</button>
                        </div>
                    </div>
                </div>
            </div>


        </div><!-- /.cookies-popup -->


    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>