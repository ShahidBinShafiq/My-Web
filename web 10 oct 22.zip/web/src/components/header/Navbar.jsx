import { useState } from "react";
import { Link } from "react-router-dom";
import Logo from "./Logo";



const Navbar = ()=>{

const [navitem, setNavitem] = useState ([
    {
        home: "Home",
        contact: "Contact",
        services: "Services",
        gallery: "Gallery",
        blogs: "Blogs"
    }
])
 

    return(
        <div>

<nav class="navbar navbar-expand-lg navbar-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
        <Logo/>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">

      {
            navitem.map((i, index)=>{
                return(
                    <div className="site-nav">
                            <ul className="navbar-nav ms-auto mb-2 mb-lg-0">

                            <li className="nav-item">
                                <Link to="/" className="nav-link active">{i.home}</Link>
                             </li>
                            <li className="nav-item">
                            <Link to="/contact" className="nav-link">{i.contact}</Link>

                            </li>
                          
                            <li className="nav-item">
                            <Link to="/services" className="nav-link">{i.services}</Link>
                            </li>
                            <li className="nav-item">
                            <Link to="/gallery" className="nav-link">{i.gallery}</Link>
                            </li>
                            <li className="nav-item">
                            <Link to="/blogs" className="nav-link">{i.blogs}</Link>
                            </li>
                        </ul>
                    </div>
                )
            })
           }


    </div>
  </div>
</nav>
     
        </div>
    )
}


export default Navbar