import { useState } from "react"




const Cards = () => {

    const [card, setCard] = useState([
        {
            img: "Card Image Path",
            title: "Delivery",
            description: "Our easy-to-use booking system makes scheduling a collection for your items simple and convenient",
            btn: "View More",
        },

        {
            img: "Card Image Path",
            title: "Collection",
            description: "Ta-da! Back at your doorstep clean & fresh in as quick as 24hrs”",
            btn: "View More",
        },

        {
            img: "Card Image Path",
            title: "Payment",
            description: "Pay for what you need with our affordable laundry packages",
            btn: "View More",
        },

        
    ])










  return (
    <div className="cards-wrapper">
        <div className="card-wrap">
            <div className="container">
                <div className="card-inner">
                    {
                    card.map((cardItem)=>{
                        return(
                            <div className="card-pod">
                                <div className="row">
                                    <div className="col-md-4">
                                    <div className="card-pod">
                                        <div class="card">
                                        <img src="{cardItem.img}" class="card-img-top" alt="..."/>
                                        <div class="card-body">
                                            <h5 class="card-title">{cardItem.title}</h5>
                                            <p class="card-text">{cardItem.description}</p>
                                            <a href="#" class="btn btn-primary">{cardItem.btn}</a>
                                        </div>
                                        </div>
                                        </div>
                                    </div>

                        </div>
                            </div>
                        )
                    })
                    }
                </div>
            </div>
        </div>
    </div>
  )
}

export default Cards