import Headerstrip from "../components/header/Headerstrip"



const Contact = ()=> {
  return (
    <div className="page-wrapper">
         <div className="header-component">
               <Headerstrip/>
            </div>
         <div className="site-contact">
        <div className="container">
            <div className="site-contact-inner">
        <h1>This is Contact Page</h1>
            </div>
        </div>
    </div>
    </div>
  )
}

export default Contact