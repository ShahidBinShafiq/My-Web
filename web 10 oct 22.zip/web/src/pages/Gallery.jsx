import Headerstrip from "../components/header/Headerstrip"
import Slider from "../components/Slider"




const Gallery = () => {
  return (
    <div className="page-wrap">
            <div className="header-component">
               <Headerstrip/>
            </div>

            <div className="gallery-wrapper">
                <div className="container">
                    <div className="gallery-inner">
                        <h1>Ths is Gallery Page</h1>
                    </div>
                </div>
            </div>


            <div className="site-slider">
              <Slider/>
          </div>


    </div>
  )
}

export default Gallery