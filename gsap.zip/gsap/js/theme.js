gsap.registerPlugin(ScrollTrigger);


// gsap.set(".scroll", {
//     x: "50%",
// })
gsap.from(".scroll1", {
    x: "100%",
    // delay: .5,
    duration: 3,
    scrollTrigger: {
        trigger: '.next',
        toggleActions: "play pause restart reset",
        scrub: .3,
        toggleClass: "bg-yellow",
        markers: true,
        start: 'top 90%',
        end: "top: 40%",
    },
   
});


gsap.from(".scroll2", {
    x: "-100%",
    // delay: .5,
    duration: 3,
    scrollTrigger: {
        trigger: '.next',
        toggleActions: "play pause restart reset",
        scrub: .3,
        toggleClass: "bg-yellow",
        // markers: true,
        start: 'top 90%',
        end: "top: 40%",
    },
   
});

gsap.to(".half-img", {
    width: "100%",
    height: "100vh",
    objectFit: "cover",
    duration: 3,
    scrollTrigger: {
        trigger: '.site-image',
        // toggleActions: "none none none none",
        toggleClass: "img-full",
        // markers: true,
        // scrub: true,
        start: 'top 50%',
        end: "top: 10%",
        
    },
})