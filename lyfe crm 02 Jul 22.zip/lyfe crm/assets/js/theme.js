$(document).ready(function(){

  $(".password-toggle").click(function () {
    // Hide it but only if not hidden - hide
    $('.password-toggle:visible').hide();

    // Later in the script - Show it but only If it's not visible.  
    $('.password-toggle:hidden').show();
});


$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
  var target = this.href.split('#');
  $('.nav a').filter('[href="#'+target[1]+'"]').tab('show');
})



  });