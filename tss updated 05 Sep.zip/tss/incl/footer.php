<footer class="footer__wrap">

    <div class="site-footer section-space">
    <div class="container-lg">
    <div class="footer-inner">
        <div class="row">
            <div class="col-md-4">
                <div class="foot-col">
                    <div class="foot-col-title">
                        <img src="./assets/images/brand-logo.svg" alt="">
                    </div>
                </div><!-- /.foot-col -->
                
            </div>
            <div class="col-md-4">
            <div class="foot-col">
                    <div class="foot-col-title">
                        <h4>Book A Free Consultation</h4>
                    </div>
                </div><!-- /.foot-col -->
            </div>
            <div class="col-md-4">
            <div class="foot-col">
                    <div class="foot-col-title">
                        <h4>Quick Links</h4>
                    </div>
                </div><!-- /.foot-col -->
            </div>
        </div>
    </div><!-- /.footer-inner -->
</div><!-- /.contaiener-lg -->
    </div><!-- /.site-footer -->
      
</footer><!--/.footer__wrap-->

</div><!--/.site__wrapper-->

<script src="assets/js/jquery-3.5.1.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/dat-gui/0.6.2/dat.gui.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/7.4.1/swiper-bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.10.4/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.10.4/ScrollTrigger.min.js"></script>
<script src="assets/js/theme.js"></script>

<script>
  



    </script>
</body>
</html>
