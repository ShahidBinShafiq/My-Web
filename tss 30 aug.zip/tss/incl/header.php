<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no, user-scalable=no">

    <title>Site Space</title> 

    <!-- <link href="assets/images/favicon/apple-touch-icon.png" rel="apple-touch-icon" type="image/png" sizes="180x180">
    <link href="assets/images/favicon/favicon-32x32.png" rel="icon" type="image/png" sizes="32x32">
    <link href="assets/images/favicon/favicon-16x16.png" rel="icon" type="image/png" sizes="16x16">
    <link href="assets/images/favicon/manifest.json" rel="manifest">
    <link href="assets/images/favicon/favicon.ico" rel="shortcut icon"> -->

    <style>
        .site__wrapper {
            opacity: 0;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/7.4.1/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="assets/css/theme.css">

</head>

<body>

<div class="preload__wrap"></div>
       
<div class="site__wrapper">

<header class="header-wrapper">
    <div class="container-md">
        <div class="heare-wrapper-inner">
            <div class="main-top-strip">
                <div class="s_media-icons">
                    facebook
                </div><!-- /.s_media-icons -->
                <div class="brand_logo">
                    site space
                </div><!-- /.brand_logo -->
                <div class="hamburger_menu-icon">
                        <div class="menu-icon-inner">
                            <span class="menu-icon-line line-one"></span>
                            <span class="menu-icon-line line-line-two"></span>
                            <span class="menu-icon-line line-three"></span>
                        </div>
                </div><!-- /.hamburger_menu-icon -->
            </div>
        </div><!-- /.heare-wrapper-inner -->
        </div><!-- /.container-md -->
    
</header>