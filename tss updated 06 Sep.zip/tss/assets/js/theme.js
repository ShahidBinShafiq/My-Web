/**
 * @var $ jQuery
 */

// Full Height...
function fsHeight() {
  let winHeight = $(window).height();
  $('[data-height="viewport"]').css("height", winHeight, "!important");
  $('[data-min-height="viewport"]').css("minHeight", winHeight, "!important");
}

/* Window Load ---------------------- */

$(window).on("load", function () {
  setTimeout(function () {
    $("body").addClass("loaded");
  }, 400);

  // setTimeout(function () {
  //     AOS.init({
  //         once: true,
  //         duration: 1000
  //     });
  // }, 800);
});

/* Document Ready ---------------------- */

$(document).ready(function () {
  fsHeight();

  // Inline background image...
  $("[data-bg]").each(function () {
    const image = $(this).attr("data-bg");
    $(this).css({
      backgroundImage: 'url("' + image + '")',
    });
  });

  /* Swiper Slider ---------------------- */

  const swiper = new Swiper(".swiper", {
    // Optional parameters
    direction: "horizontal",
    slidesPerView: 1,
    // spaceBetween: 20,
    clickable: true,
    loop: true,

    // Navigation arrows
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
  });

  /* Window Scroll ---------------------- */

  $(window).on("scroll", function () {});

  /* Window Resize ---------------------- */

  $(window).on("resize", function () {
    fsHeight();
  });

  const rippleSettings = {
    maxSize: 100,
    animationSpeed: 5,
    strokeColor: [148, 217, 255],
  };

  const canvasSettings = {
    blur: 8,
    ratio: 1,
  };

  function Coords(x, y) {
    this.x = x || null;
    this.y = y || null;
  }

  const Ripple = function Ripple(x, y, circleSize, ctx) {
    this.position = new Coords(x, y);
    this.circleSize = circleSize;
    this.maxSize = rippleSettings.maxSize;
    this.opacity = 1;
    this.ctx = ctx;
    this.strokeColor = `rgba(${Math.floor(rippleSettings.strokeColor[0])},
    ${Math.floor(rippleSettings.strokeColor[1])},
    ${Math.floor(rippleSettings.strokeColor[2])},
    ${this.opacity})`;

    this.animationSpeed = rippleSettings.animationSpeed;
    this.opacityStep = this.animationSpeed / (this.maxSize - circleSize) / 2;
  };

  Ripple.prototype = {
    update: function update() {
      this.circleSize = this.circleSize + this.animationSpeed;
      this.opacity = this.opacity - this.opacityStep;
      this.strokeColor = `rgba(${Math.floor(rippleSettings.strokeColor[0])},
      ${Math.floor(rippleSettings.strokeColor[1])},
      ${Math.floor(rippleSettings.strokeColor[2])},
      ${this.opacity})`;
    },
    draw: function draw() {
      this.ctx.beginPath();
      this.ctx.strokeStyle = this.strokeColor;
      this.ctx.arc(
        this.position.x,
        this.position.y,
        this.circleSize,
        0,
        2 * Math.PI
      );
      this.ctx.stroke();
    },
    setStatus: function setStatus(status) {
      this.status = status;
    },
  };

  const canvas = document.querySelector("#canvas");
  if (canvas) {
    const ctx = canvas?.getContext("2d");
    const ripples = [];

    const height = document.body.clientHeight;
    const width = document.body.clientWidth;

    const rippleStartStatus = "start";

    const isIE11 = !!window.MSInputMethodContext && !!document.documentMode;

    canvas.style.filter = `blur(${canvasSettings.blur}px)`;

    canvas.width = width * canvasSettings.ratio;
    canvas.height = height * canvasSettings.ratio;

    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;

    let animationFrame;

    // Add GUI settings
    const addGuiSettings = () => {
      const gui = new dat.GUI();
      gui.add(rippleSettings, "maxSize", 0, 1000).step(1);
      gui.add(rippleSettings, "animationSpeed", 1, 30).step(1);
      gui.addColor(rippleSettings, "strokeColor");

      const blur = gui.add(canvasSettings, "blur", 0, 20).step(1);
      blur.onChange((value) => {
        canvas.style.filter = `blur(${value}px)`;
      });
    };

    addGuiSettings();

    // Function which is executed on mouse hover on canvas
    const canvasMouseOver = (e) => {
      const x = e.clientX * canvasSettings.ratio;
      const y = e.clientY * canvasSettings.ratio;
      ripples.unshift(new Ripple(x, y, 2, ctx));
    };

    const animation = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const length = ripples.length;
      for (let i = length - 1; i >= 0; i -= 1) {
        const r = ripples[i];

        r.update();
        r.draw();

        if (r.opacity <= 0) {
          ripples[i] = null;
          delete ripples[i];
          ripples.pop();
        }
      }
      animationFrame = window.requestAnimationFrame(animation);
    };

    animation();
    canvas.addEventListener("mousemove", canvasMouseOver);
  }
// services section
  function ServicesItemHover() {
    const ourServices = document.getElementById("our-services");
    console.log(ourServices);
    const servicesItems = Array.from(ourServices.getElementsByTagName("li"));

    const svItemPreview = document.getElementById("sv-item-preview");
    const imageItem = svItemPreview?.querySelector("#previewItem");
    if (!(svItemPreview.getAttribute("src") != undefined)) {
      imageItem.setAttribute("src", servicesItems[0].dataset.img);
    }
    servicesItems.forEach(function (item) {
      item.addEventListener("mouseover", function () {
        imageItem.setAttribute("src", item.dataset.img);
      });
      item.addEventListener("mouseleave", function () {
        imageItem.setAttribute("src", servicesItems[0].dataset.img);
      });
    });
  }
  ServicesItemHover();


  // Mouse hover element Move effect
// function ElementMoueHoverEffect(params) {
//   const getMousePos = function(ev) {
//     let posx = 0;
//     let posy = 0;
    
//     if (!ev) ev = window.event;
//     if (ev.pageX || ev.pageY) 	{
//       posx = ev.pageX;
//       posy = ev.pageY;
//     } else if (ev.clientX || ev.clientY) 	{
//       posx = ev.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
//       posy = ev.clientY + document.body.scrollTop + document.documentElement.scrollTop;
//     }
//     return { x : posx, y : posy };
//   };
  
//   const moveElements = function(e) {
//     e.preventDefault();
//     let positions = {};
    
//     var touches = e.changedTouches;
//     Array.from(document.querySelectorAll('.btn-circle')).forEach(
//       el => positions = getMousePos(touches ? touches[0] : e)
//     );  
    
//     const elWrapper = document.querySelector(".theme-btn");
//     const screenWidth  = elWrapper.offsetWidth;
//     const screenHeight = elWrapper.offsetHeight;
//     const newPosX = ((positions.x * 100 / screenWidth) - 50) / 2;
//     const newPosY = ((positions.y * 100 / screenHeight) - 50) / 10;
    
//     Array.from(document.querySelectorAll('.btn-circle')).forEach(el => {
//       el.style.transition = "none";
//       el.style.transform = `translate(${newPosX}%, ${newPosY}%)`;
//     });
//   };
  
//   const endMove = function(e) {
//     Array.from(document.querySelectorAll('.btn-circle')).forEach(el => {
//       el.style.transition = "transform 300ms linear";
//       el.style.transform = "translate(0%, 0%)";
//     });
//   }
  
//   document.querySelector('.border-primary').addEventListener("mousemove", moveElements);
//   document.querySelector('.border-primary').addEventListener("touchmove", moveElements, false);
//   document.querySelector('.border-primary').addEventListener("mouseleave", endMove); 
//   document.querySelector('.border-primary').addEventListener("touchend", endMove, false); 
  
// }
// ElementMoueHoverEffect()
  
});








let headerWrap = document.getElementById('header-wrap');
let nav_Bar = document.getElementById('navBar');
let nav_icon = document.getElementById('nav-icon');

nav_icon.addEventListener('click', function(){
    nav_Bar.classList.toggle('nav-toggle')
    nav_icon.classList.toggle('menu-icon-collapes')
    headerWrap.classList.toggle('header-wrap-toggle')       

})



// gsap on scroll add class



/*
let el3 = $(".element-3").height();

$(window).one('scroll', function(){
    $(".my_para").css({"paddingTop": el3 });
});
*/





gsap.registerPlugin('scrollTrigger')

// gsap.to('.element-3', {
//     // x:-500,
//     duration:1,
//     scrollTrigger:{
//         // markers: true,
//         trigger: '.element-3',
//         toggleActions: 'play none none reverse',
//         scrub:1,
//         start: 'top 51%',

        
//     },
//     width: '100%',
//     height: '100%',

    
// })

gsap.to('body', {
    duration:.4,
    scrollTrigger:{
        // markers: true,
        trigger: '.g-add-bg',
        toggleActions: 'play none none reverse',
        // scrub:1,
        start: 'top 150%',
        // end: ()=> `+=${document.querySelector('.my-section').offsetHeight}`,
        end: 'bottom top',
        toggleClass: {className: 'g-add-bg-body', targets: 'body'}
    }

})


gsap.to('.svc-info-wrapper', {
    duration:.4,
    scrollTrigger:{
        // markers: true,
        trigger: '.svc-info-wrapper',
        toggleActions: 'play none none reverse',
        // scrub:1,
        start: 'top 110%',
        // end: ()=> `+=${document.querySelector('.my-section').offsetHeight}`,
        end: 'bottom top',
        toggleClass: {className: 'theme-btn-white', targets: '.theme-btn'},
        toggleClass: {className: 'g-add-whitebg', targets: '.work-cols-wrapper'},
    }

})
gsap.to('.svc-info-wrapper', {
    duration:.4,
    scrollTrigger:{
        // markers: true,
        trigger: '.work-cols-wrapper',
        toggleActions: 'play none none reverse',
        // scrub:1,
        start: 'top 100%',
        // end: ()=> `+=${document.querySelector('.my-section').offsetHeight}`,
        end: 'bottom top',
        toggleClass: {className: 'theme-btn-white', targets: '.theme-btn'},
    }

})
