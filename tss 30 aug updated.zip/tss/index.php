<?php include 'incl/header.php'; ?>

    <main class="page__wrap">
            <!-- <canvas id="canvas"> </canvas> -->

        <main>
        <div class="page-banner-wrapper">

<div class="container-md">
<div class="page-banner-inner">
<div class="page-banner-title">
        <div class="banner-title-inner">
        <h2>Creative <span class="tg-lineare">Web Design &</span> <span class="tg-lineare-reverse">Digital </span>Agency London.</h2>
        <p>Web Buds is a creative website design agency in London. A <b>team of talented web designers</b> in London.</p>
            <a href="#" class="theme-btn">Start Your Project</a>


            <div class="anim-cirlce xl-hide">
            <svg viewBox="0 0 100 100" width="100" height="100">
                <defs>
                    <path id="circle" d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"/>
                </defs>
                <text>
                    <textPath xlink:href="#circle">
                    We Create Fast websites
                    </textPath>
                </text>
                </svg>
            </div><!-- /.anim-cirlce -->
       
        </div>
</div><!-- /.page-banner-title -->
</div><!-- /.page-banner-inner -->
</div><!-- /.container-md -->

<span class="site-page-title">The&nbspSite Space</span>
</div><!-- /.page-banner-wrapper -->

    <div class="brand-info-wrapper section-space">
        <div class="brand-info-inner agency-info-cols">
            <div class="info-content-col info-col container-md-half ms-auto">
                <div class="info-col-title">
                    <h4><small>A Full-Stack</small>Web design, digital marketing and app development agency in London.</h4>
                </div>
                <p>We are London based web design agency. A small team with big ideas. We specialise in bespoke web designing. From brochure websites to custom applications we do everything! Website design for everyone..</p>
            </div>
            <div class="info-figure-col info-col">
                <figure>
                    <img src="assets/images/brand-info-fig.png" alt="">
                </figure>
            </div>
        </div><!-- /.brand-info-inner -->
    </div><!-- /.brand-info-wrapper -->

        <div class="work-cols-wrapper">
            <div class="conainer-lg">
                <div class="work-cols-inner">
                    <div class="figure-col">
                        <figure>
                            <img src="assets/images/work-img-1.png" alt="">
                        </figure>
                    </div>
                    <div class="content-col">
                        <a href="#" class="theme-btn">View Project</a>
                    </div>
                </div><!-- /.work-cols-inner -->
            </div><!-- /.conainer-lg -->
        </div><!-- /.work-cols-wrapper -->
        </main>

    </main><!--/.page__wrap-->


    <!-- <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br> -->

<?php include 'incl/footer.php'; ?>

