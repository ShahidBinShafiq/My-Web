<?php
global $bodyClass;
$bodyClass = 'inner';
?>

<?php include 'incl/header.php'; ?>

<div class="theme_page-head">
    <div class="tp_head-inner">
        <h2 class="tp_title"><i class="bi bi-grid"></i> Reports <small>Lorem ipsum dolor</small></h2>

        <div class="tp_head-right">
            <a href="#" class="btn btn-sm btn-primary">Some Button</a>
        </div><!--/.tp_head-right-->

    </div><!--/.tp_head-inner-->
</div><!--/.theme_page-head-->


<main class="theme_page-wrap">

    <div class="theme_page-inner">


        <div class="theme_content-wrapper">

            <div class="card mb1-5rem">
                <div class="card-header">
                    <i class="bi bi-grid-3x3"></i> Recent Reports
                </div><!--/.card-header-->

                <div class="card-body">

                    <div class="table-responsive">

                        <table class="table table-bordered table-striped table-hover">
                            <thead>
                            <tr>
                                <th>Open</th>
                                <th>Status</th>
                                <th>Name</th>
                                <th>Date Range</th>
                                <th>Delete</th>
                            </tr>
                            </thead>

                            <tbody>
                            <tr>
                                <td align="center"><a href="#"><i class="bi bi-box-arrow-up-right"></i></a></td>
                                <td>Complete</td>
                                <td>Genius Monkey Report for 1 Performance Overview Report and 1 Performance Report and 1 Attribution Report</td>
                                <td>3/1/22 - 3/31/22</td>
                                <td align="center"><a href="#"><i class="bi bi-trash"></i></a></td>
                            </tr>
                            <tr>
                                <td align="center"><a href="#"><i class="bi bi-box-arrow-up-right"></i></a></td>
                                <td>Complete</td>
                                <td>Genius Monkey Report for 1 Performance Overview Report and 1 Performance Report and 1 Attribution Report</td>
                                <td>3/1/22 - 3/31/22</td>
                                <td align="center"><a href="#"><i class="bi bi-trash"></i></a></td>
                            </tr>
                            <tr>
                                <td align="center"><a href="#"><i class="bi bi-box-arrow-up-right"></i></a></td>
                                <td>Complete</td>
                                <td>Genius Monkey Report for 1 Performance Overview Report and 1 Performance Report and 1 Attribution Report</td>
                                <td>3/1/22 - 3/31/22</td>
                                <td align="center"><a href="#"><i class="bi bi-trash"></i></a></td>
                            </tr>
                            <tr>
                                <td align="center"><a href="#"><i class="bi bi-box-arrow-up-right"></i></a></td>
                                <td>Complete</td>
                                <td>Genius Monkey Report for 1 Performance Overview Report and 1 Performance Report and 1 Attribution Report</td>
                                <td>3/1/22 - 3/31/22</td>
                                <td align="center"><a href="#"><i class="bi bi-trash"></i></a></td>
                            </tr>
                            <tr>
                                <td align="center"><a href="#"><i class="bi bi-box-arrow-up-right"></i></a></td>
                                <td>Complete</td>
                                <td>Genius Monkey Report for 1 Performance Overview Report and 1 Performance Report and 1 Attribution Report</td>
                                <td>3/1/22 - 3/31/22</td>
                                <td align="center"><a href="#"><i class="bi bi-trash"></i></a></td>
                            </tr>
                            <tr>
                                <td align="center"><a href="#"><i class="bi bi-box-arrow-up-right"></i></a></td>
                                <td>Complete</td>
                                <td>Genius Monkey Report for 1 Performance Overview Report and 1 Performance Report and 1 Attribution Report</td>
                                <td>3/1/22 - 3/31/22</td>
                                <td align="center"><a href="#"><i class="bi bi-trash"></i></a></td>
                            </tr>
                            <tr>
                                <td align="center"><a href="#"><i class="bi bi-box-arrow-up-right"></i></a></td>
                                <td>Complete</td>
                                <td>Genius Monkey Report for 1 Performance Overview Report and 1 Performance Report and 1 Attribution Report</td>
                                <td>3/1/22 - 3/31/22</td>
                                <td align="center"><a href="#"><i class="bi bi-trash"></i></a></td>
                            </tr>
                            <tr>
                                <td align="center"><a href="#"><i class="bi bi-box-arrow-up-right"></i></a></td>
                                <td>Complete</td>
                                <td>Genius Monkey Report for 1 Performance Overview Report and 1 Performance Report and 1 Attribution Report</td>
                                <td>3/1/22 - 3/31/22</td>
                                <td align="center"><a href="#"><i class="bi bi-trash"></i></a></td>
                            </tr>
                            </tbody>
                        </table>

                    </div><!--/.table-responsive-->

                </div><!--/.card-body-->
            </div><!--/.card-->

            <div class="mt2rem">
                <p class="small">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Hic officiis quis recusandae voluptatem. Assumenda beatae cupiditate dicta ipsa iusto necessitatibus nemo perferendis reiciendis velit vero? Adipisci, asperiores, consequatur
                    dolorem error impedit incidunt magnam minima modi natus quaerat sequi sit voluptatum. Dicta doloribus ducimus neque nobis nulla perferendis quia, vero? Molestias.</p>

                <p class="small"><b>Attribution:</b> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt expedita magni minus mollitia nobis pariatur perspiciatis quasi. Alias aliquam amet aspernatur assumenda consequuntur cum debitis doloremque dolores eos eum explicabo
                    fugiat magni molestias odit placeat porro possimus praesentium quae quibusdam, recusandae rem reprehenderit repudiandae rerum soluta sunt tempora vel velit!</p>
            </div><!--/.mb2rem-->

        </div><!--/.theme_content-wrapper-->

    </div><!--/.theme_page-inner-->

</main><!--/.theme_page-wrap-->


<?php include 'incl/footer.php'; ?>
