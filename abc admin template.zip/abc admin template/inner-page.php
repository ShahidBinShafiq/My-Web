<?php
global $bodyClass;
$bodyClass = 'inner';
?>

<?php include 'incl/header.php'; ?>

<div class="theme_page-head">
    <div class="tp_head-inner">
        <h2 class="tp_title"><i class="bi bi-grid"></i> Page Title <small>Lorem ipsum dolor</small></h2>

        <div class="tp_head-right">
            <a href="#" class="btn btn-sm btn-primary">Some Button</a>
        </div><!--/.tp_head-right-->

    </div><!--/.tp_head-inner-->
</div><!--/.theme_page-head-->


<main class="theme_page-wrap">

    <div class="theme_page-inner">


        <div class="theme_content-wrapper">

            <div class="card mb1-5rem">
                <div class="card-header">
                    <i class="bi bi-calendar4"></i> Card Panel Title
                </div><!--/.card-header-->

                <div class="card-body">

                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci architecto corporis doloribus expedita illo, nam reprehenderit sed sequi sunt voluptatem. Asperiores consequuntur, exercitationem facere impedit magnam minima non nostrum officiis placeat quae quas quia
                        quibusdam ratione recusandae reiciendis rerum sequi sunt voluptas. Commodi dolorum laboriosam voluptatibus. Eius eveniet expedita odio optio similique suscipit, totam! Accusamus consectetur ducimus ipsum iusto maiores quae quaerat quisquam sint velit voluptatibus. Dicta,
                        distinctio dolor exercitationem officiis quas sit tempora? Accusantium aspernatur dignissimos ducimus eius est laudantium quisquam veritatis voluptas? Aspernatur fugit ipsa nobis perspiciatis sint veniam voluptatem voluptates! Aperiam, atque aut beatae cupiditate magni
                        maxime obcaecati quo similique sit velit vitae voluptatem? Animi doloribus ducimus eius eligendi, et excepturi facilis modi nam necessitatibus perferendis sed sit, voluptas voluptatem? At eveniet iure magni quis sequi totam, voluptatem. Assumenda consequatur debitis
                        delectus dicta dolorem est hic mollitia porro quia similique? At consequuntur debitis esse facere harum inventore ipsa, ipsam minus nemo non nostrum provident quas repudiandae, sed similique soluta, totam unde veniam. Commodi dicta dignissimos dolore, eaque esse harum
                        inventore labore laudantium, maiores neque nobis officia officiis porro, provident quae quod repudiandae temporibus vero! Ad aspernatur earum hic ipsam nisi quo recusandae velit voluptatum? Adipisci, aliquam autem consequatur distinctio, dolorem eius expedita in
                        inventore ipsa magnam molestiae natus quae quaerat qui quis, repellat repudiandae? Ab accusantium amet animi architecto asperiores commodi corporis culpa cum delectus deleniti dolorem ducimus earum eligendi eos facilis fugiat iure libero minus nisi numquam, perferendis
                        perspiciatis porro possimus quaerat recusandae repellendus reprehenderit repudiandae sapiente similique suscipit ullam unde voluptas voluptate? Facilis fuga id incidunt, libero nam quam? Cumque dolore magni necessitatibus optio quia quod recusandae repellat. A accusamus
                        aperiam architecto asperiores blanditiis consectetur consequatur culpa dolor dolores ea enim eos esse, eum fugiat hic inventore, ipsa labore maiores minima nam neque non obcaecati odio possimus praesentium provident quaerat quam quasi quia quibusdam reiciendis repellat
                        saepe sint soluta suscipit vitae voluptatibus. Consectetur deleniti eius facere in minus nostrum totam vero! Ab ad amet asperiores, consequatur cupiditate doloribus ducimus eligendi est explicabo libero maxime odio, omnis praesentium reiciendis sapiente sequi soluta
                        veritatis. Ab animi corporis minima nemo nisi. Accusamus cum cumque eligendi, facere ipsam laudantium natus necessitatibus, quasi quod quos ratione rerum sunt voluptatem! Alias assumenda, at autem cumque id ipsa repellendus? Accusantium fugit ipsa quam veniam! Expedita
                        illum laudantium molestiae quae? Animi excepturi laborum laudantium natus necessitatibus placeat saepe sequi similique sint, tenetur voluptate?</p>

                </div><!--/.card-body-->
            </div><!--/.card-->

        </div><!--/.theme_content-wrapper-->

    </div><!--/.theme_page-inner-->

</main><!--/.theme_page-wrap-->


<?php include 'incl/footer.php'; ?>
