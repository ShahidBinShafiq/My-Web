<?php
global $bodyClass;
$bodyClass = 'login';
?>

<?php include 'incl/header.php'; ?>


<main class="login_page-wrap">

    <div class="login_page-inner">

        <figure class="landing_logo logo_animate" id="landingLogo">
            <span class="dot1"></span>
            <span class="dot2"></span>
            <span class="dot3"></span>
            <span class="dot4"></span>
            <span class="dot5"></span>
            <span class="dot6"></span>
            <span class="dot7"></span>
            <span class="dot8"></span>
            <img src="assets/images/imp_logo-wide.svg" alt="">
        </figure><!--/.landing_logo-->

        <div class="login_form-outer">

            <h2 class="h4">Login to your Account</h2>
            <small>Lorem ipsum dolor sit amet adipisicing aliquam.</small>

            <form class="login_form">

                <div class="form-group mb1rem">
                    <label for="userName">Username</label>
                    <input type="text" id="userName" class="form-control" placeholder="john_doe" autofocus>
                </div><!--/.form-group-->

                <div class="form-group mb1rem">
                    <label for="password">Password</label>
                    <input type="password" id="password" class="form-control" placeholder="Password">
                </div><!--/.form-group-->

                <div class="custom-control custom-checkbox">
                    <input type="checkbox" id="loginRemember" class="custom-control-input">
                    <label for="loginRemember" class="custom-control-label">Remember Me</label>
                </div><!--/.custom-control-->

                <div class="text-right">
                    <a href="overview.php" class="btn btn-lg btn-primary">Sign In</a>
                </div><!--/.text-right-->

            </form><!--/.login_form-->

        </div><!--/.login_form-outer-->

        <p class="login_copyrights-text">Copyright © 2022 Digital Functionalism. All Rights Reserved.</p>

    </div><!--/.login_page-inner-->

</main><!--/.login_page-wrap-->


<?php include 'incl/footer.php'; ?>
