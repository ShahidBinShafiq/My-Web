/**
 * @var $ jQuery
 */

// Browser ScrollBar Width function...
function getScrollBarWidth() {
    let $outer = $('<div>').css({
            visibility: 'hidden',
            width: 100,
            overflow: 'scroll'
        }).appendTo('body'),
        widthWithScroll = $('<div>').css({
            width: '100%'
        }).appendTo($outer).width();
    $outer.remove();
    return 100 - widthWithScroll;
}

// Padding-right Scrollbar...
function scrollBarPadding() {
    let scBarWidth = getScrollBarWidth();
    $('[data-scrollbar-padding="right"]').css('padding-right', scBarWidth);
}

// Viewport Height...
function viewportHeight() {
    let winHeight = $(window).height();
    $('[data-height="viewport"]').css('height', winHeight, '!important');
    $('[data-min-height="viewport"]').css('minHeight', winHeight, '!important');
}

/* Window Load ---------------------- */

$(window).on('load', function () {

    // Body loaded class...
    setTimeout(function () {
        $('body').addClass('loaded');
    }, 500);

});


/* Document Ready ---------------------- */

$(document).ready(function () {

    scrollBarPadding();
    viewportHeight();


    // Aside navbar toggle...
    $('.aside_toggle-button').on('click', function () {
        $('body').toggleClass('aside_collapsed');
        $('.theme_aside').toggleClass('theme_aside-collapsed');
    });


    // Mobile navbar toggle...
    $('.mobile_navbar-toggle').on('click', function () {
        $(this).toggleClass('open');
        $('.theme_aside-inner').slideToggle();
    });


    // Smooth scroll to anchor...
    let elSmScroll = $('[data-scroll="smooth"]');
    elSmScroll.on('click', function (e) {
        e.preventDefault();
        let target = $(this).attr('href');
        $('html, body').animate({
            scrollTop: $(target).offset().top - 90
        }, 1000);
    });


    // Tooltip init...
    $('[data-toggle="tooltip"]').tooltip()


});


/* Window Scroll ---------------------- */

$(window).on('scroll', function () {


});


/* Window Resize ---------------------- */

$(window).on('resize', function () {

    scrollBarPadding();
    viewportHeight();

});