// Chart One

const data = {
    labels: [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July'
    ],
    datasets: [{
        type: 'bar',
        label: 'Impressions',
        data: [10, 20, 30, 40, 25, 35, 42],
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.2)'
    }, {
        type: 'line',
        label: 'Clicks',
        data: [30, 50, 15, 35, 30, 10, 17],
        fill: false,
        borderColor: 'rgb(54, 162, 235)'
    }]
};

const config = {
    type: 'scatter',
    data: data,
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
};

const myChart = new Chart(
    document.getElementById('chartOne'),
    config
);


// Chart OneA

const dataA = {
    labels: [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July'
    ],
    datasets: [{
        type: 'bar',
        label: 'Impressions',
        data: [10, 20, 30, 40, 25, 35, 42],
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.2)'
    }, {
        type: 'line',
        label: 'Clicks',
        data: [30, 50, 15, 35, 30, 10, 17],
        fill: false,
        borderColor: 'rgb(54, 162, 235)'
    }]
};

const configA = {
    type: 'scatter',
    data: dataA,
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
};

const myChartA = new Chart(
    document.getElementById('chartOneA'),
    configA
);


// Chart Two

const data2 = {
    labels: [
        'GM Conversions: 123'
    ],
    datasets: [{
        label: 'My First Dataset',
        data: [95, 5],
        backgroundColor: [
            'rgb(255,99,132)',
            'rgb(255,204,214)'
        ],
        hoverOffset: 4
    }]
};

const config2 = {
    type: 'doughnut',
    data: data2,
};

const myChart2 = new Chart(
    document.getElementById('chartTwo'),
    config2
);


// Chart Two-One

const data21 = {
    labels: [
        'GM Conversions: 101'
    ],
    datasets: [{
        label: 'My First Dataset',
        data: [78, 22],
        backgroundColor: [
            'rgb(0,166,255)',
            'rgb(190,235,255)'
        ],
        hoverOffset: 4
    }]
};

const config21 = {
    type: 'doughnut',
    data: data21,
};

const myChart21 = new Chart(
    document.getElementById('chartTwo1'),
    config21
);


// Chart Two-Two

const data22 = {
    labels: [
        'GM Conversions: 23'
    ],
    datasets: [{
        label: 'My First Dataset',
        data: [18, 82],
        backgroundColor: [
            'rgb(255,175,0)',
            'rgb(255,231,181)'
        ],
        hoverOffset: 4
    }]
};

const config22 = {
    type: 'doughnut',
    data: data22,
};

const myChart22 = new Chart(
    document.getElementById('chartTwo2'),
    config22
);


// Chart Three

const data3 = {
    labels: [
        'Desktop: 14',
        'Mobile: 113',
        'tablet: 3'
    ],
    datasets: [{
        label: 'My First Dataset',
        data: [10, 88, 2],
        backgroundColor: [
            'rgb(0,166,255)',
            'rgb(255,99,132)',
            'rgb(255,175,0)'
        ],
        hoverOffset: 4
    }]
};

const config3 = {
    type: 'doughnut',
    data: data3,
};

const myChart3 = new Chart(
    document.getElementById('chartThree'),
    config3
);


// Chart Four

const data4 = {
    labels: [
        'Genius Monkey',
        'Organic/Other'
    ],
    datasets: [{
        label: 'My First Datasets',
        data: [59, 41],
        backgroundColor: [
            'rgb(0,166,255)',
            'rgb(255,99,132)'
        ],
        hoverOffset: 4
    }]
};

const config4 = {
    type: 'doughnut',
    data: data4,
};

const myChart4 = new Chart(
    document.getElementById('chartFour'),
    config4
);
