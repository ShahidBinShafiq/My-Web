<?php
global $bodyClass;
$bodyClass = 'home';
?>

<?php include 'incl/header.php'; ?>

<div class="theme_page-head">
    <div class="tp_head-inner">
        <h2 class="tp_title"><i class="bi bi-grid"></i> Overview <small>Dashboard & Statistics</small></h2>

        <div class="tp_head-right">
            <a href="#" class="btn btn-sm btn-primary">Some Button</a>
        </div><!--/.tp_head-right-->

    </div><!--/.tp_head-inner-->
</div><!--/.theme_page-head-->


<main class="theme_page-wrap">

    <div class="theme_page-inner">


        <div class="theme_content-wrapper">

            <div class="row">

                <div class="col-xl-6">

                    <div class="card mb2rem">
                        <div class="card-header">
                            <i class="bi bi-collection"></i> Combined Campaign Results
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="table-responsive">

                                <table class="table table-bordered table-striped table-hover">
                                    <tbody>
                                    <tr>
                                        <td width="50%">Views/Impressions:</td>
                                        <td width="50%" align="right">1,255,619</td>
                                    </tr>
                                    <tr>
                                        <td width="50%">Clicks:</td>
                                        <td width="50%" align="right">3,774</td>
                                    </tr>
                                    <tr>
                                        <td width="50%">Total Spends:</td>
                                        <td width="50%" align="right">US$ 3,891.89</td>
                                    </tr>
                                    </tbody>
                                </table>

                            </div><!--/.table-responsive-->

                        </div><!--/.card-body-->
                    </div><!--/.card-->

                </div><!--/.col-xl-6-->

                <div class="col-xl-6">

                    <div class="card mb2rem">
                        <div class="card-header">
                            <i class="bi bi-archive"></i> Attribution
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="table-responsive">

                                <table class="table table-bordered table-striped table-hover">
                                    <tbody>
                                    <tr>
                                        <td width="50%">GM Conversions (CP Conv.): <i class="bi bi-info-circle-fill info_tooltip_icon" data-toggle="tooltip" data-placement="right" title="Lorem ipsum dolor sit amet"></i></td>
                                        <td width="50%" align="right">130 ($29.94)</td>
                                    </tr>
                                    <tr>
                                        <td width="50%">Genius Monkey % of Total Conversions: <i class="bi bi-info-circle-fill info_tooltip_icon" data-toggle="tooltip" data-placement="right" title="Lorem ipsum dolor sit amet"></td>
                                        <td width="50%" align="right">59.36%</td>
                                    </tr>
                                    <tr>
                                        <td width="50%">Total Site Conversions: <i class="bi bi-info-circle-fill info_tooltip_icon" data-toggle="tooltip" data-placement="right" title="Lorem ipsum dolor sit amet"></td>
                                        <td width="50%" align="right">219</td>
                                    </tr>
                                    </tbody>
                                </table>

                            </div><!--/.table-responsive-->

                        </div><!--/.card-body-->
                    </div><!--/.card-->

                </div><!--/.col-xl-6-->

                
                <div class="col-xl-12">

                    <div class="card mb2rem">
                        <div class="card-header">
                            <i class="bi bi-collection"></i> Campaigns
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="table-responsive">

                                <table class="table table-bordered table-striped table-hover">
                                    <thead>
                                    <tr>
                                        <th>Campaign</th>
                                        <th>Service</th>
                                        <th>Spend</th>
                                        <th>Impression</th>
                                        <th>Clicks</th>
                                        <th>CTR</th>
                                        <th>CPM</th>
                                        <th>CPC</th>
                                        <th>GM Conversions</th>
                                        <th>CP Conv.</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>CNE Electrician</td>
                                        <td>Display</td>
                                        <td>$826.05</td>
                                        <td>272,818</td>
                                        <td>920</td>
                                        <td>0.34%</td>
                                        <td>$3.03</td>
                                        <td>$0.90</td>
                                        <td>40</td>
                                        <td>$20.65</td>
                                    </tr>
                                    <tr>
                                        <td>CNE Electrician</td>
                                        <td>Display</td>
                                        <td>$826.05</td>
                                        <td>272,818</td>
                                        <td>920</td>
                                        <td>0.34%</td>
                                        <td>$3.03</td>
                                        <td>$0.90</td>
                                        <td>40</td>
                                        <td>$20.65</td>
                                    </tr>
                                    <tr>
                                        <td>CNE Electrician</td>
                                        <td>Display</td>
                                        <td>$826.05</td>
                                        <td>272,818</td>
                                        <td>920</td>
                                        <td>0.34%</td>
                                        <td>$3.03</td>
                                        <td>$0.90</td>
                                        <td>40</td>
                                        <td>$20.65</td>
                                    </tr>
                                    <tr>
                                        <td>CNE Electrician</td>
                                        <td>Display</td>
                                        <td>$826.05</td>
                                        <td>272,818</td>
                                        <td>920</td>
                                        <td>0.34%</td>
                                        <td>$3.03</td>
                                        <td>$0.90</td>
                                        <td>40</td>
                                        <td>$20.65</td>
                                    </tr>
                                    <tr>
                                        <td>CNE Electrician</td>
                                        <td>Display</td>
                                        <td>$826.05</td>
                                        <td>272,818</td>
                                        <td>920</td>
                                        <td>0.34%</td>
                                        <td>$3.03</td>
                                        <td>$0.90</td>
                                        <td>40</td>
                                        <td>$20.65</td>
                                    </tr>
                                    <tr>
                                        <td>CNE Electrician</td>
                                        <td>Display</td>
                                        <td>$826.05</td>
                                        <td>272,818</td>
                                        <td>920</td>
                                        <td>0.34%</td>
                                        <td>$3.03</td>
                                        <td>$0.90</td>
                                        <td>40</td>
                                        <td>$20.65</td>
                                    </tr>
                                    <tr>
                                        <td>CNE Electrician</td>
                                        <td>Display</td>
                                        <td>$826.05</td>
                                        <td>272,818</td>
                                        <td>920</td>
                                        <td>0.34%</td>
                                        <td>$3.03</td>
                                        <td>$0.90</td>
                                        <td>40</td>
                                        <td>$20.65</td>
                                    </tr>
                                    <tr>
                                        <td>CNE Electrician</td>
                                        <td>Display</td>
                                        <td>$826.05</td>
                                        <td>272,818</td>
                                        <td>920</td>
                                        <td>0.34%</td>
                                        <td>$3.03</td>
                                        <td>$0.90</td>
                                        <td>40</td>
                                        <td>$20.65</td>
                                    </tr>
                                    <tr>
                                        <td>CNE Electrician</td>
                                        <td>Display</td>
                                        <td>$826.05</td>
                                        <td>272,818</td>
                                        <td>920</td>
                                        <td>0.34%</td>
                                        <td>$3.03</td>
                                        <td>$0.90</td>
                                        <td>40</td>
                                        <td>$20.65</td>
                                    </tr>
                                    <tr>
                                        <td>CNE Electrician</td>
                                        <td>Display</td>
                                        <td>$826.05</td>
                                        <td>272,818</td>
                                        <td>920</td>
                                        <td>0.34%</td>
                                        <td>$3.03</td>
                                        <td>$0.90</td>
                                        <td>40</td>
                                        <td>$20.65</td>
                                    </tr>
                                    <tr>
                                        <td>CNE Electrician</td>
                                        <td>Display</td>
                                        <td>$826.05</td>
                                        <td>272,818</td>
                                        <td>920</td>
                                        <td>0.34%</td>
                                        <td>$3.03</td>
                                        <td>$0.90</td>
                                        <td>40</td>
                                        <td>$20.65</td>
                                    </tr>
                                    </tbody>
                                </table>

                            </div><!--/.table-responsive-->

                        </div><!--/.card-body-->
                    </div><!--/.card-->

                </div><!--/.col-xl-12-->

            </div><!--/.row-->


            <div class="row">

                <div class="col-xxl-6">

                    <div class="card mb2rem">
                        <div class="card-header">
                            <i class="bi bi-display"></i> Optimize Display Results
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="row row_gtr1">

                                <div class="col-lg-4 col-md-6">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">Spends</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">$3,891.89</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-lg-4-->

                                <div class="col-lg-4 col-md-6">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">Impressions</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">1,255,618</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-lg-4-->

                                <div class="col-lg-4 col-md-6">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">Clicks</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">3,774</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-lg-4-->

                                <div class="col-lg-3 col-md-6">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">CTR</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">0.3%</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-lg-3-->

                                <div class="col-lg-3 col-md-6">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">CPM</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">$3.10</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-lg-3-->

                                <div class="col-lg-3 col-md-6">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">CPC</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">1.03%</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-lg-3-->

                                <div class="col-lg-3 col-md-6">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">GM Conv.</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">129 <small>($30.17)</small></h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-lg-3-->

                            </div><!--/.row-->

                        </div><!--/.card-body-->

                    </div><!--/.card-->

                </div><!--/.col-xxl-6-->


                <div class="col-xxl-6">

                    <div class="card mb2rem">
                        <div class="card-header">
                            <i class="bi bi-camera-reels"></i> Optimize Video Results
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="row row_gtr1">

                                <div class="col-lg-4 col-md-6">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">Spends</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">$3,891.89</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-lg-4-->

                                <div class="col-lg-4 col-md-6">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">Impressions</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">1,255,618</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-lg-4-->

                                <div class="col-lg-4 col-md-6">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">Clicks</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">3,774</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-lg-4-->

                                <div class="col-lg-3 col-md-6">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">CTR</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">0.3%</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-lg-3-->

                                <div class="col-lg-3 col-md-6">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">CPM</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">$3.10</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-lg-3-->

                                <div class="col-lg-3 col-md-6">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">CPC</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">1.03%</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-lg-3-->

                                <div class="col-lg-3 col-md-6">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">GM Conv.</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">129 <small>($30.17)</small></h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-lg-3-->

                            </div><!--/.row-->

                        </div><!--/.card-body-->

                    </div><!--/.card-->

                </div><!--/.col-xxl-6-->

            </div><!--/.row-->


            <div class="row">

                <div class="col-xl-6">

                    <div class="card mb2rem">
                        <div class="card-header">
                            <i class="bi bi-graph-up-arrow"></i> Performance <i class="bi bi-info-circle-fill info_tooltip_icon" data-toggle="tooltip" data-placement="right" title="Lorem ipsum dolor sit amet"></i>
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <canvas id="chartOne"></canvas>

                        </div><!--/.card-body-->
                    </div><!--/.card-->

                </div><!--/.col-xl-6-->

                <div class="col-xl-6">

                    <div class="card mb2rem">
                        <div class="card-header">
                            <i class="bi bi-graph-up-arrow"></i> Campaign Conversions by Channel <i class="bi bi-info-circle-fill info_tooltip_icon" data-toggle="tooltip" data-placement="right" title="Lorem ipsum dolor sit amet"></i>
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="row">

                                <div class="col-4">
                                    <canvas id="chartTwo"></canvas>
                                </div><!--/.col-4-->

                                <div class="col-4">
                                    <canvas id="chartTwo1"></canvas>
                                </div><!--/.col-4-->

                                <div class="col-4">
                                    <canvas id="chartTwo2"></canvas>
                                </div><!--/.col-4-->

                            </div><!--/.row-->

                        </div><!--/.card-body-->
                    </div><!--/.card-->

                </div><!--/.col-xl-6-->

                <div class="col-xl-6">

                    <div class="card mb2rem">
                        <div class="card-header">
                            <i class="bi bi-graph-up-arrow"></i> Campaign Conversions by Device Type
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="row">

                                <div class="col-md-5">
                                    <canvas id="chartThree"></canvas>
                                </div><!--/.col-md-5-->

                            </div><!--/.row-->

                        </div><!--/.card-body-->
                    </div><!--/.card-->

                </div><!--/.col-xl-6-->

            </div><!--/.row-->


        </div><!--/.theme_content-wrapper-->

    </div><!--/.theme_page-inner-->

</main><!--/.theme_page-wrap-->


<?php include 'incl/footer.php'; ?>
