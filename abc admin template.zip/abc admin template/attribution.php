<?php
global $bodyClass;
$bodyClass = 'inner';
?>

<?php include 'incl/header.php'; ?>

<div class="theme_page-head">
    <div class="tp_head-inner">
        <h2 class="tp_title"><i class="bi bi-grid"></i> Attribution <small>Lorem ipsum dolor</small></h2>

        <div class="tp_head-right">
            <a href="#" class="btn btn-sm btn-primary">Some Button</a>
        </div><!--/.tp_head-right-->

    </div><!--/.tp_head-inner-->
</div><!--/.theme_page-head-->


<main class="theme_page-wrap">

    <div class="theme_page-inner">

        <div class="theme_content-wrapper">

            <div class="row">

                <div class="col-xxl-6 mb2rem">

                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-view-list"></i> Summary
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="row row_gtr1">

                                <div class="col-md-6">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">Spend</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">$3,891.89</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-md-6-->

                                <div class="col-md-6">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">Impressions</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">1,255,619</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-md-6-->

                                <div class="col-md-6">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">Click Through</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">3,774</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-md-6-->

                                <div class="col-md-6">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">GM Conversions</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">130 <small>($29.94)</small></h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-md-6-->

                            </div><!--/.row-->

                        </div><!--/.card-body-->

                    </div><!--/.card-->

                </div><!--/.col-xxl-6-->


                <div class="col-xxl-6 mb2rem">

                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-archive"></i> Attributable Conversions
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="row">

                                <div class="col-md-5">
                                    <canvas id="chartFour"></canvas>
                                </div><!--/.col-md-5-->

                            </div><!--/.row-->

                        </div><!--/.card-body-->

                    </div><!--/.card-->

                </div><!--/.col-xxl-6-->

            </div><!--/.row-->


            <div class="row">

                <div class="col-xl-6 mb2rem">

                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-collection"></i> Campaign Conversions by Channel
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="table-responsive">

                                <table class="table table-bordered table-striped table-hover">
                                    <thead>
                                    <tr>
                                        <th width="33%">Service</th>
                                        <th width="33%">GM Conversion</th>
                                        <th width="33%">% of total <i class="bi bi-info-circle-fill info_tooltip_icon" data-toggle="tooltip" data-placement="right" title="Lorem ipsum dolor sit amet"></i></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>Remarketing</td>
                                        <td>101</td>
                                        <td>77.39%</td>
                                    </tr>
                                    <tr>
                                        <td>Display</td>
                                        <td>123</td>
                                        <td>94.62%</td>
                                    </tr>
                                    <tr>
                                        <td>Video</td>
                                        <td>23</td>
                                        <td>17.69%</td>
                                    </tr>
                                    </tbody>
                                </table>

                            </div><!--/.table-responsive-->

                        </div><!--/.card-body-->
                    </div><!--/.card-->

                </div><!--/.col-xl-6-->

                <div class="col-xl-6 mb2rem">

                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-archive"></i> Campaign Conversions by Interaction Type
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="table-responsive">

                                <table class="table table-bordered table-striped table-hover">
                                    <thead>
                                    <tr>
                                        <th width="33%">Interaction Type</th>
                                        <th width="33%">GM Conversion</th>
                                        <th width="33%">% of GM Conversions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>First <i class="bi bi-info-circle-fill info_tooltip_icon" data-toggle="tooltip" data-placement="right" title="Lorem ipsum dolor sit amet"></i></td>
                                        <td>48</td>
                                        <td>36.92%</td>
                                    </tr>
                                    <tr>
                                        <td>Supporting <i class="bi bi-info-circle-fill info_tooltip_icon" data-toggle="tooltip" data-placement="right" title="Lorem ipsum dolor sit amet"></i></td>
                                        <td>10</td>
                                        <td>7.69%</td>
                                    </tr>
                                    <tr>
                                        <td>Last <i class="bi bi-info-circle-fill info_tooltip_icon" data-toggle="tooltip" data-placement="right" title="Lorem ipsum dolor sit amet"></i></td>
                                        <td>1</td>
                                        <td>0.77%</td>
                                    </tr>
                                    <tr>
                                        <td>First and Last <i class="bi bi-info-circle-fill info_tooltip_icon" data-toggle="tooltip" data-placement="right" title="Lorem ipsum dolor sit amet"></i></td>
                                        <td>71</td>
                                        <td>54.62%</td>
                                    </tr>
                                    </tbody>
                                </table>

                            </div><!--/.table-responsive-->

                        </div><!--/.card-body-->
                    </div><!--/.card-->

                </div><!--/.col-xl-6-->

            </div><!--/.row-->


            <div class="row">

                <div class="col-xl-6 mb2rem">

                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-collection"></i> Campaign Conversions by Type
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="table-responsive">

                                <table class="table table-bordered table-striped table-hover">
                                    <thead>
                                    <tr>
                                        <th width="33%">Conversion Type</th>
                                        <th width="33%">GM Conversion</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>Contact Page</td>
                                        <td>104</td>
                                    </tr>
                                    <tr>
                                        <td>Lead Form Submit</td>
                                        <td>26</td>
                                    </tr>
                                    </tbody>
                                </table>

                            </div><!--/.table-responsive-->

                        </div><!--/.card-body-->
                    </div><!--/.card-->

                </div><!--/.col-xl-6-->

                <div class="col-xl-6 mb2rem">

                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-archive"></i> Campaign Conversions by Device Type
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="row">

                                <div class="col-md-5">
                                    <canvas id="chartThree"></canvas>
                                </div><!--/.col-md-5-->

                            </div><!--/.row-->

                        </div><!--/.card-body-->
                    </div><!--/.card-->

                </div><!--/.col-xl-6-->

            </div><!--/.row-->


            <div class="row">

                <div class="col-xxl-6 mb2rem">

                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-view-list"></i> Optimize Display Summary
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="row row_gtr1">

                                <div class="col-md-4">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">Cost</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">$5,000.00</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-md-4-->

                                <div class="col-md-4">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">Impressions</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">$1,804,549</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-md-4-->

                                <div class="col-md-4">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">Clicks</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">4,985</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-md-4-->

                                <div class="col-md-4">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">CTR</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">0.28%</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-md-4-->

                                <div class="col-md-4">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">CPM</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">2.77%</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-md-4-->

                                <div class="col-md-4">
                                    <div class="card card-solid text-center">
                                        <div class="card-header">CPC</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">1.00%</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-md-4-->

                            </div><!--/.row-->

                        </div><!--/.card-body-->

                    </div><!--/.card-->

                </div><!--/.col-xxl-6-->


                <div class="col-xxl-3 mb2rem">

                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-view-list"></i> Parental Status
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="row row_gtr1">

                                <div class="col-md-6">
                                    <h6 class="text-center">Not Parent</h6>
                                    <div class="card card-solid text-center mb1rem">
                                        <div class="card-header">Cost</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">$5,000.00</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->

                                    <div class="card card-solid text-center">
                                        <div class="card-header">Impressions</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">$1,804,549</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-md-6-->

                                <div class="col-md-6">
                                    <h6 class="text-center">Parent</h6>
                                    <div class="card card-solid text-center mb1rem">
                                        <div class="card-header">Clicks</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">4,985</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->

                                    <div class="card card-solid text-center">
                                        <div class="card-header">CTR</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">0.28%</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-md-6-->

                            </div><!--/.row-->

                        </div><!--/.card-body-->

                    </div><!--/.card-->

                </div><!--/.col-xxl-3-->


                <div class="col-xxl-3 mb2rem">

                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-view-list"></i> Gender
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="row row_gtr1">

                                <div class="col-md-6">
                                    <h6 class="text-center">Female</h6>
                                    <div class="card card-solid text-center mb1rem">
                                        <div class="card-header">Cost</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">$5,000.00</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->

                                    <div class="card card-solid text-center">
                                        <div class="card-header">Impressions</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">$1,804,549</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-md-6-->

                                <div class="col-md-6">
                                    <h6 class="text-center">Male</h6>
                                    <div class="card card-solid text-center mb1rem">
                                        <div class="card-header">Clicks</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">4,985</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->

                                    <div class="card card-solid text-center">
                                        <div class="card-header">CTR</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">0.28%</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-md-6-->

                            </div><!--/.row-->

                        </div><!--/.card-body-->

                    </div><!--/.card-->

                </div><!--/.col-xxl-3-->

            </div><!--/.row-->


            <div class="row">

                <div class="col-xl-6 mb2rem">

                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-graph-up-arrow"></i> Performance <i class="bi bi-info-circle-fill info_tooltip_icon" data-toggle="tooltip" data-placement="right" title="Lorem ipsum dolor sit amet"></i>
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <canvas id="chartOne"></canvas>

                        </div><!--/.card-body-->
                    </div><!--/.card-->

                </div><!--/.col-xl-6-->

                <div class="col-xl-6 mb2rem">

                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-graph-up-arrow"></i> Campaign Conversions by Channel <i class="bi bi-info-circle-fill info_tooltip_icon" data-toggle="tooltip" data-placement="right" title="Lorem ipsum dolor sit amet"></i>
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <canvas id="chartOneA"></canvas>

                        </div><!--/.card-body-->
                    </div><!--/.card-->

                </div><!--/.col-xl-6-->

            </div><!--/.row-->


            <div class="row">

                <div class="col-xl-6 mb2rem">

                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-collection"></i> Sample Websites
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="table-responsive">

                                <table class="table table-bordered table-striped table-hover">
                                    <tbody>
                                    <tr>
                                        <td>conservativebrief.com</td>
                                        <td>nytimes.com</td>
                                    </tr>
                                    <tr>
                                        <td>blogspot.com</td>
                                        <td>heywise.com</td>
                                    </tr>
                                    <tr>
                                        <td>conservativebrief.com</td>
                                        <td>nytimes.com</td>
                                    </tr>
                                    <tr>
                                        <td>blogspot.com</td>
                                        <td>heywise.com</td>
                                    </tr>
                                    <tr>
                                        <td>conservativebrief.com</td>
                                        <td>nytimes.com</td>
                                    </tr>
                                    </tbody>
                                </table>

                            </div><!--/.table-responsive-->

                        </div><!--/.card-body-->
                    </div><!--/.card-->

                </div><!--/.col-xl-6-->

                <div class="col-xl-6 mb2rem">

                    <div class="card">
                        <div class="card-header">
                            <i class="bi bi-collection"></i> Sample Locations
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="table-responsive">

                                <table class="table table-bordered table-striped table-hover">
                                    <tbody>
                                    <tr>
                                        <td>Las Vegas, Nevada</td>
                                        <td>Sunrise Manor, Nevada</td>
                                    </tr>
                                    <tr>
                                        <td>Spring Valley, Nevada</td>
                                        <td>Boulder City, Nevada</td>
                                    </tr>
                                    <tr>
                                        <td>Las Vegas, Nevada</td>
                                        <td>Sunrise Manor, Nevada</td>
                                    </tr>
                                    <tr>
                                        <td>Spring Valley, Nevada</td>
                                        <td>Boulder City, Nevada</td>
                                    </tr>
                                    <tr>
                                        <td>Las Vegas, Nevada</td>
                                        <td>Sunrise Manor, Nevada</td>
                                    </tr>
                                    </tbody>
                                </table>

                            </div><!--/.table-responsive-->

                        </div><!--/.card-body-->
                    </div><!--/.card-->

                </div><!--/.col-xl-6-->

            </div><!--/.row-->


            <div class="mt2rem">
                <p class="small">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Hic officiis quis recusandae voluptatem. Assumenda beatae cupiditate dicta ipsa iusto necessitatibus nemo perferendis reiciendis velit vero? Adipisci, asperiores, consequatur
                    dolorem error impedit incidunt magnam minima modi natus quaerat sequi sit voluptatum. Dicta doloribus ducimus neque nobis nulla perferendis quia, vero? Molestias.</p>

                <p class="small"><b>Attribution:</b> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt expedita magni minus mollitia nobis pariatur perspiciatis quasi. Alias aliquam amet aspernatur assumenda consequuntur cum debitis doloremque dolores eos eum explicabo
                    fugiat magni molestias odit placeat porro possimus praesentium quae quibusdam, recusandae rem reprehenderit repudiandae rerum soluta sunt tempora vel velit!</p>
            </div><!--/.mb2rem-->

        </div><!--/.theme_content-wrapper-->

    </div><!--/.theme_page-inner-->

</main><!--/.theme_page-wrap-->


<?php include 'incl/footer.php'; ?>
