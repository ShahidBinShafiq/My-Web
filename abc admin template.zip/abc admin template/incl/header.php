<?php global $bodyClass; ?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">

    <link href="assets/images/favicon/apple-touch-icon.png" rel="apple-touch-icon" type="image/png" sizes="180x180">
    <link href="assets/images/favicon/favicon-32x32.png" rel="icon" type="image/png" sizes="32x32">
    <link href="assets/images/favicon/favicon-16x16.png" rel="icon" type="image/png" sizes="16x16">
    <link href="assets/images/favicon/manifest.json" rel="manifest">
    <link href="assets/images/favicon/favicon.ico" rel="shortcut icon">

    <title>Impressionable Portal</title>

    <style>
        .theme_wrapper {
            opacity: 0;
        }
    </style>

    <link rel="stylesheet preload prefetch" as="style" href="assets/css/main.css">

</head>

<body class="<?php echo 'page_' . $bodyClass ?>">

<div class="preload_wrap"></div>

<div class="theme_wrapper">


    <header class="theme_header">

        <div class="theme_header-inner">

            <button class="aside_toggle-button" tabindex="1"></button>

            <a href="overview.php" class="theme_logo">
                <img class="main_logo-img" src="assets/images/logo_wide-grey.svg" alt="">
                <img class="print_logo-img" src="assets/images/logo_print-only.svg" alt="">
            </a><!--/.theme_logo-->

            <div class="header_right-wrap">
                <ul class="top_right-nav-list">
                    <li><a href="#"><i class="bi bi-chat"></i></a></li>
                    <li><a href="#"><i class="bi bi-bell"></i></a></li>
                    <li><a href="index.php"><i class="bi bi-person-workspace"></i></a></li>
                </ul>
            </div><!--/.header_right-wrap-->

            <button class="mobile_navbar-toggle">
                <svg viewBox="0 0 100 100">
                    <path class="nt_line nt_line-one"
                          d="M 20,29.000046 H 80.000231 C 80.000231,29.000046 94.498839,28.817352 94.532987,66.711331 94.543142,77.980673 90.966081,81.670246 85.259173,81.668997 79.552261,81.667751 75.000211,74.999942
                              75.000211,74.999942 L 25.000021,25.000058"/>
                    <path class="nt_line nt_line-two" d="M 20,50 H 80"/>
                    <path class="nt_line nt_line-three"
                          d="M 20,70.999954 H 80.000231 C 80.000231,70.999954 94.498839,71.182648 94.532987,33.288669 94.543142,22.019327 90.966081,18.329754 85.259173,18.331003 79.552261,18.332249 75.000211,25.000058
                              75.000211,25.000058 L 25.000021,74.999942"/>
                </svg>
            </button><!--/.mobile_navbar-toggle-->

        </div><!--/.theme_header-inner-->

    </header><!--/.theme_header-->


    <aside class="theme_aside theme_aside-hover">

        <div class="theme_aside-inner">

            <nav class="aside_nav">

                <ul class="aside_nav-list" id="asideNavList">

                    <li class="nav_item">
                        <a href="overview.php" class="nav_link active">
                            <i class="bi bi-grid"></i>
                            <span>Overview</span>
                        </a>
                    </li>

                    <li class="nav_item">
                        <a href="reports.php" class="nav_link">
                            <i class="bi bi-printer"></i>
                            <span>Reports</span>
                        </a>
                    </li>

                    <li class="nav_item">
                        <a href="demographics.php" class="nav_link">
                            <i class="bi bi-briefcase"></i>
                            <span>Demographics</span>
                        </a>
                    </li>

                    <li class="nav_item">
                        <a href="attribution.php" class="nav_link">
                            <i class="bi bi-chat-square-text"></i>
                            <span>Attribution</span>
                        </a>
                    </li>

                    <li class="nav_item nav_item-toggle">
                        <a href="#" class="nav_link collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false">
                            <i class="bi bi-sticky"></i>
                            <span>Dropdown Item</span>
                        </a>
                        <div class="collapse collapse_toggle" id="collapseOne" data-parent="#asideNavList">
                            <ul class="aside_subnav-list">
                                <li><a href="inner-page.php">Lorem ipsum dolor</a></li>
                                <li><a href="inner-page.php">Lorem ipsum dolor</a></li>
                                <li><a href="inner-page.php">Lorem ipsum dolor</a></li>
                                <li><a href="inner-page.php">Lorem ipsum dolor</a></li>
                                <li><a href="inner-page.php">Lorem ipsum dolor</a></li>
                                <li><a href="inner-page.php">Lorem ipsum dolor</a></li>
                            </ul>
                        </div>
                    </li>


                </ul>

            </nav><!--/.aside_nav-->

        </div><!--/.theme_aside-inner-->

    </aside><!--/.theme_aside-->


