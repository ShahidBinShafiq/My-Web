<footer class="footer_wrap">

    <div class="footer_inner">
        <p>Copyright © 2022 Digital Functionalism. All Rights Reserved.</p>
        <p>Page Generated in 0.16 Seconds. Memory Used: 0.8MB</p>
    </div><!--/.footer_inner-->

</footer><!--/.footer_wrap-->

</div><!--/.theme_wrapper-->

<script src="assets/js/jquery-3.6.0.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/chart.js"></script>
<script src="assets/js/charts.init.js"></script>
<script src="assets/js/main.js"></script>

</body>
</html>
