<?php
global $bodyClass;
$bodyClass = 'inner';
?>

<?php include 'incl/header.php'; ?>

<div class="theme_page-head">
    <div class="tp_head-inner">
        <h2 class="tp_title"><i class="bi bi-grid"></i> Demographics <small>Lorem ipsum dolor</small></h2>

        <div class="tp_head-right">
            <a href="#" class="btn btn-sm btn-primary">Some Button</a>
        </div><!--/.tp_head-right-->

    </div><!--/.tp_head-inner-->
</div><!--/.theme_page-head-->


<main class="theme_page-wrap">

    <div class="theme_page-inner">


        <div class="theme_content-wrapper">

            <div class="row">

                <div class="col-xxl-3">

                    <div class="card mb2rem">
                        <div class="card-header">
                            <i class="bi bi-hdd-rack"></i> Parental Status <i class="bi bi-info-circle-fill info_tooltip_icon" data-toggle="tooltip" data-placement="right" title="Lorem ipsum dolor sit amet"></i>
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="row row_gtr1">

                                <div class="col-md-6">
                                    <h6 class="text-center">Not Parent</h6>
                                    <div class="card card-solid text-center mb1rem">
                                        <div class="card-header">Clicks</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">58.04%</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->

                                    <div class="card card-solid text-center">
                                        <div class="card-header">Impressions</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">65.94%</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->

                                </div><!--/.col-md-6-->

                                <div class="col-md-6">
                                    <h6 class="text-center">Parents</h6>
                                    <div class="card card-solid text-center mb1rem">
                                        <div class="card-header">Click</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">41.96%</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->

                                    <div class="card card-solid text-center">
                                        <div class="card-header">Impressions</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">34.06%</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-md-6-->

                            </div><!--/.row-->

                        </div><!--/.card-body-->

                    </div><!--/.card-->

                </div><!--/.col-xxl-3-->


                <div class="col-xxl-3">

                    <div class="card mb2rem">
                        <div class="card-header">
                            <i class="bi bi-people"></i> Gander
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <div class="row row_gtr1">

                                <div class="col-md-6">
                                    <h6 class="text-center">Female</h6>
                                    <div class="card card-solid text-center mb1rem">
                                        <div class="card-header">Clicks</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">43.52%</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->

                                    <div class="card card-solid text-center">
                                        <div class="card-header">Impressions</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">46.45%</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->

                                </div><!--/.col-md-6-->

                                <div class="col-md-6">
                                    <h6 class="text-center">Male</h6>
                                    <div class="card card-solid text-center mb1rem">
                                        <div class="card-header">Clicks</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">56.48%</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->

                                    <div class="card card-solid text-center">
                                        <div class="card-header">Impressions</div>
                                        <div class="card-body">
                                            <h6 class="card-title mb-0">54.55%</h6>
                                        </div><!--/.card-body-->
                                    </div><!--/.card-->
                                </div><!--/.col-md-6-->

                            </div><!--/.row-->

                        </div><!--/.card-body-->

                    </div><!--/.card-->

                </div><!--/.col-xxl-3-->


                <div class="col-xxl-6">

                    <div class="card mb2rem">
                        <div class="card-header">
                            <i class="bi bi-calendar-week"></i> Age
                        </div><!--/.card-header-->

                        <div class="card-body">

                            <canvas id="chartOne"></canvas>

                        </div><!--/.card-body-->
                    </div><!--/.card-->

                </div><!--/.col-xxl-6-->

            </div><!--/.row-->


            <div class="mt2rem">
                <p class="small">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Hic officiis quis recusandae voluptatem. Assumenda beatae cupiditate dicta ipsa iusto necessitatibus nemo perferendis reiciendis velit vero? Adipisci, asperiores, consequatur
                    dolorem error impedit incidunt magnam minima modi natus quaerat sequi sit voluptatum. Dicta doloribus ducimus neque nobis nulla perferendis quia, vero? Molestias.</p>

                <p class="small"><b>Attribution:</b> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt expedita magni minus mollitia nobis pariatur perspiciatis quasi. Alias aliquam amet aspernatur assumenda consequuntur cum debitis doloremque dolores eos eum explicabo
                    fugiat magni molestias odit placeat porro possimus praesentium quae quibusdam, recusandae rem reprehenderit repudiandae rerum soluta sunt tempora vel velit!</p>
            </div><!--/.mb2rem-->


        </div><!--/.theme_content-wrapper-->

    </div><!--/.theme_page-inner-->

</main><!--/.theme_page-wrap-->


<?php include 'incl/footer.php'; ?>
