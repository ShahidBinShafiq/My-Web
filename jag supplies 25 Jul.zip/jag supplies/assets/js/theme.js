// side-bar-collapes

let sideToggleBtn = document.getElementById('sidebar-toggle');
let mainContent = document.getElementById('main');
let sideBar = document.getElementById('jagSidebar');

sideToggleBtn.addEventListener('click', function(){
    sideBar.classList.toggle('slide-toggle')
    mainContent.classList.toggle('main-content-padding')
})

// add active class to 

$(document).ready(function(){
    $('.copm-item').click(function(){
      $('.copm-item').removeClass("active");
      $(this).addClass("active");
  });
});



// form validation

function formValidation() {
  const submitButton = document.querySelector(".form-submit");
  submitButton.addEventListener("click", function () {
    validateFormonSubmit();
  });
  validateForm();
}
function inputValidate(target, input) {
  const parent = target.parentElement;
  const value = target.value;
  const inputClasses = Array.from(input.classList);
  const isRequired = inputClasses.find(function (cls) {
    return cls === "field-required";
  });
  if (isRequired) {
    if (value == "") {
      parent.classList.add("error");
    } else {
      parent.classList.remove("error");
    }
  }
}
function validateForm(params) {
  const formPod = document.querySelector(".form-pod");
  const inputs = formPod.getElementsByClassName("form-control");
  if (inputs) {
    const inputFields = Array.from(inputs);
    inputFields.forEach(function (input) {
      input.addEventListener("input", function (e) {
        inputValidate(e.target, input);
      });
      input.addEventListener("blur", function (e) {
        inputValidate(e.target, input);
      });
    });
  }
}
function validateFormonSubmit(params) {
  const formPod = document.querySelector(".form-pod");
  const inputs = formPod.getElementsByClassName("form-control");
  if (inputs) {
    const inputFields = Array.from(inputs);
    inputFields.forEach(function (input) {
      inputValidate(input, input);
    });
  }
}
formValidation();