<?php include 'incl/header.php'; ?>

    <main class="page__wrap">
        <div class="term-cond-wrap section-space">
           <div class="container-md">
               <div class="tac-wrap-inner">
                   <div class="tac-pag-title">
                       <h2>Terms & Conditions</h2>
                   </div><!-- /.tac-pag-title -->
                   <div class="tac-description">
                        <p>Please read all these terms and conditions. </p>
                        <p>As we can accept your order and make a legally enforceable agreement without further reference to you, you must read these terms and conditions to make sure that they contain all that you want and nothing that you are not happy with.</p>
                        <p>Unless you accept these Terms (by ticking the acceptance box when you set up your account, you will not be able to place an order.</p>
                        <p>Slikk reserve the right to change the Terms from time to time. We will notify you of any changes which may affect you by email.</p>
                   </div><!-- /.tac-description -->

                   <div class="faq-accordions-wrap">
                    <div class="accordion" id="tac-accordion">
  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item1">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse1" aria-expanded="true" aria-controls="tac-collapse1">
      Application
      </button>
    </h2>
    <div id="tac-collapse1" class="accordion-collapse collapse show" aria-labelledby="tac-item1" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item2">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse2" aria-expanded="false" aria-controls="tac-collapse2">
        Interpretation
      </button>
    </h2>
    <div id="tac-collapse2" class="accordion-collapse collapse" aria-labelledby="tac-item2" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item3">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse3" aria-expanded="false" aria-controls="tac-collapse3">
      Placing an Order
      </button>
    </h2>
    <div id="tac-collapse3" class="accordion-collapse collapse" aria-labelledby="tac-item3" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item4">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse4" aria-expanded="false" aria-controls="tac-collapse4">
      Changes to an Order
      </button>
    </h2>
    <div id="tac-collapse4" class="accordion-collapse collapse" aria-labelledby="tac-item4" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>
  

  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item5">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse5" aria-expanded="false" aria-controls="tac-collapse5">
      Order Cancellation
      </button>
    </h2>
    <div id="tac-collapse5" class="accordion-collapse collapse" aria-labelledby="tac-item5" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item6">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse6" aria-expanded="false" aria-controls="tac-collapse6">
      Our rights to cancel an order
      </button>
    </h2>
    <div id="tac-collapse6" class="accordion-collapse collapse" aria-labelledby="tac-item6" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item7">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse7" aria-expanded="false" aria-controls="tac-collapse7">
      Customer responsibilities
      </button>
    </h2>
    <div id="tac-collapse7" class="accordion-collapse collapse" aria-labelledby="tac-item7" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item8">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse8" aria-expanded="false" aria-controls="tac-collapse8">
      Collection and Delivery
      </button>
    </h2>
    <div id="tac-collapse8" class="accordion-collapse collapse" aria-labelledby="tac-item8" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item9">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse9" aria-expanded="false" aria-controls="tac-collapse9">
      Standards of Service
      </button>
    </h2>
    <div id="tac-collapse9" class="accordion-collapse collapse" aria-labelledby="tac-item9" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item10">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse10" aria-expanded="false" aria-controls="tac-collapse10">
      Monthly Membership Plans
      </button>
    </h2>
    <div id="tac-collapse10" class="accordion-collapse collapse" aria-labelledby="tac-item10" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item11">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse11" aria-expanded="false" aria-controls="tac-collapse11">
      Personal information and Registration
      </button>
    </h2>
    <div id="tac-collapse11" class="accordion-collapse collapse" aria-labelledby="tac-item11" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item12">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse12" aria-expanded="false" aria-controls="tac-collapse12">
      Fees and Payment
      </button>
    </h2>
    <div id="tac-collapse12" class="accordion-collapse collapse" aria-labelledby="tac-item12" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item13">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse13" aria-expanded="false" aria-controls="tac-collapse13">
      Our liability to you
      </button>
    </h2>
    <div id="tac-collapse13" class="accordion-collapse collapse" aria-labelledby="tac-item13" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item14">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse14" aria-expanded="false" aria-controls="tac-collapse14">
      Loyalty Scheme
      </button>
    </h2>
    <div id="tac-collapse14" class="accordion-collapse collapse" aria-labelledby="tac-item14" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item15">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse15" aria-expanded="false" aria-controls="tac-collapse15">
      Quality Guarantee
      </button>
    </h2>
    <div id="tac-collapse15" class="accordion-collapse collapse" aria-labelledby="tac-item15" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item16">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse16" aria-expanded="false" aria-controls="tac-collapse16">
      Re-Cleaning
      </button>
    </h2>
    <div id="tac-collapse16" class="accordion-collapse collapse" aria-labelledby="tac-item16" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item17">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse17" aria-expanded="false" aria-controls="tac-collapse17">
      Vouchers & Promotions
      </button>
    </h2>
    <div id="tac-collapse17" class="accordion-collapse collapse" aria-labelledby="tac-item17" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item18">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse18" aria-expanded="false" aria-controls="tac-collapse18">
      Referrals
      </button>
    </h2>
    <div id="tac-collapse18" class="accordion-collapse collapse" aria-labelledby="tac-item18" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item19">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse19" aria-expanded="false" aria-controls="tac-collapse19">
      Conformity
      </button>
    </h2>
    <div id="tac-collapse19" class="accordion-collapse collapse" aria-labelledby="tac-item19" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item20">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse20" aria-expanded="false" aria-controls="tac-collapse20">
      Duration, termination and suspension
      </button>
    </h2>
    <div id="tac-collapse20" class="accordion-collapse collapse" aria-labelledby="tac-item20" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>

  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item21">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse21" aria-expanded="false" aria-controls="tac-collapse21">
      Successors and our sub-contractors
      </button>
    </h2>
    <div id="tac-collapse21" class="accordion-collapse collapse" aria-labelledby="tac-item21" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item22">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse22" aria-expanded="false" aria-controls="tac-collapse22">
      Circumstances beyond the control of either party
      </button>
    </h2>
    <div id="tac-collapse22" class="accordion-collapse collapse" aria-labelledby="tac-item22" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


  <div class="accordion-item">
    <h2 class="accordion-header" id="tac-item23">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tac-collapse23" aria-expanded="false" aria-controls="tac-collapse23">
      Governing law, jurisdiction and complaints
      </button>
    </h2>
    <div id="tac-collapse23" class="accordion-collapse collapse" aria-labelledby="tac-item23" data-bs-parent="#tac-accordion">
      <div class="accordion-body">
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolore repudiandae cum? Molestias animi ea fuga dolore similique asperiores modi.</p>
      </div>
    </div>
  </div>


</div>
                   </div><!-- /.faq-accordions-wrap-->
               </div><!-- /.tac-wrap-inner -->
           </div><!-- /.container-md -->
        </div><!-- /.term-cond-wrap -->
    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>