<footer class="footer__wrap aside_space">

<div class="footer-cols">
           <div class="container-md">
                <div class="footer-cols-inner">
                <div class="row">
                <div class="col-md-4">
                    <div class="foot-col">
                        <a href="./index.php">
                        <img src="assets/images/icons/brand-logo.svg" alt="" class="brand-logo">
                        </a>
                    <ul class="social-list">
                        <li>
                            <a href="#">
                            <i class="icon-facebook"></i>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                            <i class="icon-twitter"></i>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                            <i class="icon-instagram"></i>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                            <i class="icon-linkedin"></i>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                            <i class="icon-tiktok"></i>
                            </a>
                        </li>
                       
                        <li>
                            <a href="#">
                            <i class="icon-snapchat"></i>
                            </a>
                        </li>
                    </ul>
                    </div>
                </div>
                <div class="col-md-2">
                  <div class="foot-col">
                  <b>About</b>
                    <ul>
                        <li>
                            <a href="#">About Us / Why Slikk?</a>
                        </li>
                        <li>
                            <a href="#">Help / FAQs</a>
                        </li>
                        <li>
                            <a href="./contact.php">Contact</a>
                        </li>
                    </ul>
                  </div>
                </div>
                <div class="col-md-2">
                    <div class="foot-col">
                    <b>Other</b>
                    <ul>
                        <li>
                            <a href="termsconditions.php">Terms & Conditions</a>
                        </li>
                        <li>
                            <a href="privacy.php">Privacy Policy</a>
                        </li>
                        <li>
                            <a href="#">Blog</a>
                        </li>
                    </ul>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="foot-col">
                        <b>Subscribe to our newsletter</b>
                        <div class="subscribe-pod">
                        <input type="text" placeholder="enter your email" class="subscribe-news">
                        <a href="#" class="theme-btn btn-black-theme">Subscribe</a>
                        </div>
                    </div>
                </div>
            </div>
                </div><!-- /.footer-cols-inner -->
           </div><!-- /.container -->
    </div><!-- /.footer-cols -->

    <div class="footer-bottom-strip">

            <div class="container-md">

                <div class="footer-bottom-strip-inner">

                        <div class="row">
                            <div class="col-md-6">
                                <div class="strip-col">
                                    <p>© 2022 Slikk Limited. All rights reserved.</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="strip-col">
                                    <ul>
                                        <li>
                                            <a href="#">
                                               <i class="icon-mastercard"></i>
                                            </a>
                                        </li>

                                        <li>
                                            <a href="#">
                                            <i class="icon-visa"></i>

                                            </a>
                                        </li>

                                        <li>
                                            <a href="#">
                                            <i class="icon-googlepay"></i>

                                            </a>
                                        </li>

                                        <li>
                                            <a href="#">
                                            <i class="icon-applepay"></i>

                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                </div><!-- /.footer-bottom-strip-inner -->
            </div><!-- /.container -->
    </div><!-- /.footer-bottom-strip -->
</footer><!--/.footer__wrap-->

</div><!--/.site__wrapper-->

<script src="assets/js/jquery-3.5.1.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- <script src="assets/js/aos.min.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/7.4.1/swiper-bundle.min.js"></script>
<script src="assets/js/theme.js"></script>
</body>
</html>
