
<?php include 'incl/header.php'; ?>

    <main class="page__wrap">
        <div class="login-wrapper">
            <div class="login-inner">
                <div class="login-title">
                  <h1>Forgot Password?</h1>
                  <p>Just let us know Your Registered Email</p>
                </div>

                <div class="login-pods">
                  <form action="">
                 
                <div class="mb-3">
                  <input type="email" class="form-control"  placeholder="Enter Your Email Address*">
                </div>

                </div><!-- /.login-credentials -->
                  <div class="login-footer">
                      <div class="login-btns">
                        <button type="submit" class="theme-btn btn-black-theme login-btn">Send me my password</button>
                      </div>
                  </div><!-- /.login-footer -->
                  </form>
                </div>


            </div><!-- /.login-inner -->
        </div><!-- /.login-wrapper -->

    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>