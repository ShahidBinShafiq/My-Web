<?php include 'incl/header.php'; ?>

    <main class="page__wrap">
       <div class="account-wrapper">
          <div class="account-inner">
            <div class="account-title">
                  <h1>Create an account</h1>
            </div><!-- /.account-title -->
             <div class="account-form">
              <form action="">
                  <div class="row">
                    <div class="col-md-6">
                    <div class="form-group mb-3">
                         <label class="user-acct-pod-label mb-1">Name<span>*</span></label>
                        <input type="text" class="form-control user-acct-field" placeholder="Name">

                        </div>
                    </div>


                    <div class="col-md-6">
                    <div class="form-group mb-3">
                         <label class="user-acct-pod-label mb-1">Contact Number<span>*</span></label>
                        <input type="text" class="form-control user-acct-field" placeholder="Contact Number">

                        </div>
                    </div>




                    <div class="col-md-12">
                    <div class="form-group mb-3">
                         <label class="user-acct-pod-label mb-1">Email Address<span>*</span></label>
                        <input type="email" class="form-control user-acct-field" placeholder="Email Address">

                        </div>
                    </div>


                    <div class="col-md-6">
                    <div class="form-group mb-3">
                         <label class="user-acct-pod-label mb-1">Password<span>*</span></label>

                             <div class="fieldwd-icon">
                        <input type="password" class="form-control form-password-field user-acct-field"  placeholder="Password*">
                        <i class="icon-eye-view form-field-icon toggle-password"></i>
                        </div><!-- /.fieldwd-icon -->




                        </div>
                    </div>


                    <div class="col-md-6">
                    <div class="form-group mb-3">
                         <label class="user-acct-pod-label mb-1">Re-Enter Password <span>*</span></label>
                         <div class="fieldwd-icon">
                        <input type="password" class="form-control form-password-field user-acct-field"  placeholder="Re-Enter Password">
                        <i class="icon-eye-view form-field-icon toggle-password"></i>
                        </div><!-- /.fieldwd-icon -->

                        </div>


               




                    </div>



                    <div class="col-md-12">
                    <div class="form-group mb-3">
                         <label class="user-acct-pod-label mb-1"> Accommodation Type <span>*</span></label>
                         <select class="form-select form-control user-acct-field accomodation-type" aria-label="Default select example">
                            <option selected>Please Select</option>
                            <option value="University Provided">University Provided</option>
                            <option value="Private">Private</option>
                        </select>

                        </div>
                    </div>



                    <div class="col-md-12">
                      <div class="accomodation-type-option" id="accomodation-type">
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group mb-3 uni-select-option">
                          <label class="user-acct-pod-label mb-1">University <span>*</span></label>
                          <select class="form-select form-control user-acct-field uni-select-pod" aria-label="Default select example">
                              <option selected>Please Select</option>
                              <option value="University of Greenwich">University of Greenwich</option>
                              <option value="Middlesex University">Middlesex University</option>
                          </select>

                        </div>
                        </div>

                        <div class="col-md-6">
                          <div class="form-group mb-3 hall-select-option" id="hall-select-option">
                          <label class="user-acct-pod-label mb-1">Hall of Residence <span>*</span></label>
                          <select class="form-select form-control user-acct-field" aria-label="Default select example">
                              <option selected>Please Select</option>
                              <option value="Platt Hall">Platt Hall</option>
                              <option value="Usher Hall">Usher Hall</option>
                          </select>

                        </div>
                        </div>


                        <div class="col-md-12">
                          <div class="form-group mb-3 flat-select-option">
                          <label class="user-acct-pod-label mb-1">Room / Flat Number <span>*</span></label>
                          <input type="text" class="form-control user-acct-field" placeholder="Room / Flat Number">


                        </div>
                        </div>

                      </div><!-- /.row -->
                      </div><!-- /.accomodation-type -->
                    </div>

                    <div class="private-accommodation">
                        <div class="row">
                          <div class="col-md-6">
                          <div class="form-group mb-3">
                          <label class="user-acct-pod-label mb-1">Address <span>*</span></label>
                          <input type="text" class="form-control user-acct-field" placeholder="Address">


                        </div>
                          </div>

                          <div class="col-md-6">
                          <div class="form-group mb-3">
                          <label class="user-acct-pod-label mb-1">Postcode <span>*</span></label>
                          <input type="text" class="form-control user-acct-field" placeholder="Postcode">


                        </div>
                          </div>



                        </div>
                    </div><!-- /.private-accommodation -->


                  </div><!-- /.row -->

                  <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="terms">
                  <label class="form-check-label" for="terms">
                    I agree to Slikk <a href="#">Terms & Conditions</a>
                  </label>
                  </div>


                  <div class="acct-btn">
                    <button type="submit" id="registerbtn" class="theme-btn btn-black-theme btn-account">Register</button>
                  </div><!-- /.acct-btn -->
              </form>
             </div>
          </div><!-- /.account-inner -->
       </div><!-- /.account-wrapper -->

    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>