<?php include 'incl/header.php'; ?>

    <main class="page__wrap">

        <div class="error-page-wrap section-space">
           <div class="error-page-inner">
            <img src="assets/images/404-page.svg" alt="">
            <div class="page-title">
                <h1>404 <small>The requested URL/404 was not found on this server.</small></h1>
            </div><!-- /.page-title -->
            <a href="index.php" class="theme-btn btn-black-theme error-pagebtn">Take me back to the Home Page</a>
           </div><!-- /.error-page-inner -->
        </div><!-- /.error-page-wrap -->

    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>