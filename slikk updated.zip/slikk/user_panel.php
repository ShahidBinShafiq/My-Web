<?php include 'incl/header.php'; ?>

<main class="page__wrap">

    <div class="order-section form-wizard" id="order-sec">
        <div class="order-steps">

            <div class="form-wizard-header">
                <div class="order-container">
                    <div class="order-section-inner form-wizard-header-inner">
                        <div class="wizard-header-col order-col-left">
                            <ul class="list-unstyled form-wizard-steps clearfix">
                                <li data-title="Address" data-step="1" class="active">

                                    <span>1</span>

                                </li>
                                <li data-title="Item Selection" data-step="2">
                                    <span>2</span>
                                </li>
                                <li data-title="Collection & Delivery" data-step="3" data-steps="2">
                                    <span>3</span>

                                </li>
                                <li data-title="Contact Details" data-step="4">
                                    <span>4</span>
                                </li>

                            </ul>
                        </div>
                        <div class="wizard-header-col order-col-right">
                            <div class="form-group clearfix">
                                <a href="javascript:;" class="form-wizard-previous-btn wizard-btn float-left">
                                    <i class="icon-arrow-left"></i>
                                    <span>Prev</span>
                                </a>
                                <a href="javascript:;" class="form-wizard-next-btn wizard-btn activatedBtn float-right">
                                    <i class="icon-arrow-right"></i>
                                    <span>Next</span>
                                </a>
                            </div>
                        </div>
                    </div><!-- /.form-wizard-header-inner -->
                </div><!-- /.order-container -->
            </div><!-- /.form-wizard-header-inner -->


        </div><!-- /.order-steps -->
        <div class="order-container">
            <div class="order-section-inner">
                <div class="order-col order-col-left">


                    <div>
                        <form action="" method="post" role="form">

                            <fieldset class="wizard-fieldset show field-1">
                                <div class="wizard-field-inner">
                                    <div class="step-title">
                                        <h4>Address</h4>
                                    </div><!-- /.step-title -->
                                    <div class="step-fields-pod">
                                        <div class="form-group">
                                            <label for="fname" class="wizard-form-text-label">PostCode</label>
                                            <input type="text" class="form-control wizard-required" id="fname" placeholder="E13 9EJ">

                                        </div>
                                        <div class="form-group">
                                            <label for="lname" class="wizard-form-text-label">Select Your Address</label>
                                            <select id="inputState" name='address' class="form-select form-control wizard-required select-placeholder">
                                                <option value=''>Please select your address</option>
                                                <option value='addressline'>Address Line One</option>
                                            </select>
                                        </div>
                                        <!-- <div class="form-group">
                                            Gender
                                            <div class="wizard-form-radio">
                                                <input name="radio-name" id="radio1" type="radio">
                                                <label for="radio1">Male</label>
                                            </div>
                                            <div class="wizard-form-radio">
                                                <input name="radio-name" id="radio2" type="radio">
                                                <label for="radio2">Female</label>
                                            </div>
                                        </div> -->
                                        <div class="form-group">

                                            <label for="zcode" class="wizard-form-text-label">Address Line 2</label>
                                            <input type="text" class="form-control wizard-required" id="zcode" placeholder="Please specify any extra address details">
                                        </div>
                                        <!--                <div class="form-group clearfix">-->
                                        <!--                    <a href="javascript:;" class="form-wizard-next-btn float-right">Next</a>-->
                                        <!--                </div>-->
                                    </div><!-- /.step-fields-pod -->
                                </div><!-- /.wizard-field-inner -->
                            </fieldset>


                            <fieldset class="wizard-fieldset field-2">
                                <div class="wizard-field-inner">

                                    <div class="items-pod">

                                        <div class="step-title">
                                            <h4>Select your items</h4>
                                        </div><!-- /.step-title -->

                                        <div class="items-slider">

                                            <div class="swiper">

                                                <div class="swiper-wrapper">

                                                    <div class="swiper-slide">
                                                        <div>
                                                            <a href="javascript:void(0)" class="tb_nav-item active" data-ctb-target="tabOne">
                                                                <i class="icon-laundry"></i>
                                                            </a>
                                                            <p>Laundry</p>
                                                        </div>
                                                    </div>

                                                    <div class="swiper-slide">
                                                        <div>
                                                            <a href="javascript:void(0)" class="tb_nav-item" data-ctb-target="tabTwo">
                                                                <i class="icon-iron-only"></i>
                                                            </a>
                                                            <p>Iron Only</p>
                                                        </div>
                                                    </div>

                                                    <div class="swiper-slide">
                                                        <div>
                                                            <a href="javascript:void(0)" class="tb_nav-item" data-ctb-target="tabThree">
                                                                <i class="icon-user-home"></i>
                                                            </a>

                                                            <p>Home</p>
                                                        </div>
                                                    </div>

                                                    <div class="swiper-slide">
                                                        <div>
                                                            <a href="javascript:void(0)" class="tb_nav-item" data-ctb-target="tabFour">
                                                                <i class="icon-shirts-top"></i>
                                                            </a>
                                                            <p>Shirts/Tops</p>
                                                        </div>
                                                    </div>

                                                    <div class="swiper-slide">
                                                        <div>
                                                            <a href="javascript:void(0)" class="tb_nav-item" data-ctb-target="tabFive">
                                                                <i class="icon-suits"></i>
                                                            </a>
                                                            <p>Suits</p>
                                                        </div>
                                                    </div>

                                                    <div class="swiper-slide">
                                                        <div>
                                                            <a href="javascript:void(0)" class="tb_nav-item" data-ctb-target="tabSix">
                                                                <i class="icon-skirt"></i>
                                                            </a>
                                                            <p>Dress/Skirt</p>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div>
                                                            <a href="javascript:void(0)" class="tb_nav-item" data-ctb-target="tabSeven">
                                                                <i class="icon-trouser"></i>
                                                            </a>
                                                            <p>Trousers</p>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div>
                                                            <a href="javascript:void(0)" class="tb_nav-item" data-ctb-target="tabEight">
                                                                <i class="icon-outdoor-item"></i>
                                                            </a>
                                                            <p>Outdoor</p>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div>
                                                            <a href="javascript:void(0)" class="tb_nav-item" data-ctb-target="tabNine">
                                                                <i class="icon-students"></i>
                                                            </a>
                                                            <p>Students</p>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div><!--/.swiper-->

                                            <div class="swiper-button-prev"></div>
                                            <div class="swiper-button-next"></div>


                                        </div> <!-- /.items-slider -->

                                    </div><!-- /.item-pod -->


                                    <div class="tab_content-wrap">

                                        <div class="tab_content tc_active" id="tabOne">
                                            <div class="tc-inner">
                                                <div class="row">
                                                    <div class="col-md-8">
                                                        <div class="svc-item">
                                                            <div class="svc-item-pod">
                                                                <div class="figure">
                                                                    <figure class="preview-item">
                                                                        <img class="img-view" src="assets/images/svc-items/laundry1.png" alt="">
                                                                    </figure>
                                                                </div><!-- /.figure -->
                                                                <div class="fig-caption">
                                                                    <figcaption>
                                                                        <div class="item-title">
                                                                            <h4>6 Kg Wash dry & fold</h4>
                                                                            <ul>
                                                                                <li>(1 x Mix Wash)</li>
                                                                                <li>(Excl Blankets, Pillow & Duvets)</li>
                                                                                <li> (No Colour Seperation)</li>
                                                                                <li> (Minimum Wash at 30 Degree)</li>
                                                                                <li> (Medium Heat Tumble Dry)</li>

                                                                            </ul>
                                                                        </div>
                                                                        <span class="svc-price">£2.00</span>
                                                                        <div class="item-select">
                                                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                                                        </div>
                                                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                                                    </figcaption>
                                                                </div>

                                                            </div><!-- /.svc-item-pod -->
                                                        </div>
                                                    </div><!-- /.col-md-6 -->

                                                </div><!-- /.row -->

                                            </div><!-- /.tc-inner -->

                                            <div class="user-guide-modal">
                                                <!-- Button trigger modal -->
                                                <button type="button" class="btn-modal-laundry-info" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                                    <span class="user-guide-btn">Laundry Guide</span>
                                                </button>

                                                <!-- Modal -->
                                                <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h4 class="modal-title" id="staticBackdropLabel">Wash Dry and Fold order what to include</h4>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="ug-lists">
                                                                    <div class="ug-list-title">
                                                                        <p>Safe to Include</p>
                                                                    </div><!-- /.ug-list-title -->
                                                                    <ul class="ug-include-list ug-list">
                                                                        <li>All personal laundry that can be washed & tumble dried.</li>
                                                                        <li>You can include bed linen and towel but we advise you to put them in a separate bag as they usually require a different washing/drying cycle.</li>
                                                                        <li>Bath mats</li>
                                                                    </ul>
                                                                    <div class="ug-list-title">
                                                                        <p>Do not Include</p>
                                                                    </div><!-- /.ug-list-title -->
                                                                    <ul class="ug-exclude-list ug-list">
                                                                        <li>Dry clean only items</li>
                                                                        <li>Items that cannot be tumble dried.</li>
                                                                        <li>All items that are not suitable for machine washing and tumble drying</li>
                                                                        <li>Any garments that can shrunk during tumble drying process</li>
                                                                    </ul>
                                                                </div><!-- /.ug-include-list -->
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="theme-btn btn-theme-dark" data-bs-dismiss="modal">Close</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div><!-- /.user-guide-modal -->


                                        </div>

                                        <div class="tab_content" id="tabTwo">
                                            <div class="tc-inner">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="svc-item">
                                                            <div class="svc-item-pod">
                                                                <div class="figure">
                                                                    <figure class="preview-item">
                                                                        <img class="img-view" src="assets/images/svc-items/iron1.png" alt="">
                                                                    </figure>
                                                                </div><!-- /.figure -->
                                                                <div class="fig-caption">
                                                                    <figcaption>
                                                                        <div class="item-title">
                                                                            <h4>Shirt on Hanger (P)</h4>
                                                                            <ul>
                                                                                <li>Men Formal Shirts</li>
                                                                            </ul>
                                                                        </div>
                                                                        <span class="svc-price">£2.00</span>
                                                                        <div class="item-select">
                                                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                                                        </div>
                                                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                                                    </figcaption>
                                                                </div>

                                                            </div><!-- /.svc-item-pod -->
                                                        </div>
                                                    </div><!-- /.col-md-6 -->
                                                    <div class="col-md-6">
                                                        <div class="svc-item">
                                                            <div class="svc-item-pod">
                                                                <div class="figure">
                                                                    <figure class="preview-item">
                                                                        <img class="img-view" src="assets/images/svc-items/iron2.png" alt="">
                                                                    </figure>
                                                                </div><!-- /.figure -->
                                                                <div class="fig-caption">
                                                                    <figcaption>
                                                                        <div class="item-title">
                                                                            <h4>T Shirt (P)</h4>
                                                                            <ul>
                                                                                <li>Men Formal Shirts</li>
                                                                            </ul>
                                                                        </div>
                                                                        <span class="svc-price">£2.00</span>
                                                                        <div class="item-select">
                                                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                                                        </div>
                                                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                                                    </figcaption>
                                                                </div>

                                                            </div><!-- /.svc-item-pod -->
                                                        </div>
                                                    </div><!-- /.col-md-6 -->


                                                </div><!-- /.row -->
                                            </div><!-- /.tc-inner -->
                                        </div>

                                        <div class="tab_content" id="tabThree">
                                            <div class="tc-inner">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="svc-item">
                                                            <div class="svc-item-pod">
                                                                <div class="figure">
                                                                    <figure class="preview-item">
                                                                        <img class="img-view" src="assets/images/svc-items/home1.png" alt="">
                                                                    </figure>
                                                                </div><!-- /.figure -->
                                                                <div class="fig-caption">
                                                                    <figcaption>
                                                                        <div class="item-title">
                                                                            <h4>Single Bed Set</h4>
                                                                            <ul>

                                                                                <li>(Wash & Iron) B Sheet,</li>
                                                                                <li> D Cover & P Case</li>
                                                                            </ul>
                                                                        </div>
                                                                        <span class="svc-price">£2.00</span>
                                                                        <div class="item-select">
                                                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                                                        </div>
                                                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                                                    </figcaption>
                                                                </div>

                                                            </div><!-- /.svc-item-pod -->
                                                        </div>
                                                    </div><!-- /.col-md-6 -->
                                                    <div class="col-md-6">
                                                        <div class="svc-item">
                                                            <div class="svc-item-pod">
                                                                <div class="figure">
                                                                    <figure class="preview-item">
                                                                        <img class="img-view" src="assets/images/svc-items/home2.png" alt="">
                                                                    </figure>
                                                                </div><!-- /.figure -->
                                                                <div class="fig-caption">
                                                                    <figcaption>
                                                                        <div class="item-title">
                                                                            <h4>Double Bed Set</h4>
                                                                            <ul>

                                                                                <li>(Wash & Iron) B Sheet,</li>
                                                                                <li>D Cover & 2 P Case</li>
                                                                            </ul>
                                                                        </div>
                                                                        <span class="svc-price">£2.00</span>
                                                                        <div class="item-select">
                                                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                                                        </div>
                                                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                                                    </figcaption>
                                                                </div>

                                                            </div><!-- /.svc-item-pod -->
                                                        </div>
                                                    </div><!-- /.col-md-6 -->


                                                </div>
                                            </div><!-- /.tc-inner -->

                                        </div>

                                        <div class="tab_content" id="tabFour">
                                            <div class="tc-inner">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="svc-item">
                                                            <div class="svc-item-pod">
                                                                <div class="figure">
                                                                    <figure class="preview-item">
                                                                        <img class="img-view" src="assets/images/svc-items/shirt-top1.png" alt="">
                                                                    </figure>
                                                                </div><!-- /.figure -->
                                                                <div class="fig-caption">
                                                                    <figcaption>
                                                                        <div class="item-title">
                                                                            <h4>5 Shirts On Hanger</h4>
                                                                            <ul>
                                                                                <li>Wash & Iron (Hung) Excluding Ladies Shirts/Blouses</li>

                                                                            </ul>
                                                                        </div>
                                                                        <span class="svc-price">£2.00</span>
                                                                        <div class="item-select">
                                                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                                                        </div>
                                                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                                                    </figcaption>
                                                                </div>

                                                            </div><!-- /.svc-item-pod -->
                                                        </div>
                                                    </div><!-- /.col-md-6 -->
                                                    <div class="col-md-6">
                                                        <div class="svc-item">
                                                            <div class="svc-item-pod">
                                                                <div class="figure">
                                                                    <figure class="preview-item">
                                                                        <img class="img-view" src="assets/images/svc-items/shirt-top2.png" alt="">
                                                                    </figure>
                                                                </div><!-- /.figure -->
                                                                <div class="fig-caption">
                                                                    <figcaption>
                                                                        <div class="item-title">
                                                                            <h4>10 Shirts @ 2.30</h4>
                                                                            <ul>
                                                                                <li>Wash & Iron (Hung) Excluding Ladies Shirts/Blouses</li>
                                                                            </ul>
                                                                        </div>
                                                                        <span class="svc-price">£2.00</span>
                                                                        <div class="item-select">
                                                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                                                        </div>
                                                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                                                    </figcaption>
                                                                </div>

                                                            </div><!-- /.svc-item-pod -->
                                                        </div>
                                                    </div><!-- /.col-md-6 -->


                                                </div>
                                            </div><!-- /.tc-inner -->
                                        </div>

                                        <div class="tab_content" id="tabFive">
                                            <div class="tc-inner">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="svc-item">
                                                            <div class="svc-item-pod">
                                                                <div class="figure">
                                                                    <figure class="preview-item">
                                                                        <img class="img-view" src="assets/images/svc-items/suit1.png" alt="">
                                                                    </figure>
                                                                </div><!-- /.figure -->
                                                                <div class="fig-caption">
                                                                    <figcaption>
                                                                        <div class="item-title">
                                                                            <h4>Cardigan (P)</h4>
                                                                            <ul>
                                                                                <li>(Dry Clean) 2 Piece Suit + 5 Shirts (Hung)</li>
                                                                            </ul>
                                                                        </div>
                                                                        <span class="svc-price">£2.00</span>
                                                                        <div class="item-select">
                                                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                                                        </div>
                                                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                                                    </figcaption>
                                                                </div>

                                                            </div><!-- /.svc-item-pod -->
                                                        </div>
                                                    </div><!-- /.col-md-6 -->
                                                    <div class="col-md-6">
                                                        <div class="svc-item">
                                                            <div class="svc-item-pod">
                                                                <div class="figure">
                                                                    <figure class="preview-item">
                                                                        <img class="img-view" src="assets/images/svc-items/suit2.png" alt="">
                                                                    </figure>
                                                                </div><!-- /.figure -->
                                                                <div class="fig-caption">
                                                                    <figcaption>
                                                                        <div class="item-title">
                                                                            <h4>2 Dresses</h4>
                                                                            <ul>
                                                                                <li>(Dry Clean) Exl velvet, seq, silk & leather</li>
                                                                            </ul>
                                                                        </div>
                                                                        <span class="svc-price">£2.00</span>
                                                                        <div class="item-select">
                                                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                                                        </div>
                                                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                                                    </figcaption>
                                                                </div>

                                                            </div><!-- /.svc-item-pod -->
                                                        </div>
                                                    </div><!-- /.col-md-6 -->

                                                </div>
                                            </div><!-- /.tc-inner -->
                                        </div>

                                        <div class="tab_content" id="tabSix">
                                            <div class="tc-inner">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="svc-item">
                                                            <div class="svc-item-pod">
                                                                <div class="figure">
                                                                    <figure class="preview-item">
                                                                        <img class="img-view" src="assets/images/svc-items/dress1.png" alt="">
                                                                    </figure>
                                                                </div><!-- /.figure -->
                                                                <div class="fig-caption">
                                                                    <figcaption>
                                                                        <div class="item-title">
                                                                            <h4>2 Dresses</h4>
                                                                            <ul>
                                                                                <li>(Dry Clean) Exl velvet, seq, silk & leather</li>
                                                                            </ul>
                                                                        </div>
                                                                        <span class="svc-price">£2.00</span>
                                                                        <div class="item-select">
                                                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                                                        </div>
                                                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                                                    </figcaption>
                                                                </div>

                                                            </div><!-- /.svc-item-pod -->
                                                        </div>
                                                    </div><!-- /.col-md-6 -->
                                                    <div class="col-md-6">
                                                        <div class="svc-item">
                                                            <div class="svc-item-pod">
                                                                <div class="figure">
                                                                    <figure class="preview-item">
                                                                        <img class="img-view" src="assets/images/svc-items/dress2.png" alt="">
                                                                    </figure>
                                                                </div><!-- /.figure -->
                                                                <div class="fig-caption">
                                                                    <figcaption>
                                                                        <div class="item-title">
                                                                            <h4>Dress</h4>
                                                                            <ul>
                                                                                <li>(Dry Clean) Exl velvet, seq, silk & leather</li>
                                                                            </ul>
                                                                        </div>
                                                                        <span class="svc-price">£2.00</span>
                                                                        <div class="item-select">
                                                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                                                        </div>
                                                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                                                    </figcaption>
                                                                </div>

                                                            </div><!-- /.svc-item-pod -->
                                                        </div>
                                                    </div><!-- /.col-md-6 -->


                                                </div>
                                            </div><!-- /.tc-inner -->
                                        </div>
                                        <div class="tab_content" id="tabSeven">
                                            <div class="tc-inner">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="svc-item">
                                                            <div class="svc-item-pod">
                                                                <div class="figure">
                                                                    <figure class="preview-item">
                                                                        <img class="img-view" src="assets/images/svc-items/trouser1.png" alt="">
                                                                    </figure>
                                                                </div><!-- /.figure -->
                                                                <div class="fig-caption">
                                                                    <figcaption>
                                                                        <div class="item-title">
                                                                            <h4>3 Trouser</h4>
                                                                            <ul>
                                                                                <li>(Dry Clean)</li>
                                                                            </ul>
                                                                        </div>
                                                                        <span class="svc-price">£2.00</span>
                                                                        <div class="item-select">
                                                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                                                        </div>
                                                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                                                    </figcaption>
                                                                </div>

                                                            </div><!-- /.svc-item-pod -->
                                                        </div>
                                                    </div><!-- /.col-md-6 -->
                                                    <div class="col-md-6">
                                                        <div class="svc-item">
                                                            <div class="svc-item-pod">
                                                                <div class="figure">
                                                                    <figure class="preview-item">
                                                                        <img class="img-view" src="assets/images/svc-items/trouser2.png" alt="">
                                                                    </figure>
                                                                </div><!-- /.figure -->
                                                                <div class="fig-caption">
                                                                    <figcaption>
                                                                        <div class="item-title">
                                                                            <h4>Trousers</h4>
                                                                            <ul>
                                                                                <li>(Dry Clean)</li>
                                                                            </ul>
                                                                        </div>
                                                                        <span class="svc-price">£2.00</span>
                                                                        <div class="item-select">
                                                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                                                        </div>
                                                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                                                    </figcaption>
                                                                </div>

                                                            </div><!-- /.svc-item-pod -->
                                                        </div>
                                                    </div><!-- /.col-md-6 -->


                                                </div>
                                            </div><!-- /.tc-inner -->
                                        </div>
                                        <div class="tab_content" id="tabEight">
                                            <div class="tc-inner">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="svc-item">
                                                            <div class="svc-item-pod">
                                                                <div class="figure">
                                                                    <figure class="preview-item">
                                                                        <img class="img-view" src="assets/images/svc-items/outdoor1.png" alt="">
                                                                    </figure>
                                                                </div><!-- /.figure -->
                                                                <div class="fig-caption">
                                                                    <figcaption>
                                                                        <div class="item-title">
                                                                            <h4>Fleece</h4>
                                                                            <ul>
                                                                                <li>(Dry Clean)</li>
                                                                            </ul>
                                                                        </div>
                                                                        <span class="svc-price">£2.00</span>
                                                                        <div class="item-select">
                                                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                                                        </div>
                                                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                                                    </figcaption>
                                                                </div>

                                                            </div><!-- /.svc-item-pod -->
                                                        </div>
                                                    </div><!-- /.col-md-6 -->
                                                    <div class="col-md-6">
                                                        <div class="svc-item">
                                                            <div class="svc-item-pod">
                                                                <div class="figure">
                                                                    <figure class="preview-item">
                                                                        <img class="img-view" src="assets/images/svc-items/outdoor2.png" alt="">
                                                                    </figure>
                                                                </div><!-- /.figure -->
                                                                <div class="fig-caption">
                                                                    <figcaption>
                                                                        <div class="item-title">
                                                                            <h4>Blazer</h4>
                                                                            <ul>
                                                                                <li>(Dry Clean)</li>
                                                                            </ul>
                                                                        </div>
                                                                        <span class="svc-price">£2.00</span>
                                                                        <div class="item-select">
                                                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                                                        </div>
                                                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                                                    </figcaption>
                                                                </div>

                                                            </div><!-- /.svc-item-pod -->
                                                        </div>
                                                    </div><!-- /.col-md-6 -->


                                                </div>
                                            </div><!-- /.tc-inner -->
                                        </div>
                                        <div class="tab_content" id="tabNine">
                                            <div class="tc-inner">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="svc-item">
                                                            <div class="svc-item-pod">
                                                                <div class="figure">
                                                                    <figure class="preview-item">
                                                                        <img class="img-view" src="assets/images/svc-items/outdoor1.png" alt="">
                                                                    </figure>
                                                                </div><!-- /.figure -->
                                                                <div class="fig-caption">
                                                                    <figcaption>
                                                                        <div class="item-title">
                                                                            <h4>Fleece</h4>
                                                                            <ul>
                                                                                <li>(Dry Clean)</li>
                                                                            </ul>
                                                                        </div>
                                                                        <span class="svc-price">£2.00</span>
                                                                        <div class="item-select">
                                                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                                                        </div>
                                                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                                                    </figcaption>
                                                                </div>

                                                            </div><!-- /.svc-item-pod -->
                                                        </div>
                                                    </div><!-- /.col-md-6 -->
                                                    <div class="col-md-6">
                                                        <div class="svc-item">
                                                            <div class="svc-item-pod">
                                                                <div class="figure">
                                                                    <figure class="preview-item">
                                                                        <img class="img-view" src="assets/images/svc-items/outdoor2.png" alt="">
                                                                    </figure>
                                                                </div><!-- /.figure -->
                                                                <div class="fig-caption">
                                                                    <figcaption>
                                                                        <div class="item-title">
                                                                            <h4>Blazer</h4>
                                                                            <ul>
                                                                                <li>(Dry Clean)</li>
                                                                            </ul>
                                                                        </div>
                                                                        <span class="svc-price">£2.00</span>
                                                                        <div class="item-select">
                                                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                                                        </div>
                                                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                                                    </figcaption>
                                                                </div>

                                                            </div><!-- /.svc-item-pod -->
                                                        </div>
                                                    </div><!-- /.col-md-6 -->


                                                </div>
                                            </div><!-- /.tc-inner -->
                                        </div>

                                    </div><!--/.tab_content-wrap-->
                                </div><!-- /.wizard-field-inner -->


                            </fieldset>

                            <fieldset class="wizard-fieldset field-3">
                                <div class="wizard-field-inner field-step-inner">
                                    <div class="step-title">
                                        <h4>Addons</h4>
                                    </div><!-- /.step-title -->
                                    <div class="step-fields-pod">

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="" for="inlineFormSelectPref">Wash Mode <span>*</span></label>
                                                    <select class="form-select form-control">
                                                        <option selected>Hot Wash 30-90 C</option>
                                                        <option value="1">Color Wash 30-60 C</option>
                                                        <option value="2">Synthetic 30-40 C</option>
                                                        <option value="3">Nylon 30 C</option>
                                                        <option value="4">Delicates 20 C</option>
                                                    </select>

                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="" for="inlineFormSelectPref"> Detergent <span>*</span></label>
                                                    <select class="form-select form-control">
                                                        <option selected>Lynx BioT-3 Professional Laundry...</option>
                                                        <option value="1">Lynx BioT-3 Professional laundry detergent</option>
                                                        <option value="2">Default</option>
                                                        <option value="3">Lynx Colour Protection Bleach £0.30(£0.30)</option>
                                                        <option value="4">Persil Powder Bio(+£0.80 / 8Kg)(£0.80)</option>
                                                        <option value="5">Ariel ACTILIFT Powder Bio(+£0.80 / 8Kgs)(£0.80)</option>
                                                        <option value="6">Vanish Oxi Gold £0.20(£1.00)</option>
                                                        <option value="7">Eco Flower(£1.00)</option>
                                                    </select>

                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="" for="inlineFormSelectPref"> Fabric Softner <span>*</span></label>
                                                    <select class="form-select form-control">
                                                        <option selected>Lynx Big Blue Professional</option>
                                                        <option value="1">None</option>
                                                        <option value="2">Lenor Midnight shadows(+£0.50 / 8Kg)(£0.50)</option>
                                                        <option value="3">ECOVER flower(+£0.80 / 8Kg)(£0.80)</option>
                                                    </select>

                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="" for="inlineFormSelectPref"> White <span>*</span></label>
                                                    <select class="form-select form-control">
                                                        <option selected>30 degrees</option>
                                                        <option value="1">40 degrees</option>
                                                        <option value="2">60 degrees</option>
                                                        <option value="3">90 degrees</option>
                                                    </select>

                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="" for="inlineFormSelectPref"> Color & Dirt Collector <span>*</span></label>
                                                    <select class="form-select form-control">
                                                        <option selected>none</option>
                                                        <option value="1">(Dr. Beckmann) £0.15p each(£0.15)</option>

                                                    </select>

                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="" for="inlineFormSelectPref"> Number of Loads <span>*</span></label>
                                                    <select class="form-select form-control">
                                                        <option selected>Standard (1 load)</option>
                                                        <option value="1">Lights & Darks (2 loads/bags)(+£9.99/order)(£9.99)</option>

                                                    </select>

                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="" for="inlineFormSelectPref"> Tumble Dryer <span>*</span></label>
                                                    <select class="form-select form-control">
                                                        <option selected>HOT</option>
                                                        <option value="1">MEDIUM</option>
                                                        <option value="2">LIGHT(£3.00)</option>
                                                    </select>

                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="" for="inlineFormSelectPref"> Finishing <span>*</span></label>
                                                    <select class="form-select form-control">
                                                        <option selected>Wash, Dry & Fold</option>

                                                    </select>

                                                </div>
                                            </div>


                                        </div>


                                    </div><!-- /.step-fields-pod -->
                                </div><!-- /.wizard-field-inner -->


                            </fieldset>

                            <fieldset class="wizard-fieldset field-4">

                                <div class="wizard-field-inner field-step-inner">
                                    <div class="step-title">
                                        <h4>Collection time</h4>
                                    </div><!-- /.step-title -->
                                    <div class="step-fields-pod">

                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="field-pod-image">
                                                    <img src="assets/images/collection-time.svg" alt="">
                                                </div><!-- /.pod-image -->
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label class="" for="inlineFormSelectPref">DATE</label>
                                                    <input type="date" class="form-control">

                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label class="" for="inlineFormSelectPref"> Time</label>
                                                    <input type="time" class="form-control">

                                                </div>
                                            </div>


                                        </div>


                                    </div><!-- /.step-fields-pod -->
                                </div><!-- /.wizard-field-inner -->

                                <div class="wizard-field-inner field-step-inner wizard-field-inner-next">
                                    <div class="step-title">
                                        <h4>Delivery time</h4>
                                    </div><!-- /.step-title -->
                                    <div class="step-fields-pod">

                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="field-pod-image">
                                                    <img src="assets/images/delivery.svg" alt="">
                                                </div><!-- /.pod-image -->
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label class="" for="inlineFormSelectPref">DATE</label>
                                                    <input type="date" class="form-control">

                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label class="" for="inlineFormSelectPref"> Time</label>
                                                    <input type="time" class="form-control">

                                                </div>
                                            </div>


                                        </div>


                                    </div><!-- /.step-fields-pod -->
                                </div><!-- /.wizard-field-inner -->


                                <div class="wizard-field-inner field-step-inner wizard-field-inner-next">
                                    <div class="step-title">
                                        <h4>Order instructions (optional)</h4>
                                    </div><!-- /.step-title -->
                                    <div class="step-fields-pod">

                                        <textarea class="form-control" rows="3" placeholder="Add any special instructions for the driver / cleaning team"></textarea>


                                    </div><!-- /.step-fields-pod -->
                                </div><!-- /.wizard-field-inner -->

                            </fieldset>

                            <fieldset class="wizard-fieldset field-5">

                                <div class="wizard-field-inner field-step-inner wizard-field-inner-next">
                                    <div class="step-title">
                                        <h4>Payments Options</h4>
                                    </div><!-- /.step-title -->
                                    <div class="step-fields-pod">

                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="wizard-form-text-label">Name on Card</label>
                                                    <input type="text" class="form-control" placeholder="Name on Card">

                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="wizard-form-text-label">Card Number</label>
                                                    <input type="text" class="form-control" placeholder="0000 0000 0000 0000">

                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="wizard-form-text-label">Expiry Date</label>
                                                    <input type="text" class="form-control" placeholder="MM / YY">

                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="wizard-form-text-label">CVC</label>
                                                    <input type="text" class="form-control" placeholder="CVC">

                                                </div>
                                            </div>


                                        </div>


                                    </div><!-- /.step-fields-pod -->
                                </div><!-- /.wizard-field-inner -->
                            </fieldset>

                            <fieldset class="wizard-fieldset field-6">

                                <div class="wizard-field-inner field-step-inner wizard-field-inner-next">
                                    <div class="step-title">
                                        <h4>Payments Options</h4>
                                    </div><!-- /.step-title -->
                                    <div class="step-fields-pod">

                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="wizard-form-text-label">Name on Card</label>
                                                    <input type="text" class="form-control" placeholder="Name on Card">

                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="wizard-form-text-label">Card Number</label>
                                                    <input type="text" class="form-control" placeholder="0000 0000 0000 0000">

                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="wizard-form-text-label">Expiry Date</label>
                                                    <input type="text" class="form-control" placeholder="MM / YY">

                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="wizard-form-text-label">CVC</label>
                                                    <input type="text" class="form-control" placeholder="CVC">

                                                </div>
                                            </div>


                                        </div>


                                    </div><!-- /.step-fields-pod -->
                                </div><!-- /.wizard-field-inner -->
                            </fieldset>
                        </form>

                    </div>


                </div>
                <div class="order-col order-col-right" id="order-details">
                    <div class="order-details-inner">
                        <div class="step-title">
                            <h4>Order Summary</h4>
                        </div><!-- /.step-title -->

                        <div class="items-ordered-list">
                            <ul>
                                <li class="step-details" data-step="1">
                                    <i class="icon-edit edit-selected-items"></i>
                                    <div class="custom-checkbox">
                                        <input type="checkbox" value="Address" checked>
                                        <label>Address</label>
                                    </div><!-- /.custom-chekbox -->
                                    <ul class="address-lines order-info">
                                        <li>4B Samson Street, London</li>
                                        <li></li>
                                    </ul>
                                </li>
                                <li class="step-details" data-step="2">
                                    <i class="icon-edit edit-selected-items"></i>
                                    <div class="custom-checkbox">
                                        <input type="checkbox" value="Item Selection" checked>
                                        <label>Item Selection</label>
                                        <ul class="order-info">
                                            <li>
                                            <span class="selected-item item-name">
                                                6 Kg Wash dry & fold
                                            </span>
                                                <span class="selected-item item-quantity">
                                                1
                                            </span>
                                                <span class="selected-item item-price">
                                                £16.00
                                            </span>
                                            </li>
                                            <li>
                                            <span class="selected-item item-name">
                                                T Shirt (P)
                                            </span>
                                                <span class="selected-item item-quantity">
                                                4
                                            </span>
                                                <span class="selected-item item-price">
                                                £8.00
                                            </span>
                                            </li>
                                            <li>
                                            <span class="selected-item item-name">
                                                Shirt/TShirt Fold (P)
                                            </span>
                                                <span class="selected-item item-quantity">
                                                2
                                            </span>
                                                <span class="selected-item item-price">
                                                £2.50
                                            </span>
                                            </li>
                                            <li>
                                            <span class="selected-item item-name">
                                                Shirt/TShirt Fold (P)
                                            </span>
                                                <span class="selected-item item-quantity">
                                                4
                                            </span>
                                                <span class="selected-item item-price">
                                                £8.00
                                            </span>
                                            </li>
                                            <li>
                                            <span class="selected-item item-name">
                                                Jacket (P)
                                            </span>
                                                <span class="selected-item item-quantity">
                                                2
                                            </span>
                                                <span class="selected-item item-price">
                                                £16.00
                                            </span>
                                            </li>
                                            <li>
                                            <span class="selected-item item-name">
                                                6 Kg Wash dry & fold
                                            </span>
                                                <span class="selected-item item-quantity">
                                                1
                                            </span>
                                                <span class="selected-item item-price">
                                                £16.00
                                            </span>
                                            </li>
                                            <li>
                                            <span class="selected-item item-name">
                                                Evening Dress (P)
                                            </span>
                                                <span class="selected-item item-quantity">
                                                4
                                            </span>
                                                <span class="selected-item item-price">
                                                £8.00
                                            </span>
                                            </li>
                                            <li>
                                            <span class="selected-item item-name">
                                                Dress (P)
                                            </span>
                                                <span class="selected-item item-quantity">
                                                1
                                            </span>
                                                <span class="selected-item item-price">
                                                £2.50
                                            </span>
                                            </li>
                                            <li>
                                            <span class="selected-item item-name">
                                                Skirt (P)
                                            </span>
                                                <span class="selected-item item-quantity">
                                                3
                                            </span>
                                                <span class="selected-item item-price">
                                                £8.00
                                            </span>
                                            </li>
                                        </ul>
                                    </div><!-- /.custom-chekbox -->
                                </li>
                                <li class="step-details" data-step="3">
                                    <i class="icon-edit edit-selected-items"></i>
                                    <div class="custom-checkbox">
                                        <input type="checkbox" value="Collection & Delivery" checked>
                                        <label>Collection & Delivery</label>
                                        <ul class="services-list">
                                            <li class="item-services"><span>Collection: <b>Fri, 24 Jun 11:00-13:00</b></span></li>
                                            <li class="item-services"><span>Delivery: <b>Mon, 27 Jun 15:00-17:00</b></span></li>
                                        </ul>
                                    </div><!-- /.custom-chekbox -->
                                </li>

                                <li class="step-details" data-step="4">
                                    <i class="icon-edit edit-selected-items"></i>
                                    <div class="custom-checkbox">
                                        <input type="checkbox" value="Contact Details" checked>
                                        <label>Contact Details</label>
                                        <ul class="user-info services-list">
                                            <li class="user-data item-services"><span>Name: <b>John Doe</b></span></li>
                                            <li class="user-data item-services"><span>Email: <b>johndoe@gmail.com</b></span></li>
                                            <li class="user-data item-services"><span>Phone: <b>+4433692558</b></span></li>
                                        </ul>
                                    </div><!-- /.custom-chekbox -->
                                </li>
                            </ul>
                            <ul class="user-order-guide-list">

                                <li>Minimum order value of £15</li>
                                <li>No minimum order value for student accounts linked to a halls of residence</li>
                                <li>£3.50 small order fee if minimum order value is not met</li>
                                <li>£4.50 cancellation fee</li>
                            </ul>
                            <ul class="order-values-list">
                                <li class="value-item value-item-2"><span>Services Total </span> <b>£140.73</b></li>
                                <li class="value-item value-item-3"><span>Grand Total </span> <b>£20.00</b></li>
                            </ul>

                            <div class="discount-pod">
                                <input type="text" placeholder="Discount or referral code" class="form-control promo-code">
                                <button type="button" class="theme-btn btn-black-theme apply-btn">Apply</button>
                            </div>
                        </div><!-- /.items-orderd-list -->
                    </div><!-- /.order-details-inner -->

                    <div class="form-group clearfix od-btn-next-only">

                        <a href="javascript:;" class="form-wizard-next-btn theme-btn btn-black-theme od-next-btn">
                            <span>Next</span>
                        </a>
                        <p class="acceptance-tc">By continuing you agree to our Terms & Conditions and Privacy Policy.</p>
                    </div>


                </div>
            </div><!-- /.order-section-inner -->
        </div><!-- /.order-container -->
    </div><!-- /.order-section -->
</main><!--/.page__wrap-->

<div class="no-footer">
    <?php include 'incl/footer.php'; ?>
</div><!-- /.no-footer -->