<?php include 'incl/header.php'; ?>

    <main class="page__wrap">
    <div class="page-banner slikk-banner">
        <div class="page-banner-inner">
              <div class="banner-col col-left container-half slikk-col-left">
              <div class="banner-title">
                <h1>Reinventing the future of Laundry & Dry Cleaning</h1>
                <p>We want to make laundry and dry cleaning simple, but also less harmful to the environment. A convenient service for students, professionals and businesses that doesn’t cost the earth (literally).</p>
                
            </div><!-- /.banner-title -->
              </div>

            <div class="banner-col col-right">
                <figure class="preview-item">
                  <img class="img-view" src="assets/images/slikk-banner.png" alt="">
                </figure>
          </div>

        </div><!-- /.page-banner-inner -->
    </div><!-- /.page-banner -->


    <div class="team-section">
        <div class="container">
          <div class="team-section-inner">
              <div class="section-title center-text">
                  <h4>We are building a business that thinks about <br> the future of our planet</h4>
              </div><!-- /.section-title -->

            <div class="team-image">
                <figure>
                <img src="assets/images/commercial-hero-image.png" alt="">
                </figure>
            </div><!-- /.team-image -->
            <div class="team-description center-text">
                <b>Founded by a London University Student in 2021, Slikk aims to be the next level to eco-friendly and sustainable services for all.</b>
                <p class="team-details">
                Everyone needs clean clothes and bed sheets – no one likes to be smelly or dirty! With our Laundry, Dry Cleaning & Sneaker Care packages we are committed to reducing the burden on your pockets, but also the negatives impacts on the environment.
                </p>
                <p>
                The Slikk cleaning process uses less water, electricity and eradicates the use of unnecessary emissions. All our services are delivered in an eco-friendly manner. During the cleaning process we use only cruelty- free and non-harmful products to make sure that your items get back to you fresh and clean without harming the earth. Who wants to wear chemical covered clothes or sleep in toxic bed sheets? No one.
                </p>
                <p>
                We are determined to be the first truly sustainable laundry service that works around you and your needs. That means neither harming your cotton socks, nor our wonderful planet.”
                </p>
            </div><!-- /.team-description -->

          </div><!-- /.team-section-inner -->
        </div><!-- /.container-sm -->
    </div><!-- /.team-section -->

    <div class="price-banner-section">
            <div class="price-banner-inner">
            <div class="row">
                <div class="col-md-6">
                    <div class="price-col col-left">
                    <img src="assets/images/best-price-banner.svg" alt="">
                    </div>
                </div>
                <div class="col-md-6">
                <div class="price-col col-right">
                        <div class="section-title">
                            <h4><small>Refer a friend</small>Get £5 off <span>Your next wash</span></h4>
                            <a href="#" class="theme-btn btn-green-theme section-icon-btn">Send Referral link <i class="icon-referral-link"></i> </a>
                        </div><!-- /.section-title -->
                     <img src="assets/images/grey-star.svg" alt="">
                </div>
                </div>
            </div>
            </div><!-- /.price-banner-inner -->
    </div><!-- /.price-banner-section -->

    

    <div class="brand-features-section bg-theme-lightblue">
        <div class="container">
            <div class="brand-features-inner">
              <div class="section-title center-text">
                  <h4>Why use Slikk?</h4>
              </div><!-- /.section-title -->

                <div class="feature-cols">
                <div class="row">
                  <div class="col-md-3">
                  <div class="feature-col center-text">

                              <figure>
                                <img src="assets/images/icons/abt-ico1.svg" alt="">
                              </figure>
                              <figcaption>
                                <b>Robust Tech</b>
                                <p>We use regularly maintained machines and top tech for your belongings</p>
                              </figcaption>

                    </div><!-- /.feature-col -->
                  </div>

                  <div class="col-md-3">
                  <div class="feature-col center-text">

                              <figure>
                                <img src="assets/images/icons/abt-ico2.svg" alt="">
                              </figure>
                              <figcaption>
                                <b>Eco Friendly Products</b>
                                <p>High quality products don’t need to be harmful to you or the environment. We use only the best</p>
                              </figcaption>
                              
                    </div><!-- /.feature-col -->
                  </div>

                  <div class="col-md-3">
                  <div class="feature-col center-text">

                              <figure>
                                <img src="assets/images/icons/abt-ico3.svg" alt="">
                              </figure>
                              <figcaption>
                                <b>Round the clock service</b>
                                <p>Expect an efficient and helpful service all round: from placing your order to getting in touch with the Slikk team</p>
                              </figcaption>
                              
                    </div><!-- /.feature-col -->
                  </div>

                  <div class="col-md-3">
                  <div class="feature-col center-text">

                              <figure>
                                <img src="assets/images/icons/abt-ico4.svg" alt="">
                              </figure>
                              <figcaption>
                                <b>Free pick-up and delivery</b>
                                <p>Conveniently choose time slots that suit you – from wherever you are</p>
                              </figcaption>
                              
                    </div><!-- /.feature-col -->
                  </div>
                </div>
                </div><!-- /.feature-cols -->
              
            </div><!-- /.brand-features-inner -->
        </div><!-- /.container -->
    </div><!-- /.brand-features-seciton -->



    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>