<?php include 'incl/header.php'; ?>

    <main class="page__wrap">
       <div class="account-wrapper">
          <div class="account-inner">
            <div class="account-title">
                  <h1>Create an account</h1>
            </div><!-- /.account-title -->
             <div class="account-form">
              <form action="">
                  <div class="form-pods-two">
                  <div class="mb-3 pod-half">
                    <input type="text" class="form-pod" id="name1" placeholder="First Name*">
                  </div>
                  <div class="mb-3 pod-half">
                    <input type="text" class="form-pod" id="name2" placeholder="Last Name*">
                  </div>
                  </div><!-- /.form-pods-two -->

                  <div class="form-pods-two">
                  <div class="mb-3 pod-half">
                    <input type="email" class="form-pod" id="email" placeholder="Email*">
                  </div>
                  <div class="mb-3 pod-half">
                    <input type="text" class="form-pod" id="phone" placeholder="Phone*">
                  </div>
                  </div><!-- /.form-pods-two -->

                  <div class="mb-3 one-full">
                    <input type="password" class="form-pod" id="password" placeholder="Password*">
                  </div>

                  <div class="mb-3 form-check student-check">
                  <input class="form-check-input" type="checkbox" value="" id="studentCheck">
                  <label class="form-check-label" for="studentCheck">
                    I am a Student
                  </label>
                </div>
                <div class="student-regn" id="student-registeration">
                  
                <div class="mb-3 one-full">
                    <input type="text" class="form-pod" id="accomo-type" placeholder="Accommodation Type*">
                  </div>

                  <div class="form-pods-two">
                  <div class="mb-3 pod-half-lg">
                    <input type="text" class="form-pod" id="address" placeholder="Address">
                  </div>
                  <div class="mb-3 pod-half-sm">
                    <input type="text" class="form-pod" id="postcode" placeholder="Postcode">
                  </div>
                  </div><!-- /.form-pods-two -->

                  <div class="form-pods-two">
                  <div class="mb-3 pod-half-lg">
                    <input type="text" class="form-pod" id="university" placeholder="University">
                  </div>
                  <div class="mb-3 pod-half-sm">
                    <input type="text" class="form-pod" id="hall" placeholder="Hall">
                  </div>
                  </div><!-- /.form-pods-two -->
                </div>
                  <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="terms">
                  <label class="form-check-label" for="terms">
                    I agree to Slikk <a href="#">Terms & Conditions</a>
                  </label>
                  </div>


                  <div class="acct-btn">
                    <button type="submit" id="registerbtn" class="theme-btn btn-black-theme btn-account">Register</button>
                  </div><!-- /.acct-btn -->
              </form>
             </div>
          </div><!-- /.account-inner -->
       </div><!-- /.account-wrapper -->

    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>