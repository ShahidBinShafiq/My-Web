<?php include 'incl/header.php'; ?>

    <main class="page__wrap">
    <div class="page-banner commercial-banner" style="background-image:url('assets/images/commercial-hero-image.png')">
    <div class="container-md">
        <div class="page-banner-inner">
        <div class="banner-title">
                <h1>Get Slikk for your business</h1>
                <p>If our services can be of use to your business we'd love to hear from you</p>
                <p>From Apartments to Gyms - whatever your business - we want to hear from you!" "Boost your CRS by working alongside a socially conscious business like Slikk."</p>
            </div><!-- /.banner-title -->

        </div><!-- /.page-banner-inner -->
    </div><!-- /.container -->
    </div><!-- /.page-banner -->




    <div class="enquiry-section  bg-theme-lightblue">
        <div class="container-sm">
            <div class="enquiry-section-inner">
                <div class="section-title center-text">
                        <h4>Lets work together! <br> Get in touch below</h4>
                </div><!-- /.section-title -->


                <div class="form-pod box-shadow">
                    <form action="">
                      <div class="from-cols">
                          <div class="from-col">
                                <div class="mb-3">
                                  <input type="text" class="form-content"  placeholder="Your Name">
                                </div>
                            </div>

                            <div class="from-col">
                                <div class="mb-3">
                                  <input type="email" class="form-content"  placeholder="Your Email">
                                </div>
                          </div>


                          <div class="from-col">
                                <div class="mb-3">
                                  <input type="text" class="form-content"  placeholder="Contact Number">
                                </div>
                          </div>

                          <div class="from-col">
                                <div class="mb-3">
                                  <input type="text" class="form-content"  placeholder="Company">
                                </div>
                          </div>

                      

                      </div><!-- /.form-cols -->

                      <div class="service-enquiry-area">
                        <p>Enquiring for</p>
                        <div class="enquiry-pods">

                      <div class="custom_radio">
                            <input type="radio" id="radioOne" name="enquiry" checked>
                            <label for="radioOne">
                            <figure>
                            <img src="assets/images/icons/dry-clng-ico.svg" alt="">
                            </figure>
                            Dry Cleaning & Laundry
                            </label>
                          </div>

                          <div class="custom_radio">
                            <input type="radio" id="radioTwo" name="enquiry">
                            <label for="radioTwo">
                            <figure>
                            <img src="assets/images/icons/shoe-ico.svg" alt="">
                            </figure>
                            Shoe Care
                            </label>
                          </div>


                        </div><!-- /.enquiry-pods -->
                        </div>



                      <div class="mb-3 address-pod">
                                  <textarea class="form-control" rows="5" placeholder="Your enquiry"></textarea>
                                  
                              </div>

                              <div class="message-btn">
                        <button type="submit" class="theme-btn btn-black-theme">Send Message</button>
                        </div>
                    </form>
                </div><!-- /.form-pod -->

               
            </div><!-- /.enquiry-section-inner -->
        </div><!-- /.container-sm -->
    </div><!-- /.enquiry-section -->

    <div class="brand-features-section bg-theme-lightblue">
        <div class="container">
            <div class="brand-features-inner">
              <div class="section-title center-text">
                  <h4>Why use Slikk?</h4>
              </div><!-- /.section-title -->

                <div class="feature-cols">
                <div class="row">
                  <div class="col-md-3">
                  <div class="feature-col center-text">

                              <figure>
                                <img src="assets/images/icons/abt-ico1.svg" alt="">
                              </figure>
                              <figcaption>
                                <b>Robust Tech</b>
                                <p>We use regularly maintained machines and top tech for your belongings</p>
                              </figcaption>

                    </div><!-- /.feature-col -->
                  </div>

                  <div class="col-md-3">
                  <div class="feature-col center-text">

                              <figure>
                                <img src="assets/images/icons/abt-ico2.svg" alt="">
                              </figure>
                              <figcaption>
                                <b>Eco Friendly Products</b>
                                <p>High quality products don’t need to be harmful to you or the environment. We use only the best</p>
                              </figcaption>
                              
                    </div><!-- /.feature-col -->
                  </div>

                  <div class="col-md-3">
                  <div class="feature-col center-text">

                              <figure>
                                <img src="assets/images/icons/abt-ico3.svg" alt="">
                              </figure>
                              <figcaption>
                                <b>Round the clock service</b>
                                <p>Expect an efficient and helpful service all round: from placing your order to get in touch with the Slikk team</p>
                              </figcaption>
                              
                    </div><!-- /.feature-col -->
                  </div>

                  <div class="col-md-3">
                  <div class="feature-col center-text">

                              <figure>
                                <img src="assets/images/icons/abt-ico4.svg" alt="">
                              </figure>
                              <figcaption>
                                <b>Free pick-up and delivery</b>
                                <p>Conveniently choose time slots that suit you – from wherever you are</p>
                              </figcaption>
                              
                    </div><!-- /.feature-col -->
                  </div>
                </div>
                </div><!-- /.feature-cols -->
              
            </div><!-- /.brand-features-inner -->
        </div><!-- /.container -->
    </div><!-- /.brand-features-seciton -->





    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>