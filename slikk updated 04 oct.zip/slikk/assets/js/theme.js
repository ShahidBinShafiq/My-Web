/**
 * @var $ jQuery
 */

// Full Height...
function fsHeight() {
    let winHeight = $(window).height();
    $('[data-height="viewport"]').css("height", winHeight, "!important");
    $('[data-min-height="viewport"]').css("minHeight", winHeight, "!important");
}

/* Window Load ---------------------- */

$(window).on("load", function () {

    setTimeout(function () {
        $("body").addClass("loaded");
    }, 400);


    $('.hm_cookie-modal').modal('show');


    // setTimeout(function () {
    //     AOS.init({
    //         once: true,
    //         duration: 1000
    //     });
    // }, 800);


});

/* Document Ready ---------------------- */

$(document).ready(function () {
    fsHeight();

    // Inline background image...
    $("[data-bg]").each(function () {
        const image = $(this).attr("data-bg");
        $(this).css({
            backgroundImage: 'url("' + image + '")',
        });
    });

    // student section form validation...

    //  $('#studentCheck').click(function() {
    //     if ($(this).is(':checked')) {
    //       $("#student-registeration").css({
    //         opacity: "1",
    //         pointerEvents: "auto",

    //     })

    //     } else {
    //       $("#student-registeration").css({
    //         opacity: ".4",
    //         pointerEvents: "none",

    //     })
    //     }
    //   });

    // register user form validation...

    //  $('#terms').click(function() {
    //     if ($(this).is(':checked')) {
    //       $('#registerbtn').removeAttr('disabled');
    //       $("#registerbtn").css({
    //         opacity: "1",

    //     })

    //     } else {
    //       $('#registerbtn').attr('disabled', 'disabled');
    //       $("#registerbtn").css({
    //         opacity: ".4",

    //     })
    //     }
    //   });

    // click on next button
    jQuery(".form-wizard-next-btn").click(function () {
        var cartSection = $("#order-sec");
        var parentFieldset = cartSection.find(".wizard-fieldset.show");
        // console.log(parentFieldset, cartSection)
        var currentActiveStep = cartSection.find(".form-wizard-steps .active");
        var nextWizardStep = true;

        // parentFieldset.find(".wizard-required").each(function () {
        //   var thisValue = jQuery(this).val();
        //   if (thisValue == "") {
        //     jQuery(this).parent('.form-group').addClass("wizard-form-error");
        //     nextWizardStep = false;
        //   } else {
        //     jQuery(this).parent('.form-group').removeClass("wizard-form-error");
        //   }
        // });
        if (nextWizardStep && currentActiveStep.attr("data-step")) {
            const currentStep = Number(currentActiveStep.attr("data-step"));
            const totalSteps = Number(currentActiveStep.attr("data-steps")) || 0;
            const currentacStep =
                (totalSteps > 0 && Number(currentActiveStep.attr("data-current"))) || 1;
            if (currentStep > 0) {
                $(".form-wizard-previous-btn").addClass("activatedBtn");
            }
            const existingStep = currentActiveStep.next().attr("data-step") != null;
            const lastStep =
                currentActiveStep.next().attr("data-step") == null &&
                currentActiveStep.attr("data-step") != null;
            if (
                currentStep != null &&
                totalSteps !== 0 &&
                totalSteps > currentacStep
            ) {
                currentActiveStep.attr("data-current", currentacStep + 1);
            } else if (existingStep || lastStep) {
                currentActiveStep.removeClass("active");
                currentRightActiveStep(Number(currentActiveStep.attr("data-step")));
                if (existingStep) {
                    currentActiveStep
                        .addClass("activated")
                        .next()
                        .addClass("active", "400");
                } else {
                    currentActiveStep.addClass("activated lastactive");
                    $(".form-wizard-next-btn").removeClass("activatedBtn");
                    return;
                }
                console.log(Number(currentActiveStep.attr("data-step")));
            } else {
                return;
            }

            cartSection.find(".wizard-fieldset").removeClass("show", "400");
            parentFieldset.next(".wizard-fieldset").addClass("show", "400");
        }
    });
    //click on previous button
    jQuery(".form-wizard-previous-btn").click(function () {
        var cartSection = $("#order-sec");
        const lastActive = cartSection.find(".form-wizard-steps .lastactive");
        var currentActiveStep =
            lastActive?.length > 0
                ? lastActive
                : cartSection.find(".form-wizard-steps .active");
        const currentelTotalSteps =
            Number(currentActiveStep.attr("data-steps")) || 0;
        const currentelcurrentStep =
            Number(currentActiveStep.attr("data-current")) || 0;

        var currentWizard = cartSection.find(".wizard-fieldset.show");
        const prevElementTotalSteps =
            Number(currentActiveStep.prev().attr("data-steps")) || 0;
        const prevElementCurrentStep =
            Number(currentActiveStep.prev().attr("data-current")) || 0;
        const currentStep = Number(currentActiveStep.attr("data-step"));
        if (currentStep && currentStep - 1 > 1) {
            $(".form-wizard-next-btn").addClass("activatedBtn");

        } else {
            $(".form-wizard-previous-btn").removeClass("activatedBtn");
        }

        const prevElementCondition =
            prevElementTotalSteps !== 0 && prevElementCurrentStep >= 1;
        const currentElementCondition =
            currentActiveStep.prev().attr("data-step") != null;
        if (currentelTotalSteps !== 0 && currentelcurrentStep > 1) {
            currentActiveStep.removeClass("lastactive").removeClass("activated");
            currentActiveStep.attr("data-current", currentelcurrentStep - 1);
        } else if (prevElementCondition || currentElementCondition) {
            currentActiveStep.removeClass("lastactive").removeClass("activated");
            if (prevElementTotalSteps === prevElementCurrentStep) {
                var currentPrev = currentActiveStep
                    .removeClass("active")
                    .removeClass("lastactive");

                if (prevElementCondition) {
                    currentPrev.prev().removeClass("activated").addClass("active", "400");
                } else {
                    currentPrev
                        .removeClass("activated")
                        .prev()
                        .removeClass("activated")
                        .addClass("active", "400");
                }
                currentRightActiveStep(Number(currentPrev.attr("data-step")) - 2);
            }
        } else {
            return;
        }
        if (lastActive?.length > 0) {
            currentActiveStep
                .removeClass("lastactive")
                .removeClass("activated")
                .removeClass("activated");
        }
        currentWizard.removeClass("show", "400");
        currentWizard.prev(".wizard-fieldset").addClass("show", "400");

        // cartSection.find('.wizard-fieldset').each(function(){
        // 	if(jQuery(this).hasClass('show')){
        // 		var formAtrr = jQuery(this).attr('data-tab-content');
        // 		console.log(formAtrr)
        // 		jQuery(document).find('.form-wizard-steps .form-wizard-step-item').each(function(){
        // 			if(jQuery(this).attr('data-attr') == formAtrr){
        // 				jQuery(this).addClass('active');
        // 				var innerWidth = jQuery(this).innerWidth();
        // 				var position = jQuery(this).position();
        // 				jQuery(document).find('.form-wizard-step-move').css({"left": position.left, "width": innerWidth});
        // 				currentRightActiveStep(jQuery(this), "remove");
        // 			}else{
        // 				jQuery(this).removeClass('active');
        // 				currentRightActiveStep(jQuery(this), "add");
        // 			}
        // 		});
        // 	}
        // });
    });

    // Active right side
    function currentRightActiveStep(step = 0) {
        const orderdetails = $("#order-details");
        orderdetails.find(".step-details").each(function () {
            const currentItem = $(this);
            const itemstep = Number(currentItem.attr("data-step"));
            console.log({itemstep, step})
            if (itemstep <= step) {
                currentItem.addClass("order-detail-checked");
            } else {
                currentItem.removeClass("order-detail-checked");
            }
        });
    }

    //click on form submit button
    jQuery(document).on("click", ".form-wizard .form-wizard-submit", function () {
        var parentFieldset = jQuery(this).parents(".wizard-fieldset");
        var currentActiveStep = jQuery(this)
            .parents(".form-wizard")
            .find(".form-wizard-steps .active");
        // parentFieldset.find(".wizard-required").each(function () {
        //   var thisValue = jQuery(this).val();
        //   if (thisValue == "") {
        //     jQuery(this).parent('.form-group').addClass("wizard-form-error");
        //   } else {
        //     jQuery(this).parent('.form-group').removeClass("wizard-form-error");
        //   }
        // });
    });
    // focus on input field check empty or not
    // jQuery(".form-control")

    // .on("focus", function () {
    //   var tmpThis = jQuery(this).val();
    //   jQuery(this).parent('.form-group').removeClass("wizard-form-error");      
    //   if (tmpThis == "") {
    //     jQuery(this).parent().addClass("focus-input");
    //   } else if (tmpThis != "") {
    //     jQuery(this).parent().addClass("focus-input");


    //   }
    // })
    // .on("blur", function () {
    //   var tmpThis = jQuery(this).val();
    //   if (tmpThis == "") {
    //     jQuery(this).parent().removeClass("focus-input");
    //     jQuery(this).parent('.form-group').addClass("wizard-form-error");
    //   } else if (tmpThis != "") {
    //     jQuery(this).parent().addClass("focus-input");
    //     jQuery(this).parent('.form-group').removeClass("wizard-form-error");      }
    // });


    // form password fields

    $(".toggle-password").click(function() {
        $(this).toggleClass("icon-eye-view icon-Unhide");
        input = $(this).parent().find("input");
        if (input.attr("type") == "password") {
            input.attr("type", "text");
        } else {
            input.attr("type", "password");
        }
    });

    // terms and conditions accordions

    
      


});

/* Swiper Slider ---------------------- */

const swiper = new Swiper(".swiper", {
    // Optional parameters
    direction: "horizontal",
    slidesPerView: 7,
    spaceBetween: 20,
    clickable: true,
    loop: false,

    // Navigation arrows
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
});

let elTabBtn = document.querySelectorAll("[data-ctb-target]");
let elTabContent = document.querySelectorAll(".tab_content");

elTabBtn.forEach(function (el) {
    el.addEventListener("click", function (e) {
        let targetId = e.target.attributes["data-ctb-target"].value;
        elTabContent.forEach(function (el2) {
            el2.classList.remove("tc_active");
        });
        document.getElementById(targetId).classList.add("tc_active");
    });
});

elTabBtn.forEach(function (item) {
    item.addEventListener("click", function (e) {
            // ADDS AND REMOVES ACTIVE CLASS ON TABLINKS
            elTabBtn.forEach(function (item) {
                item.classList.remove("active");
            });
            item.classList.add("active");

            // SOMEHOW EQUATE TAB LINKS TO TAB PANES
            // console.log(e.target);
        },
        false
    );
});


// $(document).ready(function(){

//   $(".password-toggle").click(function () {

//     let passbtn = $('.password-toggle').html();

// if(passbtn == "Show"){
//  $('.password-toggle').html("Hide");
//  $('#loginPass').attr('type','text');

// }else{
//   $('.password-toggle').html("Show");
//   $('#loginPass').attr('type','password');

// }
// });


/* Window Scroll ---------------------- */

$(window).on("scroll", function () {
});

/* Window Resize ---------------------- */

$(window).on("resize", function () {
    fsHeight();
});
