<?php include 'incl/header.php'; ?>

    <main class="page__wrap">

        <main>
        <!-- <canvas id="canvas"> </canvas> -->

        <div class="page-banner-wrapper home-page-banner">

<div class="container-md">
<div class="page-banner-inner">
<div class="page-banner-title">
        <div class="banner-title-inner">
        <h2>Creative <span class="tg-lineare">Web Design &</span> <br> <span class="tg-lineare-reverse">Digital </span>Agency London.</h2>
        <p>Web Buds is a creative website design agency in London. A <b>team of talented web designers</b> in London.</p>
            <!-- <a href="#" class="theme-btn">Start Your Project</a> -->

            <a href="#" class="theme-btn">
  <div class="btn-circle border-primary" >
    <div class="btn-circle border-primary">
    Start Your Project
    </div>  
  </div>
</a>

            <div class="anim-cirlce xl-hide">
            <svg viewBox="0 0 100 100" width="100" height="100">
                <defs>
                    <path id="circle" d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"/>
                </defs>
                <text>
                    <textPath xlink:href="#circle">
                    We Create Fast websites
                    </textPath>
                </text>
                </svg>
            </div><!-- /.anim-cirlce -->
       
        </div>
</div><!-- /.page-banner-title -->
</div><!-- /.page-banner-inner -->
</div><!-- /.container-md -->

<span class="site-page-title">The&nbspSite Space</span>
</div><!-- /.page-banner-wrapper -->

    <div class="brand-info-wrapper section-space">
        <div class="brand-info-inner agency-info-cols">
            <div class="info-content-col info-col container-lg-half ms-auto">
                <div class="info-col-title">
                    <h4><small>A Full-Stack</small>Web design, digital marketing and app development agency in London.</h4>
                </div>
                <p>We are London based web design agency. A small team with big ideas. We specialise in bespoke web designing. From brochure websites to custom applications we do everything! Website design for everyone..</p>
            </div>
            <div class="info-figure-col info-col">
                <figure>
                    <img src="assets/images/brand-info-fig.png" alt="">
                </figure>
            </div>
        </div><!-- /.brand-info-inner -->
    </div><!-- /.brand-info-wrapper -->

        <div class="work-cols-wrapper section-space">
            <div class="container-lg">
                         <div class="section-title section-title-white">
                            <h4><span>Our</span> Work</h4>
                        </div><!-- /.section-title -->
                    <div class="work-cols-inner g-add-bg">
           
                    <div class="figure-col work-col">
                      
                        <figure>
                            <img src="assets/images/work-img-1.png" alt="">
                        </figure>
                    </div>
                    <div class="content-col work-col">

                        <div class="col-title">
                            <h4>Slice Ping Pong</h4>
                            <p>A great venue for ping pong, Table Foosball and Beer Pong Games</p>
                        </div><!-- /.col-title -->

                       <a href="#" class="theme-btn theme-btn-white">View Project</a>
                    </div>
                </div><!-- /.work-cols-inner -->




                <div class="work-cols-inner flex-row-reverse">
           
           <div class="figure-col work-col">
             
               <figure>
                   <img src="assets/images/work-img-2.png" alt="">
               </figure>
           </div>
           <div class="content-col work-col">

               <div class="col-title">
                   <h4>Team Triad</h4>
                   <p>Cultivating cultures of leadership excellence</p>
               </div><!-- /.col-title -->

              <a href="#" class="theme-btn theme-btn-white">View Project</a>
           </div>
       </div><!-- /.work-cols-inner -->


                <div class="work-cols-inner">
           
           <div class="figure-col work-col">
             
               <figure>
                   <img src="assets/images/work-img-3.png" alt="">
               </figure>
           </div>
           <div class="content-col work-col">

               <div class="col-title">
                   <h4>Apres Furniture</h4>
                   <p>We developed a beautiful eCommerce website for Après Furniture with lots of custom features.</p>
               </div><!-- /.col-title -->

              <a href="#" class="theme-btn theme-btn-white">View Project</a>
           </div>
       </div><!-- /.work-cols-inner -->


                <div class="work-cols-inner flex-row-reverse">
           
           <div class="figure-col work-col">
             
               <figure>
                   <img src="assets/images/work-img-4.png" alt="">
               </figure>
           </div>
           <div class="content-col work-col">

               <div class="col-title">
                   <h4>Celsius Dynamics</h4>
                   <p>Revolutionary logistics solutions and cold chain distributions services</p>
               </div><!-- /.col-title -->

              <a href="#" class="theme-btn theme-btn-white">View Project</a>
           </div>
       </div><!-- /.work-cols-inner -->
        <div class="view-projects-btn">

            <a href="#">View All Projects</a>
        </div>

            </div><!-- /.conainer-lg -->
        </div><!-- /.work-cols-wrapper -->

        <div class="svc-info-wrapper section-space">
            <div class="container-lg">
                <div class="section-title">
                            <h4><span>Our</span> Services</h4>
                        </div><!-- /.section-title -->
                </div><!-- /.container-lg -->

        <div class="brand-info-inner svc-info-inner agency-info-cols flex-row-reverse">
            <div class="info-content-col info-col container-lg-half me-auto">
                <div class="svcs-list" id="our-services">



                   <ul>
                        <li  data-img='./assets/images/svc-img-1.png'>
                        <div class='sv-item'>
                                <span>Custom Web Design.<small>WordPress, Laravel, React JS, WooCommerce, Shopify, Magento</small></span>
                            </div>
                        </li>
                        <li  data-img='./assets/images/work-img-2.png'>
                        <div class='sv-item'>
                                <span>Digital Marketing.<small>Search Engine Optimization (SEO), Social Media, PPC, Video Marketing</small></span>
</div>
                        </li  >
                        <li data-img='./assets/images/work-img-3.png'>
                            <div class='sv-item'>
                                <span>Branding & UI/UX Design.<small>UI/UX Design, Brand Identity, Social Media Designs</small></span>
</div>
                        </li >
                        <li data-img='./assets/images/work-img-4.png'>
                            <div class='sv-item'>
                                <span>Mobile App Development<small>Wordpress, Laravel. Shopify, WooCommerce, Shopify, React JS, Magento</small></span>
</div>
                        </li>
                        <li data-img='./assets/images/work-img-1.png'>
                            <div class='sv-item'>
                                <span>Content Creation.<small>Website Content, Blog Posts, Article Writing, Guest Posts</small></span>
</div>
                        </li>
                        <li data-img='./assets/images/work-img-2.png'>
                            <div class='sv-item'>
                                <span>Web App Development<small>UI/UX Design, Brand Identity, Social Media Designs</small></span>
</div>
                        </li>
                    </ul>
                </div><!-- /.svcs-list -->
            </div>
            <div class="info-figure-col info-col" id="sv-item-preview">
                <figure>
                    <img id='previewItem' src="" alt="">
                </figure>
            </div>
        </div><!-- /.brand-info-inner -->
    </div><!-- /.svc-info-wrapper -->

        <div class="testimonial-section">
            <div class="container-lg">
                <div class="testimonial-section-inner">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="usre-reviews-col col-left">
                            <div class="section-title">
                            <h4>Our Consistant 5 Star Reviews</h4>
                            </div><!-- /.section-title -->
                            <div class="reviews-content">
                                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Alias sequi optio maxime! Hic aut possimus temporibus delectus accusantium ratione voluptatibus modi error, corporis, tenetur et molestiae. Obcaecati veritatis voluptate omnis.</p>
                            </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="usre-reviews-col col-right">
                            <div class="swiper">

                                <div class="swiper-wrapper">

                                    <div class="swiper-slide">
                                        <div class="review-wrap">
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="swiper-slide">
                                    <div class="review-wrap">
                                            <div class="user-name-title">
                                                <b>Latoya Gabbidon <small>Owner - Candy Palazzo</small></b>
                                            </div><!-- /.user-name-title -->
                                            <div class="user-reviews">
                                                <p>The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex! Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox Fox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                               <div class="swiper-nav-icons">
                                        <div class="swiper-button-prev icon-arrow-left swiper-nav"></div>
                                        <div class="swiper-button-next icon-arrow-right swiper-nav"></div>
                               </div><!-- /.swiper-nav-icons -->

                        </div><!--/.swiper-->

                            </div>
                        </div>
                    </div>
                </div><!-- /.testimonial-section-inner -->
            </div><!-- /.container-lg -->
        </div><!-- /.testimonial-section -->


            <div class="blogs-section section-space">
                <div class="container-lg">
                    <div class="blogs-section-inner">
                        <div class="title-pod">
                        <div class="section-title">
                            <h4><span>Our Latest</span>Blogs</h4>
                        </div><!-- /.section-title -->
                            <div class="blog-btn-pod">
                                <a href="#" class="theme-btn">View All Blogs</a>
                            </div>
                        </div>

                        <div class="blogs-cols">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="blog-col">
                                        <figure>
                                            <img src="assets/images/blog-img-1.png" alt="">
                                            <div class="circle-complete-anim">
                               
                                                    <svg version="1.1" id="social-icons" class="svg-circle" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
                                                    y="0px" viewBox="0 0 24 24" style="enable-background:new 0 0 24 24;" xml:space="preserve">
                                               
                                                <circle id="circle" class="st0" cx="12" cy="12" r="10.5"/>

                                                </svg>
                                            </div><!-- /.circle-complete-anim -->
                                        </figure>
                                        <div class="blog-post-cols">
                                            <div class="post-time-col">
                                                <b>19:03</b><sup>2022</sup>
                                            </div>
                                            <div class="post-content-col">
                                                <p>7 Key Benefits of Pay Monthly Website : Your business doesn’t get the representation it needs in today’s world without a website.</p>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="blog-col">

                                    <figure>
                                        <img src="assets/images/blog-img-2.png" alt="">
                                        <div class="circle-complete-anim">
                             
                                                    <svg version="1.1" id="social-icons" class="svg-circle" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
                                                    y="0px" viewBox="0 0 24 24" style="enable-background:new 0 0 24 24;" xml:space="preserve">
                                            
                                                <circle id="circle" class="st0" cx="12" cy="12" r="10.5"/>

                                                </svg>
                                            </div><!-- /.circle-complete-anim -->
                                    </figure>

                                        <div class="blog-post-cols">
                                            <div class="post-time-col">
                                                <b>05:10</b><sup>2021</sup>
                                            </div>
                                            <div class="post-content-col">
                                                <p>Bad Website Design: Are You Making These Web Design Mistakes? You spend hours designing the perfect website.</p>
                                            </div>
                                        </div>

                              

                                    </div>
                                </div>
                             
                            </div>
                        </div><!-- /.blogs-cols -->

                    </div><!-- /.blogs-section-inner -->
                </div><!-- /.congainer-lg -->
            </div><!-- /.blogs-section -->

        </main>

    </main><!--/.page__wrap-->


    <!-- <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br> -->

<?php include 'incl/footer.php'; ?>

