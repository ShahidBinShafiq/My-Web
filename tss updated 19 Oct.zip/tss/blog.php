<?php include 'incl/header.php'; ?>

    <main class="page__wrap">

        <main>
        <!-- <canvas id="canvas"> </canvas> -->

        <div class="page-banner-wrapper home-page-banner">

<div class="container-md">
<div class="page-banner-inner">
<div class="page-banner-title">
        <div class="banner-title-inner">
        
        <h2>Latest <span class="tg-lineare">Insights, news,</span> And creative hacks and whatnot.</h2>
            <!-- <a href="#" class="theme-btn">Start Your Project</a> -->

           

            <div class="anim-cirlce xl-hide">
            <svg viewBox="0 0 100 100" width="100" height="100">
                <defs>
                    <path id="circle" d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"/>
                </defs>
                <text>
                    <textPath xlink:href="#circle">
                    We Create Fast websites
                    </textPath>
                </text>
                </svg>
            </div><!-- /.anim-cirlce -->
       
        </div>
</div><!-- /.page-banner-title -->
</div><!-- /.page-banner-inner -->
</div><!-- /.container-md -->
<div class="site-page-title">
<span class="title-line1">The Site</span>
<span class="title-line2">Space</span>
</div><!-- /.site-page-title -->
</div><!-- /.page-banner-wrapper -->

    <div class="services-tabs-section">
            <div class="container-lg">
                <div class="services-tabs-inner">
                <ul class="nav nav-tabs" id="myTab" role="tablist">



                <li class="nav-item" role="presentation">
                    <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab1" type="button" role="tab" aria-controls="tab1" aria-selected="true">All</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab2" type="button" role="tab" aria-controls="tab2" aria-selected="false">Website</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab3" type="button" role="tab" aria-controls="tab3" aria-selected="false">E-commerce</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab4" type="button" role="tab" aria-controls="tab4" aria-selected="false">SEO</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab5" type="button" role="tab" aria-controls="tab5" aria-selected="false">Digital Marketing</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab6" type="button" role="tab" aria-controls="tab6" aria-selected="false">UI Design</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab7" type="button" role="tab" aria-controls="tab6" aria-selected="false">Trending</button>
                </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="tab1" role="tabpanel" aria-labelledby="tab-1">
                    <div class="svc-tab-contnet-inner">
                        <div class="row">
                            <div class="col-md-4">
                               <div class="tab-col">
                                    <a href="blog-content.php">
                                    <figure class="figure-item"> <img class="justifier__thumb" loading="lazy" src="assets/images/blg-img-1.jpg" alt=""></figure>
                                <figcaption> <h4>Blog vs Website: Which one is Best for You?</h4>
                                <span>March 21, 2022</span>

                                </figcaption>
                                    </a>
                               </div>
                            </div>
                            <div class="col-md-4">
                                <div class="tab-col">
                                  <a href="blog-content.php">
                                  <figure class="figure-item"> <img class="justifier__thumb" loading="lazy" src="assets/images/blg-img-2.jpg" alt=""></figure>
                                    <figcaption> <h4>Blog vs Website: Which one is Best for You?</h4>
                                <span>March 21, 2022</span>

                                </figcaption>
                                  </a>
                                </div>
                            </div>
                            <div class="col-md-4">
                               <div class="tab-col">
                               <a href="blog-content.php">
                               <figure class="figure-item"> <img class="justifier__thumb" loading="lazy" src="assets/images/blg-img-3.jpg" alt=""></figure>
                               <figcaption> <h4>Blog vs Website: Which one is Best for You?</h4>
                                <span>March 21, 2022</span>

                                </figcaption>
                               </a>
                               </div>
                            </div>
                            <div class="col-md-4">
                                <div class="tab-col">
                                    <a href="blog-content.php">
                                    <figure class="figure-item"> <img class="justifier__thumb" loading="lazy" src="assets/images/blg-img-4.jpg" alt=""></figure>
                                <figcaption> <h4>Blog vs Website: Which one is Best for You?</h4>
                                <span>March 21, 2022</span>

                                </figcaption>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="tab-col">
                                <a href="blog-content.php">
                                <figure class="figure-item"> <img class="justifier__thumb" loading="lazy" src="assets/images/blg-img-5.jpg" alt=""></figure>
                               <figcaption> <h4>Blog vs Website: Which one is Best for You?</h4>
                                <span>March 21, 2022</span>

                                </figcaption>
                                </a>
                                </div>
                            </div>
                            <div class="col-md-4">
                               <div class="tab-col">
                                <a href="blog-content.php">
                                <figure class="figure-item"> <img class="justifier__thumb" loading="lazy" src="assets/images/blg-img-6.jpg" alt=""></figure>
                               <figcaption> <h4>Blog vs Website: Which one is Best for You?</h4>
                                <span>March 21, 2022</span>

                                </figcaption>
                                </a>
                               </div>
                            </div>
                            <div class="col-md-4">
                               <div class="tab-col">
                                <a href="blog-content.php">
                                <figure class="figure-item"> <img class="justifier__thumb" loading="lazy" src="assets/images/blg-img-7.jpg" alt=""></figure>
                               <figcaption> <h4>Blog vs Website: Which one is Best for You?</h4>
                                <span>March 21, 2022</span>

                                </figcaption>
                                </a>
                               </div>
                            </div>
                            <div class="col-md-4">
                                <div class="tab-col">
                                    <a href="blog-content.php">
                                    <figure class="figure-item"> <img class="justifier__thumb" loading="lazy" src="assets/images/blg-img-8.jpg" alt=""></figure>
                                <figcaption> <h4>Blog vs Website: Which one is Best for You?</h4>
                                <span>March 21, 2022</span>

                                </figcaption>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4">
                               <div class="tab-col">
                                <a href="blog-content.php">
                                <figure class="figure-item"> <img class="justifier__thumb" loading="lazy" src="assets/images/blg-img-9.jpg" alt=""></figure>
                               <figcaption> <h4>Blog vs Website: Which one is Best for You?</h4>
                                <span>March 21, 2022</span>

                                </figcaption>
                                </a>
                               </div>
                            </div>
                        </div>
                        <a href="#" class="more-svc-tabs-btn">Show More</a>
                    </div><!-- /.svc-tab-contnet-inner -->


                </div>
                <div class="tab-pane fade" id="tab2" role="tabpanel" aria-labelledby="tab-2">Website</div>
                <div class="tab-pane fade" id="tab3" role="tabpanel" aria-labelledby="tab-3">E-Commerce</div>
                <div class="tab-pane fade" id="tab4" role="tabpanel" aria-labelledby="tab-4">SEO</div>
                <div class="tab-pane fade" id="tab5" role="tabpanel" aria-labelledby="tab-5">Digital Marketing</div>
                <div class="tab-pane fade" id="tab6" role="tabpanel" aria-labelledby="tab-6">UI Design</div>
                <div class="tab-pane fade" id="tab7" role="tabpanel" aria-labelledby="tab-7">Trending</div>
                </div>



                </div><!-- /.services-tabs-inner -->
            </div><!-- /.container-lg -->
    </div><!-- /.services-tabs-section -->




        </main>

    </main><!--/.page__wrap-->


    <!-- <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br> -->

<?php include 'incl/footer.php'; ?>

