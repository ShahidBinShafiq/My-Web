

import {Link} from 'react-router-dom'




const TechItemsList = ()=> {
  return (
    <div className="tech-list-wrap">
        <div className="container">
            <div className="tech-list-inner">
                <div className="section-title">
                    <h4 className="text-center py-5">Select Your Item for Repairing</h4>
                </div>
                <div className="row">

                    <div className="col-md-3">
                        <div className="tech-item-col">
                        <div class="card">
                            <img src="./images/smartphone.webp" class="card-img-top" alt="..."/>
                            <div class="card-body">
                                <h5 class="card-title text-center">Smart Phones</h5>
                                <Link to="/smartphone" className='btn btn-success mx-auto d-block text-white'> Select</Link>

                            </div>
                            </div>
                        </div>
                    </div>


                    <div className="col-md-3">
                        <div className="tech-item-col">
                        <div class="card">
                        <img src="./images/tablet.webp" class="card-img-top" alt="..."/>
                            <div class="card-body">
                                <h5 class="card-title text-center">Tablets</h5>
                                <a href="#" class="btn btn-success mx-auto d-block text-white">Select Item</a>
                            </div>
                            </div>
                        </div>
                    </div>


                    <div className="col-md-3">
                        <div className="tech-item-col">
                        <div class="card">
                        <img src="./images/laptop.webp" class="card-img-top" alt="..."/>
                            <div class="card-body">
                                <h5 class="card-title text-center">Laptops</h5>
                                <a href="#" class="btn btn-success mx-auto d-block text-white">Select Item</a>
                            </div>
                            </div>
                        </div>
                    </div>


                    <div className="col-md-3">
                        <div className="tech-item-col">
                        <div class="card">
                        <img src="./images/smart-watch.webp" class="card-img-top" alt="..."/>
                            <div class="card-body">
                                <h5 class="card-title text-center">Smart Watches</h5>
                                <a href="#" class="btn btn-success mx-auto d-block text-white">Select Item</a>
                            </div>
                            </div>
                        </div>
                    </div>
                   
                    
                </div>
            </div>
        </div>

    </div>
  )
}

export default TechItemsList