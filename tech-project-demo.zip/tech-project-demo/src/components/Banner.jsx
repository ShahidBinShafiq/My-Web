




const Banner = ()=> {
  return (
    <div className="banner-wrap">
      
        <div className="banner-image">
        <img src="./images/hero-image.jpg" alt="" />
        <div className="banner-caption">
          <h1></h1>
        </div>
        </div>
      </div>
  )
}

export default Banner