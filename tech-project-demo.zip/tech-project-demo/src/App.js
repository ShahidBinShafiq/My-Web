import './App.css';
import Home from './Pages/Home';
import About from './Pages/About';
import Contact from './Pages/Contact';
import {BrowserRouter as Router, Routes, Route,} from "react-router-dom";
import Signin from './Pages/Signin';
import Signup from './Pages/Signup';
import Cart from './Pages/Cart';
import SmartPhone from "./Pages/SmartPhone";
import Samsung from "./Pages/Samsung";
import Huawei from "./Pages/Huawei";
import Apple from "./Pages/Apple";
import Redmi from "./Pages/Redmi";

function App() {
  return (
    <div className="App">
      
    <Router>
      <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/about" element={<About/>}/>
          <Route path="/contact" element={<Contact/>}/>
          <Route path="/signin" element={<Signin/>}/>
          <Route path="/signup" element={<Signup/>}/>
          <Route path="/cart" element={<Cart/>}/>
          <Route path="/smartphone" element={<SmartPhone/>}/>
          <Route path="/samsung" element={<Samsung/>}/>
          <Route path="/huawei" element={<Huawei/>}/>
          <Route path="/apple" element={<Apple/>}/>
          <Route path="/redmi" element={<Redmi/>}/>
      </Routes>
    </Router>


    </div>
  );
}

export default App;
