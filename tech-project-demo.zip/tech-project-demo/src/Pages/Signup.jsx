import Header from "../components/Header"





const Signup = ()=> {
  return (
    <div>
        <Header/>
        <div className="signin-wrapper">
          <div className="container-sm">
            <div className="signup-inner">
            <div class="form-body">
        <div class="row">
            <div class="form-holder">
                <div class="form-content">
                    <div class="form-items">
                        <h3>Create Your Account</h3>
                        <p>Fill in the data below.</p>
                        <form class="requires-validation" novalidate>

                            <div class="col-md-12">
                               <input class="form-control mb-3" type="text" name="name" placeholder="First Name" required/>
                               <div class="valid-feedback">Username field is valid!</div>
                               <div class="invalid-feedback">Username field cannot be blank!</div>
                            </div>

                            <div class="col-md-12">
                               <input class="form-control mb-3" type="text" name="name" placeholder="Last Name" required/>
                               <div class="valid-feedback">Username field is valid!</div>
                               <div class="invalid-feedback">Username field cannot be blank!</div>
                            </div>

                            <div class="col-md-12">
                                <input class="form-control mb-3" type="email" name="email" placeholder="E-mail Address" required/>
                                 <div class="valid-feedback">Email field is valid!</div>
                                 <div class="invalid-feedback">Email field cannot be blank!</div>
                            </div>

                           <div class="col-md-12">
                           <input class="form-control mb-3" type="text" name="password" placeholder="Phone Number" required/>
                               <div class="valid-feedback">Password field is valid!</div>
                               <div class="invalid-feedback">Password field cannot be blank!</div>
                           </div>


                           <div class="col-md-12">
                              <input class="form-control mb-3" type="password" name="password" placeholder="Password" required/>
                               <div class="valid-feedback">Password field is valid!</div>
                               <div class="invalid-feedback">Password field cannot be blank!</div>
                           </div>


                           <div class="col-md-12">
                              <input class="form-control mb-3" type="password" name="re-enter-password" placeholder="Re-Enter Password" required/>
                               <div class="valid-feedback">Password field is valid!</div>
                               <div class="invalid-feedback">Password field cannot be blank!</div>
                           </div>


                           <div class="col-md-12 mb-3">
                            <label class="mb-3 mr-1" for="gender">Gender: </label>

                            <input type="radio" class="btn-check" name="gender" id="male" autocomplete="off" required/>
                            <label class="btn btn-sm btn-outline-secondary m-1" for="male">Male</label>

                            <input type="radio" class="btn-check" name="gender" id="female" autocomplete="off" required/>
                            <label class="btn btn-sm btn-outline-secondary m-1" for="female">Female</label>

                            {/* <input type="radio" class="btn-check" name="gender" id="secret" autocomplete="off" required/>
                            <label class="btn btn-sm btn-outline-secondary m-1" for="secret">Secret</label>
                               <div class="valid-feedback mv-up">You selected a gender!</div>
                                <div class="invalid-feedback mv-up">Please select a gender!</div> */}
                            </div>

                       
                  

                            <div class="form-button mt-3">
                                <button id="submit" type="submit" class="btn btn-primary w-100">Create an Account</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

            </div>
          </div>
        </div>
        </div>
  )
}

export default Signup