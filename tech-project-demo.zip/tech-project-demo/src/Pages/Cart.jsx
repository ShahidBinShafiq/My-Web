import Header from "../components/Header"





const Cart = ()=> {
  return (
    <div>
        <Header/>

        <div className="cart-wrapper">
          <div className="container">
            <div className="cart-inner">
              <div className="cart-item-pod shadow bg-white">
                  <div className="cart-inner p-3">
                    <div className="row">
                      <div className="col-lg-6 col-md-12">
                          <div className="cart-item-col col-left">
                          <h4>Samsung Galaxy Note 10
                          <small className="d-block">Screen Replacement</small>
                        </h4>
                          </div>
                      </div>
                      <div className="col-lg-6 col-md-12">
                       <div className="cart-item-col col-right">
                       <span className="me-2">Number of Items</span>
                       <input type="number" className="me-2 item-counter"/>
                       <button className="btn btn-danger">Delete</button>
                       </div>
                      </div>
                    </div>
                  </div>
              </div>
              <div className="cart-item-pod shadow bg-white">
                  <div className="cart-inner p-3">
                    <div className="row">
                      <div className="col-lg-6 col-md-12">
                          <div className="cart-item-col col-left">
                          <h4>Samsung Note 5
                          <small className="d-block">Reapring</small>
                        </h4>
                          </div>
                      </div>
                      <div className="col-lg-6 col-md-12">
                       <div className="cart-item-col col-right">
                       <span className="me-2">Number of Items</span>
                       <input type="number" className="me-2 item-counter"/>
                       <button className="btn btn-danger">Delete</button>
                       </div>
                      </div>
                    </div>
                  </div>
              </div>

              <div className="cart-item-pod shadow bg-white">
                  <div className="cart-inner p-3">
                    <div className="row">
                      <div className="col-lg-6 col-md-12">
                          <div className="cart-item-col col-left">
                          <h4>Apple 13Pro
                          <small className="d-block">Battery Replacement</small>
                        </h4>
                          </div>
                      </div>
                      <div className="col-lg-6 col-md-12">
                       <div className="cart-item-col col-right">
                       <span className="me-2">Number of Items</span>
                       <input type="number" className="me-2 item-counter"/>
                       <button className="btn btn-danger">Delete</button>
                       </div>
                      </div>
                    </div>
                  </div>
              </div>
            </div>
          </div>
        </div>

    </div>
  )
}

export default Cart