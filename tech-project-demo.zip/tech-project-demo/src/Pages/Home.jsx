import Banner from "../components/Banner"
import Header from "../components/Header"
import TechItemsList from "../components/TechItemsList"





const Home = ()=> {
  return (
    <div className="page-wrapper">
        <Header/>
        <Banner/>
        <TechItemsList/>
        <div className="brand-info-wrapper">
          <div className="container">
            <div className="brand-info-inner py-5">
              <h2 className="text-center theme-color mb-4">The Complete Guide to Tech Specialist for Cell Phone Repair</h2>
              <p className="mb-5">In the heat gun for cell phone repair article, we will explore What is a Heat Gun and Why Would You Need One for Cell Phone Repair. Different types of phone heat guns that are available on the market today and what they can be used for.</p>
              <h2 className="text-center theme-color mb-4">What is the need for Tech Specialist for Cell Phone Repair? 
</h2>
              <p className="">A heat gun is an electrical and electronic device that heats up and emits hot air. It is used for a variety of purposes, including cooking, dry cleaning, removing adhesive substances from surfaces, and for soldering electronic components. The heat gun is used in cell phone repair to soften glue or other adhesive substances that are holding parts together on the back of the phone. mostly heat gun for fixing phones are used to soften and remove the adhesive from the front LCD glass of a cell phone or other electronic device.
</p>
            </div>
          </div>
        </div>
    </div>
  )
}

export default Home