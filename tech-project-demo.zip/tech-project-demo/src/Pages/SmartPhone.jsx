
import {Link} from 'react-router-dom'
import Header from "../components/Header";





const  SmartPhone = ()=> {

    return (

        <div className='smartphone-wrapper'>
            <Header/>
           <div className="container">
               <div className="smartphone-wrap-inner">
                   <h1 className="text-center py-5 bg-primary text-white mt-2">Select Your Category</h1>

                   <div className="row">
                       <div className="col-md-3">
                           <div className="card p-2">
                           <img src="./images/samsung.png" class="card-img-top" alt="..."/>                                   
                           <div className="card-body">
                                       <h5 className="card-title text-center">Samsung</h5>

                                       <Link to='/samsung' className="btn btn-primary d-block">Select Item</Link>
                                   </div>
                           </div>
                       </div>

                       <div className="col-md-3">
                           <div className="card p-2">
                           <img src="./images/huawei.png" class="card-img-top" alt="..."/>                               
                           <div className="card-body">
                                   <h5 className="card-title text-center">Huawei</h5>
                                   <Link to='/huawei' className="btn btn-primary d-block">Select Item</Link>
                               </div>
                           </div>
                       </div>

                       <div className="col-md-3">
                           <div className="card p-2">
                           <img src="./images/apple.png" class="card-img-top" alt="..."/>                               
                           <div className="card-body">
                                   <h5 className="card-title text-center">Apple</h5>
                                   <Link to='/apple' className="btn btn-primary d-block">Select Item</Link>
                               </div>
                           </div>
                       </div>

                       <div className="col-md-3">
                           <div className="card p-2">
                           <img src="./images/redmi.png" class="card-img-top" alt="..."/>                               
                           <div className="card-body">
                                   <h5 className="card-title text-center">Redmi</h5>
                                   <Link to='/redmi' className="btn btn-primary d-block">Select Item</Link>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
        </div>

    )

}

export default SmartPhone