




import {Link} from 'react-router-dom'
import Header from "../components/Header";





const  Samsung = ()=> {

    return (

        <div className='smartphone-wrapper'>
            <Header/>
            <div className="container">
                <div className="smartphone-wrap-inner">
                    <h1 className="text-center py-5 bg-info text-white mt-2">Samsung Phones</h1>

                    <div className="row">
                        <div className="col-md-3">
                            <div className="card">
                                <img src="./images/note-10.webp" className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h5 className="card-title text-center">Galaxy Note10</h5>
                                    <select className='form-control bg-info text-white'>
                                        <option value="reparing issue">Select Repairing Issue</option>
                                        <option value="Diagnostics">Diagnostics</option>
                                        <option value="Screen Replacement">Screen Replacement</option>
                                        <option value="Battery Replacement">Battery Replacement</option>
                                        <option value="Not Charging">Not Charging</option>
                                        <option value="Front Camera">Front Camera</option>
                                        <option value="Loudspeaker">Loudspeaker</option>
                                        <option value="Wifi Problem">Wifi Problem</option>
                                        <option value="Simcard Problem">Simcard Problem</option>
                                    </select>
                                    <button className="btn theme-color-bg text-white w-100 my-2">Add to Cart</button>
                                    <input type="number" className="w-100 item-counter" placeholder='Number of Items'/>

                                </div>
                            </div>
                        </div>

                        <div className="col-md-3">
                            <div className="card">
                                <img src="./images/a70.webp" className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h5 className="card-title text-center">Galaxy A70</h5>
                                    <select className='form-control bg-info text-white'>
                                        <option value="reparing issue">Select Repairing Issue</option>
                                        <option value="Diagnostics">Diagnostics</option>
                                        <option value="Screen Replacement">Screen Replacement</option>
                                        <option value="Battery Replacement">Battery Replacement</option>
                                        <option value="Not Charging">Not Charging</option>
                                        <option value="Front Camera">Front Camera</option>
                                        <option value="Loudspeaker">Loudspeaker</option>
                                        <option value="Wifi Problem">Wifi Problem</option>
                                        <option value="Simcard Problem">Simcard Problem</option>
                                    </select>
                                    <button className="btn theme-color-bg text-white w-100 my-2">Add to Cart</button>
                                    <input type="number" className="w-100 item-counter" placeholder='Number of Items'/>
                                </div>
                            </div>
                        </div>

                        <div className="col-md-3">
                            <div className="card">
                            <img src="./images/a20e.webp" className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h5 className="card-title text-center">Galaxy A20e</h5>
                                    <select className='form-control bg-info text-white'>
                                        <option value="reparing issue">Select Repairing Issue</option>
                                        <option value="Diagnostics">Diagnostics</option>
                                        <option value="Screen Replacement">Screen Replacement</option>
                                        <option value="Battery Replacement">Battery Replacement</option>
                                        <option value="Not Charging">Not Charging</option>
                                        <option value="Front Camera">Front Camera</option>
                                        <option value="Loudspeaker">Loudspeaker</option>
                                        <option value="Wifi Problem">Wifi Problem</option>
                                        <option value="Simcard Problem">Simcard Problem</option>
                                    </select>
                                    <button className="btn theme-color-bg text-white w-100 my-2">Add to Cart</button>
                                    <input type="number" className="w-100 item-counter" placeholder='Number of Items'/>
                                </div>
                            </div>
                        </div>

                        <div className="col-md-3">
                            <div className="card">
                            <img src="./images/note-8.webp" className="card-img-top" alt="..."/>
                                <div className="card-body">
                                    <h5 className="card-title text-center">Galaxy Note8</h5>
                                    <select className='form-control bg-info text-white'>
                                        <option value="reparing issue">Select Repairing Issue</option>
                                        <option value="Diagnostics">Diagnostics</option>
                                        <option value="Screen Replacement">Screen Replacement</option>
                                        <option value="Battery Replacement">Battery Replacement</option>
                                        <option value="Not Charging">Not Charging</option>
                                        <option value="Front Camera">Front Camera</option>
                                        <option value="Loudspeaker">Loudspeaker</option>
                                        <option value="Wifi Problem">Wifi Problem</option>
                                        <option value="Simcard Problem">Simcard Problem</option>
                                    </select>
                                    <button className="btn theme-color-bg text-white w-100 my-2">Add to Cart</button>
                                    <input type="number" className="w-100 item-counter" placeholder='Number of Items'/>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="addto-cart-btn">
                    <Link to="/cart" className='btn theme-color-bg text-white mx-auto w-50 d-table mt-5'> SHOW MY CART </Link>

                    </div>
                </div>
            </div>
        </div>

    )

}

export default Samsung