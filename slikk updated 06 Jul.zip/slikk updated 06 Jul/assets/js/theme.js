/**
 * @var $ jQuery
 */

// Full Height...
function fsHeight() {
    let winHeight = $(window).height();
    $('[data-height="viewport"]').css('height', winHeight, '!important');
    $('[data-min-height="viewport"]').css('minHeight', winHeight, '!important');
}

/* Window Load ---------------------- */

$(window).on('load', function () {

    setTimeout(function () {
        $('body').addClass('loaded');
    }, 400);

    // setTimeout(function () {
    //     AOS.init({
    //         once: true,
    //         duration: 1000
    //     });
    // }, 800);

});


/* Document Ready ---------------------- */

$(document).ready(function () {

    fsHeight();


    // Inline background image...
    $("[data-bg]").each(function () {
        const image = $(this).attr("data-bg");
        $(this).css({
            backgroundImage: 'url("' + image + '")',
        });
    });


         // student section form validation...
    
        //  $('#studentCheck').click(function() {
        //     if ($(this).is(':checked')) {
        //       $("#student-registeration").css({
        //         opacity: "1",
        //         pointerEvents: "auto",
                
        //     })
    
        //     } else {
        //       $("#student-registeration").css({
        //         opacity: ".4",
        //         pointerEvents: "none",
                
        //     })
        //     }
        //   });




     // register user form validation...
    
    //  $('#terms').click(function() {
    //     if ($(this).is(':checked')) {
    //       $('#registerbtn').removeAttr('disabled');
    //       $("#registerbtn").css({
    //         opacity: "1",
            
    //     })

    //     } else {
    //       $('#registerbtn').attr('disabled', 'disabled');
    //       $("#registerbtn").css({
    //         opacity: ".4",
            
    //     })
    //     }
    //   });





    // click on next button
	jQuery('.form-wizard-next-btn').click(function() {
		var cartSection = $("#order-sec")
		var parentFieldset = cartSection.find('.wizard-fieldset.show');
		// console.log(parentFieldset, cartSection)
		var currentActiveStep =cartSection.find('.form-wizard-steps .active');
		var nextWizardStep = true;
		parentFieldset.find('.wizard-required').each(function(){
			var thisValue = jQuery(this).val();

			if( thisValue == "") {
				jQuery(this).siblings(".wizard-form-error").slideDown();
				nextWizardStep = false;
			}
			else {
				jQuery(this).siblings(".wizard-form-error").slideUp();
			}
		});
		console.log("steps",currentActiveStep.attr('data-step'))
		if( nextWizardStep) {
			cartSection.find('.wizard-fieldset').removeClass("show","400");
			// const currentStep = Number(currentActiveStep.attr('data-step'))
			const totalSteps = Number(currentActiveStep.attr('data-steps')) || 0
			const currentacStep = Number(currentActiveStep.attr('data-current')) || 1
			if (totalSteps !== 0 && totalSteps > currentacStep) {
				currentActiveStep.attr('data-current', currentacStep + 1)
			}else{
				currentActiveStep.removeClass('active').addClass('activated').next().addClass('active',"400");
				currentRightActiveStep(Number(currentActiveStep.attr('data-step')))
			}
			parentFieldset.next('.wizard-fieldset').addClass("show","400");
			
			// cartSection.find('.wizard-fieldset').each(function(){
			// 	if(jQuery(this).hasClass('show')){
			// 		var formAtrr = jQuery(this).attr('data-tab-content');
			// 		console.log(formAtrr)
			// 		cartSection.find('.form-wizard-steps .form-wizard-step-item').each(function(){
			// 			if(jQuery(this).attr('data-attr') == formAtrr){
			// 				jQuery(this).addClass('active');
			// 				var innerWidth = jQuery(this).innerWidth();
			// 				var position = jQuery(this).position();
			// 				jQuery(document).find('.form-wizard-step-move').css({"left": position.left, "width": innerWidth});
			// 			}else{
			// 				jQuery(this).removeClass('active');
			// 			}
			// 		});
			// 	}
			// });
		}
	});
	//click on previous button
	jQuery('.form-wizard-previous-btn').click(function() {
		var cartSection = $("#order-sec")
		var counter = parseInt(jQuery(".wizard-counter").text());;
		var currentActiveStep = cartSection.find('.form-wizard-steps .active');
		const currentelTotalSteps = Number(currentActiveStep.attr('data-steps')) || 0;
		const currentelcurrentStep = Number(currentActiveStep.attr('data-current')) || 0;


		var currentWizard = cartSection.find('.wizard-fieldset.show');
		const prevElementTotalSteps = Number(currentActiveStep.prev().attr('data-steps')) || 0;
		const currentStep = Number(currentActiveStep.prev().attr('data-step'));
		const prevElementCurrentStep = Number(currentActiveStep.prev().attr('data-current')) || 0
		if (currentelcurrentStep !== 0) {
			if (currentelTotalSteps !== 0 && currentelcurrentStep >= 1) {
				currentActiveStep.attr('data-current', currentelcurrentStep - 1)
			}else{
				var currentPrev = currentActiveStep.removeClass('active').prev().removeClass('activated').addClass('active',"400");
				currentRightActiveStep(Number(currentPrev.attr('data-step')) - 1)
			}
		}else if (prevElementTotalSteps !== 0 && prevElementCurrentStep >= 1) {
			currentActiveStep.prev().attr('data-current', prevElementCurrentStep - 1)
			if (prevElementTotalSteps === prevElementCurrentStep) {
					
				currentActiveStep.removeClass('active').prev().removeClass('activated').addClass('active',"400");
				currentRightActiveStep(Number(currentActiveStep.prev().attr('data-step')) - 1)
			}
		}else{
			var currentPrev = currentActiveStep.removeClass('active').prev().removeClass('activated').addClass('active',"400");
			currentRightActiveStep(Number(currentPrev.attr('data-step')) - 1)
		}
		currentWizard.removeClass("show","400");
		currentWizard.prev('.wizard-fieldset').addClass("show","400");

		// cartSection.find('.wizard-fieldset').each(function(){
		// 	if(jQuery(this).hasClass('show')){
		// 		var formAtrr = jQuery(this).attr('data-tab-content');
		// 		console.log(formAtrr)
		// 		jQuery(document).find('.form-wizard-steps .form-wizard-step-item').each(function(){
		// 			if(jQuery(this).attr('data-attr') == formAtrr){
		// 				jQuery(this).addClass('active');
		// 				var innerWidth = jQuery(this).innerWidth();
		// 				var position = jQuery(this).position();
		// 				jQuery(document).find('.form-wizard-step-move').css({"left": position.left, "width": innerWidth});
		// 				currentRightActiveStep(jQuery(this), "remove");
		// 			}else{
		// 				jQuery(this).removeClass('active');
		// 				currentRightActiveStep(jQuery(this), "add");
		// 			}
		// 		});
		// 	}
		// });
	});
	// Active right side
	function currentRightActiveStep(step=0){
		const orderdetails =  $('#order-details');
		orderdetails.find('.step-details').each(function()  {
			const currentItem = $(this);
			const itemstep = Number(currentItem.attr('data-step'));

	if (itemstep <= step){
		currentItem.addClass('order-detail-checked')
	}else {
		currentItem.removeClass('order-detail-checked')
	}
			})



	}
	//click on form submit button
	jQuery(document).on("click",".form-wizard .form-wizard-submit" , function(){
		var parentFieldset = jQuery(this).parents('.wizard-fieldset');
		var currentActiveStep = jQuery(this).parents('.form-wizard').find('.form-wizard-steps .active');
		parentFieldset.find('.wizard-required').each(function() {
			var thisValue = jQuery(this).val();
			if( thisValue == "" ) {
				jQuery(this).siblings(".wizard-form-error").slideDown();
			}
			else {
				jQuery(this).siblings(".wizard-form-error").slideUp();
			}
		});
	});
	// focus on input field check empty or not
	jQuery(".form-control").on('focus', function(){
		var tmpThis = jQuery(this).val();
		if(tmpThis == '' ) {
			jQuery(this).parent().addClass("focus-input");
		}
		else if(tmpThis !='' ){
			jQuery(this).parent().addClass("focus-input");
		}
	}).on('blur', function(){
		var tmpThis = jQuery(this).val();
		if(tmpThis == '' ) {
			jQuery(this).parent().removeClass("focus-input");
			jQuery(this).siblings('.wizard-form-error').slideDown("3000");
		}
		else if(tmpThis !='' ){
			jQuery(this).parent().addClass("focus-input");
			jQuery(this).siblings('.wizard-form-error').slideUp("3000");
		}
	});




});









/* Swiper Slider ---------------------- */

const swiper = new Swiper('.swiper', {
	// Optional parameters
	direction: 'horizontal',
	loop: true,
  
	// If we need pagination
	pagination: {
	  el: '.swiper-pagination',
	},
  
	// Navigation arrows
	navigation: {
	  nextEl: '.swiper-button-next',
	  prevEl: '.swiper-button-prev',
	},
  
	// And if we need scrollbar
	scrollbar: {
	  el: '.swiper-scrollbar',
	},
  });




/* Window Scroll ---------------------- */

$(window).on('scroll', function () {


});


/* Window Resize ---------------------- */

$(window).on('resize', function () {

    fsHeight();

});