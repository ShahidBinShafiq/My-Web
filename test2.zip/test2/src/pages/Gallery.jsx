import Header from "../components/Header"






function Gallery() {
  return (
    <div>
        <Header/>

        <h1>This is Gallery Page</h1>
    </div>
  )
}

export default Gallery