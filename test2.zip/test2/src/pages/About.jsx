import Header from "../components/Header"






const About =()=> {
  return (
    <div>
      <Header/>
        <h1>This is About Page</h1>
    </div>
  )
}

export default About