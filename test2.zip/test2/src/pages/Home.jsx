
import Header from "../components/Header"



const Home = ()=> {
  return (
    <div>
          <Header/>

        <h1>This is Home Page</h1>
    </div>
  )
}

export default Home