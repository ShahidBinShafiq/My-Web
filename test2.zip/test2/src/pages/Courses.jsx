import Header from "../components/Header"





const Courses = ()=> {
  return (
    <div>
      <Header/>
      <h1>This is Courses Page</h1>
      </div>
  )
}

export default Courses