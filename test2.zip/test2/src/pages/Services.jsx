import Header from "../components/Header"






const Services=()=> {
  return (
    <div>
      
      <Header/>
      <h1>This is Services Page</h1>
      </div>
  )
}

export default Services