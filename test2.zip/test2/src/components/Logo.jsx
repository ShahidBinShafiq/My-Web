



function Logo() {
  return (
    <div>
        <h1>STICS</h1>
    </div>
  )
}

export default Logo