import { useState } from "react"

import { Link } from "react-router-dom";




const Navbar =()=> {

const [navitem, setNavitem] = useState([
    {
        home: "Home",
        courses: "Courses",
        services: "Services",
        about: "About",
        gallery: "Gallery",
    }
])



  return (
    <div>
        {
            navitem.map((item)=>{
                return(
                    <div>
                        <ul>
                            <li>
                                <Link to="/home">{item.home}</Link>
                            </li>
                            <li>
                                <Link to="/courses">{item.courses}</Link>
                            </li>
                            <li>
                                <Link to="/services">{item.services}</Link>
                            </li>
                            <li>
                                <Link to="/about">{item.about}</Link>
                            </li>
                            <li>
                                <Link to="/gallery">{item.gallery}</Link>
                            </li>
                           
                        </ul>
                    </div>
                )
            })
        }
    </div>
  )
}

export default Navbar