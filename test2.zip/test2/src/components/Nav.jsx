import Logo from "./Logo"
import Navbar from "./Navbar"




function Nav() {
  return (
   <div className="nav-wrapper">
    <div className="container">
        <div className="nav-inner">
            <Logo/>
        <Navbar/>

        </div>
    </div>
   </div>
  )
}

export default Nav