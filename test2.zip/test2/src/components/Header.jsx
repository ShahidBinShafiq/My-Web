import Nav from "./Nav"






function Header() {
  return (
    
    <Nav/>


  )
}

export default Header