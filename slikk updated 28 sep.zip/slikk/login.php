<?php include 'incl/header.php'; ?>

    <main class="page__wrap">
        <div class="login-wrapper">
            <div class="login-inner">
                <div class="login-title">
                  <h1>Login to your account</h1>
                </div>

                <div class="login-pods">
                  <form action="">
                  <div class="mb-3">
                  <input type="email" class="form-control"  placeholder="Email">
                </div>
                <div class="mb-3">
                  <input type="password" class="form-control"  placeholder="Password">
                </div>

                <div class="loging-credentials">
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" value="" id="remember-cred">
                      <label class="form-check-label" for="remember-cred">
                        Remember me
                      </label>
                    </div>

                    <div class="pass-forgot">
                      <a href="#"> Forgot password?</a>
                    </div>
                </div><!-- /.login-credentials -->
                  <div class="login-footer">
                      <div class="login-btns">
                        <button type="submit" class="theme-btn btn-black-theme login-btn">Login</button>
                        <a href="account.php" type="button" class="theme-btn btn-black-theme login-btn">Create an account</a>
                      </div>
                  </div><!-- /.login-footer -->
                  </form>
                </div>


            </div><!-- /.login-inner -->
        </div><!-- /.login-wrapper -->

    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>