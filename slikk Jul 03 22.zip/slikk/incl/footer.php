<footer class="footer__wrap aside_space">

<div class="footer-cols">
           <div class="container-md">
                <div class="footer-cols-inner">
                <div class="row">
                <div class="col-md-4">
                    <div class="foot-col">
                        <a href="./index.php">
                        <img src="assets/images/icons/brand-logo.svg" alt="" class="brand-logo">
                        </a>
                    <ul class="social-list">
                        <li>
                            <a href="#">
                            <img src="assets/images/icons/fb-ico.svg" alt="">
                            </a>
                        </li>
                        <li>
                            <a href="#">
                            <img src="assets/images/icons/twitter-ico.svg" alt="">
                            </a>
                        </li>
                        <li>
                            <a href="#">
                            <img src="assets/images/icons/insta-ico.svg" alt="">
                            </a>
                        </li>
                        <li>
                            <a href="#">
                            <img src="assets/images/icons/linkedin-ico.svg" alt="">
                            </a>
                        </li>
                        <li>
                            <a href="#">
                            <img src="assets/images/icons/tiktok-ico.svg" alt="">
                            </a>
                        </li>
                        <li>
                            <a href="#">
                            <img src="assets/images/icons/snapchat-ico.svg" alt="">
                            </a>
                        </li>
                    </ul>
                    </div>
                </div>
                <div class="col-md-2">
                  <div class="foot-col">
                  <b>About</b>
                    <ul>
                        <li>
                            <a href="#">About</a>
                        </li>
                        <li>
                            <a href="#">FAQs</a>
                        </li>
                        <li>
                            <a href="./contact.php">Contact</a>
                        </li>
                    </ul>
                  </div>
                </div>
                <div class="col-md-2">
                    <div class="foot-col">
                    <b>Other</b>
                    <ul>
                        <li>
                            <a href="#">Terms & Conditions</a>
                        </li>
                        <li>
                            <a href="#">Privacy Policy</a>
                        </li>
                        <li>
                            <a href="#">Blog</a>
                        </li>
                    </ul>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="foot-col">
                        <b>Subscribe to our newsletter</b>
                        <div class="subscribe-pod">
                        <input type="text" placeholder="enter your email" class="subscribe-news">
                        <a href="#" class="theme-btn btn-black-theme">Subscribe</a>
                        </div>
                    </div>
                </div>
            </div>
                </div><!-- /.footer-cols-inner -->
           </div><!-- /.container -->
    </div><!-- /.footer-cols -->

    <div class="footer-bottom-strip">
            <div class="container-md">
                <div class="footer-bottom-strip-inner">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="strip-col">
                                    <p>© 2022 Slikk Limited. All rights reserved.</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="strip-col">
                                    <ul>
                                        <li>
                                            <a href="#">
                                            <img src="assets/images/icons/mastercard-pay.svg" alt="">

                                            </a>
                                        </li>

                                        <li>
                                            <a href="#">
                                            <img src="assets/images/icons/mastercard-pay.svg" alt="">

                                            </a>
                                        </li>

                                        <li>
                                            <a href="#">
                                            <img src="assets/images/icons/google-pay.svg" alt="">

                                            </a>
                                        </li>

                                        <li>
                                            <a href="#">
                                            <img src="assets/images/icons/apple-pay.svg" alt="">

                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                </div><!-- /.footer-bottom-strip-inner -->
            </div><!-- /.container -->
    </div><!-- /.footer-bottom-strip -->
</footer><!--/.footer__wrap-->

</div><!--/.site__wrapper-->

<script src="assets/js/jquery-3.5.1.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- <script src="//unpkg.com/swiper/swiper-bundle.min.js"></script> -->
<!-- <script src="assets/js/aos.min.js"></script> -->
<script src="assets/js/theme.js"></script>
</body>
</html>
