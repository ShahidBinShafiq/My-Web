<?php include 'incl/header.php'; ?>

    <main class="page__wrap">
    <div class="page-banner commercial-banner" style="background-image:url('assets/images/package-hero-image.jpg')">
    <div class="container-md">
        <div class="page-banner-inner">
        <div class="banner-title">
                <h1>Slikk Commercial Dry Cleaning service</h1>
                
            </div><!-- /.banner-title -->

        </div><!-- /.page-banner-inner -->
    </div><!-- /.container -->
    </div><!-- /.page-banner -->



    <div class="work-section package-work-section">
        <div class="container-sm">
            <div class="work-section-inner">
                    <div class="section-title center-text">
                            <h4>How it works?</h4>
                    </div><!-- /.section-title -->

                <div class="flow-cols">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="flow-col">
                              <figure>
                                <img src="assets/images/icons/home-ico1.svg" alt="">
                              </figure>
                              <figcaption>
                                <b>We collect</b>
                                <p>We collect your clothes from your premises on your selected date and time</p>
                              </figcaption>
                            </div><!-- /.flow-col -->
                        </div>

                        <div class="col-md-4">
                            <div class="flow-col">
                              <figure>
                                <img src="assets/images/icons/home-ico2.svg" alt="">
                              </figure>
                              <figcaption>
                                <b>We clean & iron</b>
                                <p>We clean your laundry in our state of the art machines and carefully iron them</p>
                              </figcaption>
                            </div><!-- /.flow-col -->
                        </div>


                        <div class="col-md-4">
                            <div class="flow-col">
                              <figure>
                                <img src="assets/images/icons/home-ico3.svg" alt="">
                              </figure>
                              <figcaption>
                                <b>We deliver</b>
                                <p>We deliver your clothes in our Zero-emission delivery vehicles</p>
                              </figcaption>
                            </div><!-- /.flow-col -->
                        </div>

                    </div>
                </div><!-- /.flow-cols -->
            </div><!-- /.work-section-inner -->
        </div><!-- /.container-sm -->
    </div><!-- /.worksection -->


    <div class="enquiry-section  bg-theme-lightblue">
        <div class="container-sm">
            <div class="enquiry-section-inner">
                <div class="section-title center-text">
                        <h4>Enquire about our commercial dry cleaning service</h4>
                </div><!-- /.section-title -->


                <div class="form-pod">
                    <form action="">
                      <div class="from-cols">
                          <div class="from-col">
                                <div class="mb-3">
                                  <input type="text" class="form-content"  placeholder="Your Name">
                                </div>
                            </div>

                            <div class="from-col">
                                <div class="mb-3">
                                  <input type="email" class="form-content"  placeholder="Your Email">
                                </div>
                          </div>


                          <div class="from-col">
                                <div class="mb-3">
                                  <input type="text" class="form-content"  placeholder="Contact Number">
                                </div>
                          </div>

                          <div class="from-col">
                                <div class="mb-3">
                                  <input type="text" class="form-content"  placeholder="Company">
                                </div>
                          </div>

                          <div class="from-col">
                                <div class="mb-3">
                                  <input type="text" class="form-content"  placeholder="Address">
                                </div>
                          </div>

                          <div class="from-col">
                                <div class="mb-3">
                                  <input type="text" class="form-content"  placeholder="Post Code">
                                </div>
                          </div>

                      </div><!-- /.form-cols -->

                      <div class="service-enquiry-area">
                        <p>Enquiring for</p>
                        <div class="enquiry-pods">

                      <div class="custom_radio">
                            <input type="radio" id="radioOne" name="enquiry" checked>
                            <label for="radioOne">
                            <figure>
                            <img src="assets/images/icons/dry-clng-ico.svg" alt="">
                            </figure>
                            Dry Cleaning
                            </label>
                          </div>

                          <div class="custom_radio">
                            <input type="radio" id="radioTwo" name="enquiry">
                            <label for="radioTwo">
                            <figure>
                            <img src="assets/images/icons/shoe-ico.svg" alt="">
                            </figure>
                            Shoe Cleaning
                            </label>
                          </div>


                        </div><!-- /.enquiry-pods -->
                        </div>



                      <div class="mb-3 address-pod">
                                  <textarea class="form-control" rows="5" placeholder="Address"></textarea>
                                  
                              </div>

                              <div class="message-btn">
                        <button type="submit" class="theme-btn btn-black-theme">Send Message</button>
                        </div>
                    </form>
                </div><!-- /.form-pod -->

               
            </div><!-- /.enquiry-section-inner -->
        </div><!-- /.container-sm -->
    </div><!-- /.enquiry-section -->

    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>