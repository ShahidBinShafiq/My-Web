<?php include 'incl/header.php'; ?>

    <main class="page__wrap">
    <div class="page-banner slikk-banner">
        <div class="page-banner-inner">
          <div class="row">
            <div class="col-md-5">
              <div class="banner-col col-left container-half">
              <div class="banner-title">
                <h1>Reinventing the future of laundry and dry cleaning</h1>
                <p>Slikk delivers the quickest, easiest to use, and most reliable professional laundry and dry cleaning service that completely adjusts to your needs.</p>
                
            </div><!-- /.banner-title -->
              </div>
            </div>
            <div class="col-md-7">

            <div class="banner-col col-right" style="background-image:url('assets/images/package-hero-image.jpg')">
                
          </div>
            </div>
          </div>

        </div><!-- /.page-banner-inner -->
    </div><!-- /.page-banner -->


    <div class="team-section">
        <div class="container">
          <div class="team-section-inner">
              <div class="section-title center-text">
                  <h4>Who we are</h4>
              </div><!-- /.section-title -->

            <div class="team-image">
                <figure>
                <img src="assets/images/team.jpg" alt="">
                </figure>
            </div><!-- /.team-image -->
            <div class="team-description center-text">
                <b>Founded in 2020 in London, Slikk is the next generation laundry & dry cleaning company. We offer professional laundry and dry cleaning delivered to your doorstep in as quick as 24 hours.</b>
                <p class="team-details">
                Since our beginnings in London, we have expanded globally to 11 countries. Our services are available in the following countries: Ireland, Netherlands, UAE, Bahrain, Singapore, Kuwait, United Kingdom, Qatar, Sweden, United States, and Denmark. Social and environmental sustainability is at the heart of what we do. We are building the largest fleet of electric delivery vehicles and are committed to reducing water, electricity consumption and the amount of packaging.
                </p>
                <p>
                Since our beginnings in London, we have expanded globally to 11 countries. Our services are available in the following countries: Ireland, Netherlands, UAE, Bahrain, Singapore, Kuwait, United Kingdom, Qatar, Sweden, United States, and Denmark. Social and environmental sustainability is at the heart of what we do. We are building the largest fleet of electric delivery vehicles and are committed to reducing water, electricity consumption and the amount of packaging.
                </p>
            </div><!-- /.team-description -->

          </div><!-- /.team-section-inner -->
        </div><!-- /.container-sm -->
    </div><!-- /.team-section -->

    <div class="brand-features-section bg-theme-lightblue">
        <div class="container">
            <div class="brand-features-inner">
              <div class="section-title center-text">
                  <h4>Why use Slikk?</h4>
              </div><!-- /.section-title -->

                <div class="feature-cols">
                <div class="row">
                  <div class="col-md-3">
                  <div class="feature-col center-text">

                              <figure>
                                <img src="assets/images/icons/abt-ico1.svg" alt="">
                              </figure>
                              <figcaption>
                                <b>Automatic Machines</b>
                                <p>We have one of the best and state of the art machines</p>
                              </figcaption>

                    </div><!-- /.feature-col -->
                  </div>

                  <div class="col-md-3">
                  <div class="feature-col center-text">

                              <figure>
                                <img src="assets/images/icons/abt-ico2.svg" alt="">
                              </figure>
                              <figcaption>
                                <b>Eco Friendly Products</b>
                                <p>We use high quality products to dry clean your clot</p>
                              </figcaption>
                              
                    </div><!-- /.feature-col -->
                  </div>

                  <div class="col-md-3">
                  <div class="feature-col center-text">

                              <figure>
                                <img src="assets/images/icons/abt-ico3.svg" alt="">
                              </figure>
                              <figcaption>
                                <b>Round the clock service</b>
                                <p>Our friendly team is always available whenever you need us</p>
                              </figcaption>
                              
                    </div><!-- /.feature-col -->
                  </div>

                  <div class="col-md-3">
                  <div class="feature-col center-text">

                              <figure>
                                <img src="assets/images/icons/abt-ico4.svg" alt="">
                              </figure>
                              <figcaption>
                                <b>Free pick-up and delivery</b>
                                <p>Yes we offer free pick-up and delivery on all our services</p>
                              </figcaption>
                              
                    </div><!-- /.feature-col -->
                  </div>
                </div>
                </div><!-- /.feature-cols -->
              
            </div><!-- /.brand-features-inner -->
        </div><!-- /.container -->
    </div><!-- /.brand-features-seciton -->
    



    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>