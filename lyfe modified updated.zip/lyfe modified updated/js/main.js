
$(document).ready(function(){

    $(".password-toggle").click(function () {

        let passbtn = $('.password-toggle').html();

        if(passbtn == "Show"){
            $('.password-toggle').html("Hide");
            $('#loginPass').attr('type','text');

        }else{
            $('.password-toggle').html("Show");
            $('#loginPass').attr('type','password');

        }
    });


});