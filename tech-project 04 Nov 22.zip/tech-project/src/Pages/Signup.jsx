import Header from "../components/Header"





const Signup = ()=> {
  return (
    <div>
        <Header/>
        Signup</div>
  )
}

export default Signup