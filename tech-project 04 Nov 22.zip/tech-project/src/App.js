import './App.css';
import Home from './Pages/Home';
import About from './Pages/About';
import Contact from './Pages/Contact';
import {BrowserRouter as Router, Routes, Route,} from "react-router-dom";
import Signin from './Pages/Signin';
import Signup from './Pages/Signup';
import Cart from './Pages/Cart';

function App() {
  return (
    <div className="App">
      
    <Router>
      <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/about" element={<About/>}/>
          <Route path="/contact" element={<Contact/>}/>
          <Route path="/signin" element={<Signin/>}/>
          <Route path="/signup" element={<Signup/>}/>
          <Route path="/cart" element={<Cart/>}/>
      </Routes>
    </Router>


    </div>
  );
}

export default App;
