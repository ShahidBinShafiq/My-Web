




const TechItemsList = ()=> {
  return (
    <div className="tech-list-wrap">
        <div className="container">
            <div className="tech-list-inner">
                <div className="section-title">
                    <h4 className="text-center py-5">Select Your Item for Repairing</h4>
                </div>
                <div className="row">

                    <div className="col-md-3">
                        <div className="tech-item-col">
                        <div class="card">
                            <img src="./images/hero-image.jpg" class="card-img-top" alt="..."/>
                            <div class="card-body">
                                <h5 class="card-title">Mobile Phone repair</h5>
                                <a href="#" class="btn btn-info mx-auto d-block text-white">Select Item</a>
                            </div>
                            </div>
                        </div>
                    </div>


                    <div className="col-md-3">
                        <div className="tech-item-col">
                        <div class="card">
                            <img src="./images/hero-image.jpg" class="card-img-top" alt="..."/>
                            <div class="card-body">
                                <h5 class="card-title">Mobile Phone repair</h5>
                                <a href="#" class="btn btn-info mx-auto d-block text-white">Select Item</a>
                            </div>
                            </div>
                        </div>
                    </div>


                    <div className="col-md-3">
                        <div className="tech-item-col">
                        <div class="card">
                            <img src="./images/hero-image.jpg" class="card-img-top" alt="..."/>
                            <div class="card-body">
                                <h5 class="card-title">Mobile Phone repair</h5>
                                <a href="#" class="btn btn-info mx-auto d-block text-white">Select Item</a>
                            </div>
                            </div>
                        </div>
                    </div>


                    <div className="col-md-3">
                        <div className="tech-item-col">
                        <div class="card">
                            <img src="./images/hero-image.jpg" class="card-img-top" alt="..."/>
                            <div class="card-body">
                                <h5 class="card-title">Mobile Phone repair</h5>
                                <a href="#" class="btn btn-info mx-auto d-block text-white">Select Item</a>
                            </div>
                            </div>
                        </div>
                    </div>
                   
                    
                </div>
            </div>
        </div>

    </div>
  )
}

export default TechItemsList