import {Link} from 'react-router-dom'


const  Logo = ()=> {

  return (

    <div>
     <Link to="/"> Tech</Link>
      </div>
      
  )

}

export default Logo