const swiper = new Swiper('.swiper', {
    // Optional parameters
    direction: 'horizontal',
    slidesPerView: 3,
    spaceBetween: 20,
    clickable: true,
    loop: true,

    // Navigation arrows
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },

});


let elTabBtn = document.querySelectorAll('[data-ctb-target]');
let elTabContent = document.querySelectorAll('.tab_content');

elTabBtn.forEach(function (el) {
    el.addEventListener('click', function (e) {
        let targetId = e.target.attributes['data-ctb-target'].value;
        elTabContent.forEach(function (el2) {
            el2.classList.remove('tc_active');
        });
        document.getElementById(targetId).classList.add('tc_active');
    });
});


elTabBtn.addEventListener('click', function (x) {
    x.classList.remove('active');
    this.classList.add('active');
});
