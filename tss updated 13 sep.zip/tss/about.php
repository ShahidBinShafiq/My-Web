<?php include 'incl/header.php'; ?>

    <main class="page__wrap">

        <main>
        <!-- <canvas id="canvas"> </canvas> -->
        <div class="about-page-wrap">
        <div class="container-md">
            <div class="about-page-inner">
            <div class="page-heading-title">
                <h4>A team of young and <br> <span class="tg-lineare">talented digital experts</span></h4>
                </div><!-- /.page-heading-title -->
                <div class="about-page-description">
                    <p>Web Buds is a team of young, talented and fast-growing digital experts specialising in modern website design and development and effective digital marketing and search engine optimization techniques.</p>
                    <p>We are based in the heart of London, inspired by the online creative community. We understand all the latest design and development trends.</p>
                    <p>Our team uses all the modern tools and provide detailed reports. Unlike others, our experts provide the services and also love educating our clients about the results and what they will be getting at the end.</p>
                    <p>Whether you need a stunning mobile responsive website or a high-performing digital marketing campaign? A website that loads quickly, engage visitors, and helps in your business growth?</p>
                    <p>Talk to us, and we will make it happen.</p>
                </div><!-- /.about-page-description -->
            </div><!-- /.about-page-inner -->
        </div><!-- /.container-md -->
        </div><!-- /.about-page-wrap -->


        </main>

    </main><!--/.page__wrap-->


    <!-- <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br> -->

<?php include 'incl/footer.php'; ?>

