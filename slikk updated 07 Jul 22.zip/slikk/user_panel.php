<?php include 'incl/header.php'; ?>

    <main class="page__wrap">

      <div class="order-section form-wizard" id="order-sec">
        <div class="order-steps">

            <div class="form-wizard-header">
               <div class="order-container">
               <div class="order-section-inner form-wizard-header-inner">
                    <div class="wizard-header-col order-col-left">
                    <ul class="list-unstyled form-wizard-steps clearfix">
                    <li data-title="Address" data-step="1" class="active">

                        <span>1</span>

                    </li>
                    <li data-title="Item Selection" data-step="2">
                        <span>2</span>
                    </li>
                    <li data-title="Collection & Delivery" data-step="3" data-steps="2">
                        <span>3</span>

                    </li>
                    <li data-title="Contact Details" data-step="4">
                        <span>4</span>
                    </li>
                </ul>
                    </div>
                <div class="wizard-header-col order-col-right">
                <div class="form-group clearfix">
                    <a href="javascript:;" class="form-wizard-previous-btn wizard-btn float-left"><
                        <span>Prev</span>
                    </a>
                    <a href="javascript:;" class="form-wizard-next-btn wizard-btn float-right">>
                    <span>Next</span>
                    </a>
                </div>
                </div>
                </div><!-- /.form-wizard-header-inner -->
               </div><!-- /.order-container -->
            </div><!-- /.form-wizard-header-inner -->



        </div><!-- /.order-steps -->
          <div class="order-container">
              <div class="order-section-inner">
                  <div class="order-col order-col-left">
                   

                  <div>
        <form action="" method="post" role="form">

            <fieldset class="wizard-fieldset show field-1">
                <div class="step-title">
                <h4>Address</h4>
                </div><!-- /.step-title -->
            <div class="address-pod">
            <div class="form-group">
                <label for="fname" class="wizard-form-text-label">PostCode</label>
                    <input type="text" class="form-control wizard-required" id="fname" placeholder="E13 9EJ">
                    <div class="wizard-form-error">
                        <!-- <span>this is required</span> -->
                    </div>
                </div>
                <div class="form-group">
                <label for="lname" class="wizard-form-text-label">Select Your Address</label>
                  <select id="inputState" class="form-select form-control wizard-required select-placeholder">
                    <option selected>Please select your address</option>
                    <option>Address Line One</option>
                  </select>
                    <div class="wizard-form-error"></div>
                </div>
                <!-- <div class="form-group">
                    Gender
                    <div class="wizard-form-radio">
                        <input name="radio-name" id="radio1" type="radio">
                        <label for="radio1">Male</label>
                    </div>
                    <div class="wizard-form-radio">
                        <input name="radio-name" id="radio2" type="radio">
                        <label for="radio2">Female</label>
                    </div>
                </div> -->
                <div class="form-group">

                    <label for="zcode" class="wizard-form-text-label">Address Line 2</label>
                    <input type="text" class="form-control wizard-required" id="zcode" placeholder="Please specify any extra address details">
                    <div class="wizard-form-error"></div>
                </div>
<!--                <div class="form-group clearfix">-->
<!--                    <a href="javascript:;" class="form-wizard-next-btn float-right">Next</a>-->
<!--                </div>-->
            </div><!-- /.address-pod -->
            </fieldset>	
            <fieldset class="wizard-fieldset field-2">
                <div class="items-pod">
                <div class="step-title">
                <h4>Select your items</h4>
                </div><!-- /.step-title -->
                <div class="items-slider">

                <div class="swiper">

                    <div class="swiper-wrapper">

                        <div class="swiper-slide">
                            <div>
                                <a href="javascript:void(0)" class="tb_nav-item active" data-ctb-target="tabOne">tab 1</a>
                            </div>
                        </div>

                        <div class="swiper-slide">
                            <div>
                                <a href="javascript:void(0)" class="tb_nav-item" data-ctb-target="tabTwo">tab 2</a>
                            </div>
                        </div>

                        <div class="swiper-slide">
                            <div>
                                <a href="javascript:void(0)" class="tb_nav-item" data-ctb-target="tabThree">tab 3</a>
                            </div>
                        </div>

                        <div class="swiper-slide">
                            <div>
                                <a href="javascript:void(0)" class="tb_nav-item" data-ctb-target="tabFour">tab 4</a>
                            </div>
                        </div>

                        <div class="swiper-slide">
                            <div>
                                <a href="javascript:void(0)" class="tb_nav-item" data-ctb-target="tabFive">tab 5</a>
                            </div>
                        </div>

                        <div class="swiper-slide">
                            <div>
                                <a href="javascript:void(0)" class="tb_nav-item" data-ctb-target="tabSix">tab 6</a>
                            </div>
                        </div>
                    </div>

                    <div class="swiper-button-prev"></div>
                    <div class="swiper-button-next"></div>

        </div><!--/.swiper-->



                    
                </div> <!-- /.items-slider -->
                </div><!-- /.item-pod -->

                
    <div class="tab_content-wrap">

<div class="tab_content tc_active" id="tabOne">
    <div class="tc-inner">
            <div class="row">
                    <div class="col-md-6">
                        <div class="svc-item">
                        <div class="svc-item-pod">
                           <div class="figure">
                                <figure>
                                    <picture>
                                        <img src="assets/images/svc-items/item1.png" alt="">
                                    </picture>
                                </figure>
                           </div><!-- /.figure -->
                           <div class="fig-caption">
                                <figcaption>
                                    <div class="item-title">
                                        <h4>Cardigan (P) <small>Cardigan (P)</small></h4>
                                        </div>
                                        <span class="svc-price">£2.00</span>
                                        <div class="item-select">
                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                        </div>
                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                </figcaption>
                           </div>

                        </div><!-- /.svc-item-pod -->
                        </div>
                    </div><!-- /.cold-md-6 -->
                    <div class="col-md-6">
                    <div class="svc-item">
                        <div class="svc-item-pod">
                           <div class="figure">
                                <figure>
                                    <picture>
                                        <img src="assets/images/svc-items/item1.png" alt="">
                                    </picture>
                                </figure>
                           </div><!-- /.figure -->
                           <div class="fig-caption">
                                <figcaption>
                                    <div class="item-title">
                                        <h4>Cardigan (P) <small>Cardigan (P)</small></h4>
                                        </div>
                                        <span class="svc-price">£2.00 <small></small></span>
                                        <div class="item-select">
                                            <a href="javascript:void(0)" class="item-increase">+</a>
                                            <a href="javascript:void(0)" class="item-decrease">-</a>
                                        </div>
                                        <p class="item-quantity">Quantity: <span>0</span></p>
                                </figcaption>
                           </div>

                        </div><!-- /.svc-item-pod -->
                        </div>
                    </div><!-- /.cold-md-6 -->
            </div><!-- /.row -->
    </div><!-- /.tc-inner -->
</div>

<div class="tab_content" id="tabTwo"><h1>Lorem ipsum dolor sit amet.</h1></div>

<div class="tab_content" id="tabThree">
    <h1>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius doloremque facere natus, suscipit aspernatur maiores modi quod blanditiis ad. Odio iste magnam voluptas rerum unde dicta atque doloremque explicabo possimus!</h1>


</div>

<div class="tab_content" id="tabFour"><h1>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ad, eius.</h1></div>

<div class="tab_content" id="tabFive"><h1>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nisi cupiditate voluptates itaque nihil veritatis rem aperiam facilis exercitationem voluptatum distinctio.</h1></div>

<div class="tab_content" id="tabSix"><h1>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Aspernatur enim officia ducimus dolores magnam, natus dignissimos, sed, voluptatibus quaerat commodi explicabo placeat! Error, repellat! Soluta, dolorem quae. Omnis sunt voluptate asperiores, eos necessitatibus fugit eaque porro nulla eius impedit, fugiat architecto? Voluptatibus dignissimos nemo dolore nesciunt nam officia maiores dolor.</h1></div>

</div><!--/.tab_content-wrap-->

                
            </fieldset>	

            <fieldset class="wizard-fieldset field-3">
                <h5>Field</h5>
                
            </fieldset>	

            <fieldset class="wizard-fieldset field-4">
                <h5>Bank Information</h5>
                <div class="form-group">
                    <input type="text" class="form-control wizard-required" id="bname">
                    <label for="bname" class="wizard-form-text-label">Bank Name*</label>
                    <div class="wizard-form-error"></div>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control wizard-required" id="brname">
                    <label for="brname" class="wizard-form-text-label">Branch Name*</label>
                    <div class="wizard-form-error"></div>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control wizard-required" id="acname">
                    <label for="acname" class="wizard-form-text-label">Account Name*</label>
                    <div class="wizard-form-error"></div>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control wizard-required" id="acon">
                    <label for="acon" class="wizard-form-text-label">Account Number*</label>
                    <div class="wizard-form-error"></div>
                </div>

            </fieldset>	
           
            <fieldset class="wizard-fieldset field-5">
                <h5>Payment Information</h5>
                <div class="form-group">
                    Payment Type
                    <div class="wizard-form-radio">
                        <input name="radio-name" id="mastercard" type="radio">
                        <label for="mastercard">Master Card</label>
                    </div>
                    <div class="wizard-form-radio">
                        <input name="radio-name" id="visacard" type="radio">
                        <label for="visacard">Visa Card</label>
                    </div>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control wizard-required" id="honame">
                    <label for="honame" class="wizard-form-text-label">Holder Name*</label>
                    <div class="wizard-form-error"></div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="form-group">
                            <input type="text" class="form-control wizard-required" id="cardname">
                            <label for="cardname" class="wizard-form-text-label">Card Number*</label>
                            <div class="wizard-form-error"></div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="form-group">
                            <input type="text" class="form-control wizard-required" id="cvc">
                            <label for="cvc" class="wizard-form-text-label">CVC*</label>
                            <div class="wizard-form-error"></div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">Expiry Date</div>
                    <div class="col-lg-4 col-md-4 col-sm-4">
                        <div class="form-group">
                            <select class="form-control">
                                <option value="">Date</option>
                                <option value="">1</option>
                                <option value="">2</option>
                                <option value="">3</option>
                                <option value="">4</option>
                                <option value="">5</option>
                                <option value="">6</option>
                                <option value="">7</option>
                                <option value="">8</option>
                                <option value="">9</option>
                                <option value="">10</option>
                                <option value="">11</option>
                                <option value="">12</option>
                                <option value="">13</option>
                                <option value="">14</option>
                                <option value="">15</option>
                                <option value="">16</option>
                                <option value="">17</option>
                                <option value="">18</option>
                                <option value="">19</option>
                                <option value="">20</option>
                                <option value="">21</option>
                                <option value="">22</option>
                                <option value="">23</option>
                                <option value="">24</option>
                                <option value="">25</option>
                                <option value="">26</option>
                                <option value="">27</option>
                                <option value="">28</option>
                                <option value="">29</option>
                                <option value="">30</option>
                                <option value="">31</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4">
                        <div class="form-group">
                            <select class="form-control">
                                <option value="">Month</option>
                                <option value="">jan</option>
                                <option value="">Feb</option>
                                <option value="">March</option>
                                <option value="">April</option>
                                <option value="">May</option>
                                <option value="">June</option>
                                <option value="">Jully</option>
                                <option value="">August</option>
                                <option value="">Sept</option>
                                <option value="">Oct</option>
                                <option value="">Nov</option>
                                <option value="">Dec</option>	
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4">
                        <div class="form-group">
                            <select class="form-control">
                                <option value="">Years</option>
                                <option value="">2019</option>
                                <option value="">2020</option>
                                <option value="">2021</option>
                                <option value="">2022</option>
                                <option value="">2023</option>
                                <option value="">2024</option>
                                <option value="">2025</option>
                                <option value="">2026</option>
                                <option value="">2027</option>
                                <option value="">2028</option>
                                <option value="">2029</option>
                                <option value="">2030</option>
                                <option value="">2031</option>
                                <option value="">2032</option>
                                <option value="">2033</option>
                                <option value="">2034</option>
                                <option value="">2035</option>
                                <option value="">2036</option>
                                <option value="">2037</option>
                                <option value="">2038</option>
                                <option value="">2039</option>
                                <option value="">2040</option>	
                            </select>
                        </div>
                    </div>
                </div>
<!--                <div class="form-group clearfix">-->
<!--                    <a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a>-->
<!--                    <a href="javascript:;" class="form-wizard-submit float-right">Submit</a>-->
<!--                </div>-->
            </fieldset>	
        </form>

    </div>







                  </div>
                  <div class="order-col order-col-right" id="order-details">

                                <div class="step-title">
                                <h4>Order Summary</h4>
                                </div><!-- /.step-title -->

                                <div class="items-ordered-list">
                                <ul>
                            <li class="step-details" data-step="1">
                                <div class="custom-checkbox">
                                    <input type="checkbox" value="Address" checked>
                                    <label>Address</label>
                                </div><!-- /.custom-chekbox -->
                                <ul class="address-lines order-info">
                                    <li>4B Samson Street, London</li>
                                    <li></li>
                                </ul>
                            </li>
                            <li class="step-details" data-step="2">
                                <div class="custom-checkbox">
                                    <input type="checkbox" value="Item Selection" checked>
                                    <label>Item Selection</label>
                                    <ul class="order-info">
                                        <li>
                                            <span class="selected-item item-name">
                                                6 Kg Wash dry & fold
                                            </span>
                                            <span class="selected-item item-quantity">
                                                1
                                            </span>
                                            <span class="selected-item item-price">
                                                £16.00
                                            </span>
                                        </li>
                                        <li>
                                            <span class="selected-item item-name">
                                                T Shirt (P)
                                            </span>
                                            <span class="selected-item item-quantity">
                                                4
                                            </span>
                                            <span class="selected-item item-price">
                                                £8.00
                                            </span>
                                        </li>
                                        <li>
                                            <span class="selected-item item-name">
                                                Shirt/TShirt Fold (P)
                                            </span>
                                            <span class="selected-item item-quantity">
                                                2
                                            </span>
                                            <span class="selected-item item-price">
                                                £2.50
                                            </span>
                                        </li>
                                        <li>
                                            <span class="selected-item item-name">
                                                Shirt/TShirt Fold (P)
                                            </span>
                                            <span class="selected-item item-quantity">
                                                4
                                            </span>
                                            <span class="selected-item item-price">
                                                £8.00
                                            </span>
                                        </li>
                                        <li>
                                            <span class="selected-item item-name">
                                                Jacket (P)                                            </span>
                                            <span class="selected-item item-quantity">
                                                2
                                            </span>
                                            <span class="selected-item item-price">
                                                £16.00
                                            </span>
                                        </li>
                                        <li>
                                            <span class="selected-item item-name">
                                                6 Kg Wash dry & fold
                                            </span>
                                            <span class="selected-item item-quantity">
                                                1
                                            </span>
                                            <span class="selected-item item-price">
                                                £16.00
                                            </span>
                                        </li>
                                        <li>
                                            <span class="selected-item item-name">
                                                Evening Dress (P)
                                            </span>
                                            <span class="selected-item item-quantity">
                                                4
                                            </span>
                                            <span class="selected-item item-price">
                                                £8.00
                                            </span>
                                        </li>
                                        <li>
                                            <span class="selected-item item-name">
                                                Dress (P)
                                            </span>
                                            <span class="selected-item item-quantity">
                                                1
                                            </span>
                                            <span class="selected-item item-price">
                                                £2.50
                                            </span>
                                        </li>
                                        <li>
                                            <span class="selected-item item-name">
                                                Skirt (P)
                                            </span>
                                            <span class="selected-item item-quantity">
                                                3
                                            </span>
                                            <span class="selected-item item-price">
                                                £8.00
                                            </span>
                                        </li>
                                    </ul>
                                </div><!-- /.custom-chekbox -->
                            </li>
                            <li class="step-details" data-step="3">
                                <div class="custom-checkbox">
                                    <input type="checkbox" value="Collection & Delivery" checked>
                                    <label>Collection & Delivery</label>
                                    <ul class="services-list">
                                        <li class="item-services"><span>Collection: <b>Fri, 24 Jun 11:00-13:00</b></span></li>
                                        <li class="item-services"><span>Delivery: <b>Mon, 27 Jun 15:00-17:00</b></span></li>
                                    </ul>
                                </div><!-- /.custom-chekbox -->
                            </li>

                            <li class="step-details" data-step="4">
                                <div class="custom-checkbox">
                                    <input type="checkbox" value="Contact Details" checked>
                                    <label>Contact Details</label>
                                    <ul class="user-info">
                                        <li class="user-data"><span>Name: <b>John Doe</b></span></li>
                                        <li class="user-data"><span>Email: <b>johndoe@gmail.com</b></span></li>
                                        <li class="user-data"><span>Phone: <b>+4433692558</b></span></li>
                                    </ul>
                                </div><!-- /.custom-chekbox -->
                            </li>
                        </ul>
                        <ul class="order-values-list">
                            <li class="value-item value-item-1"><span>Minimum Order Value £20.00 </span></li>
                            <li class="value-item value-item-2"><span>Services Total </span> <b>£140.73</b></li>
                            <li class="value-item value-item-3"><span>Grand Total </span> <b>£20.00</b></li>
                        </ul>

                        <div class="discount-pod">
                        <input type="text" placeholder="Discount or referral code" class="form-control promo-code">
                        <button type="button" class="theme-btn btn-black-theme apply-btn">Apply</button>
                        </div>
                                </div><!-- /.items-orderd-list -->

                </div>
              </div><!-- /.order-section-inner -->
          </div><!-- /.order-container -->
      </div><!-- /.order-section -->
    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>