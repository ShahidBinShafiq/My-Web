<footer class="footer__wrap">

    <div class="site-footer section-space-top">
    <div class="container-lg">
    <div class="footer-inner">
        <div class="row">
            <div class="col-md-5">
                <div class="foot-col">
                    <div class="foot-col-title">
                        <img src="./assets/images/brand-logo-foot.svg" alt="">
                    </div>

                    <div class="foot-contacts-pod">
                        <span>0203 876 6726</span>
                        <span>enquiries@thesitespace.com</span>
                    </div><!-- /.foot-contacts-pod -->

                    <div class="social-links-foot">
                        <ul>
                            <li><a href="#"><i class="icon-instagram"></i></a></li>
                            <li><a href="#"><i class="icon-linked-in"></i></a></li>
                            <li><a href="#"><i class="icon-twitter"></i></a></li>
                            <li><a href="#"><i class="icon-facebook"></i></a></li>
                        </ul>
                    </div><!-- /.social-links-foot -->

                    <div class="call-booking-pod">
                        <b>Book A Call Back</b>
                        <small>HI, I am Kashi Shabbir and I would love to discuss your project.</small>
                        <a href="#"> <i class="icon-phone"></i>Let's Start</a>
                    </div><!-- /.call-booking-pod -->



                </div><!-- /.foot-col -->
                
            </div>
            <div class="col-md-5">
            <div class="foot-col">
                    <div class="foot-col-title">
                        <h4>Book A Free Consultation</h4>
                    </div>
                    <div class="cunsultation-form">
                        <form action="">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="floatingInput" placeholder="Name">
                            <label for="floatingInput">Name</label>
                            </div>
                            <div class="form-floating">
                            <input type="email" class="form-control" id="floatingPassword" placeholder="Email">
                            <label for="floatingPassword">Email</label>
                            </div>
                            <div class="form-floating">
                            <input type="text" class="form-control" id="floatingInput" placeholder="Name">
                            <label for="floatingInput">Contact number</label>
                            </div>
                            <div class="form-floating">
                            <input type="text" class="form-control" id="floatingInput" placeholder="Name">
                            <label for="floatingInput">Business name</label>
                            </div>
                            <button class="foot-form-btn-submit" type="submit">Submit <i class="icon-arrow-fill-right"></i></button>
                        </form>
                    </div><!-- /.cunsultation-form -->
                </div><!-- /.foot-col -->
            </div>
            <div class="col-md-2">
            <div class="foot-col">
                    <div class="foot-col-title">
                        <h4>Quick Links</h4>
                    </div>

                    <div class="foot-quick-links">
                        <ul>
                            <li>
                                <a href="index.php">Home</a>
                            </li>
                            <li>
                                <a href="about.php">About Us</a>
                            </li>
                            <li>
                                <a href="contact.php">Contact Us</a>
                            </li>
                            <li>
                                <a href="blog.php">Blogs</a>
                            </li>
                            <li>
                                <a href="#">Terms &  Conditions</a>
                            </li>
                            <li>
                                <a href="#">Privacy Policy</a>
                            </li>
                        </ul>
                    </div><!-- /.foot-quick-links -->


                </div><!-- /.foot-col -->
            </div>
        </div>

        <div class="foot-bottom-strip">
            <p>© 2022 Web Buds Ltd. Registered In England And Wales Under Company Number: 11607956.</p>
        </div><!-- /.foot-bottom-strip -->

        <!-- <br><br><br><br><br> -->
    </div><!-- /.footer-inner -->
</div><!-- /.contaiener-lg -->
    </div><!-- /.site-footer -->
      
</footer><!--/.footer__wrap-->

</div><!--/.site__wrapper-->

<script src="assets/js/jquery-3.5.1.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/dat-gui/0.6.2/dat.gui.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/7.4.1/swiper-bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.10.4/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.10.4/ScrollTrigger.min.js"></script>
<script src="assets/js/theme.js"></script>

<script>
  



    </script>
</body>
</html>
