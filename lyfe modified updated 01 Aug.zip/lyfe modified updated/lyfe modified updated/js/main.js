
$(document).ready(function(){

    $(".password-toggle").click(function () {

        let passbtn = $('.password-toggle').html();

        if(passbtn == "Show"){
            $('.password-toggle').html("Hide");
            $('#loginPass').attr('type','text');

        }else{
            $('.password-toggle').html("Show");
            $('#loginPass').attr('type','password');

        }
    });


    $(".c-password-toggle").click(function () {

        let passbtn = $('.c-password-toggle').html();

        if(passbtn == "Show"){
            $('.c-password-toggle').html("Hide");
            $('#confirmPass').attr('type','text');

        }else{
            $('.c-password-toggle').html("Show");
            $('#confirmPass').attr('type','password');

        }
    });

        $("#mega-nav-item1").hover(function(){
            $("#mega-nav").slideToggle(800);
         });

         $("#mega-nav-item2").hover(function(){
            $("#mega-nav2").slideToggle(800);
         });
    


     
     
     
    });

    var numInput;
var number = 0;
var numberInput = 0;

$(".increment").on("click",function(){
  numInput = $(this).parent(".buttons").siblings("input");
  number = parseInt($(numInput).val());
  if (isNaN(number)){
    number = 0;
  }
  $(numInput).val(parseInt(number)+1);
  numInput = null; number = 0; numInput = 0;
});

$(".decrement").on("click",function(){
  numInput = $(this).parent(".buttons").siblings("input");
  number = parseInt($(numInput).val());

  if ( (isNaN(number) ) || (number < 0) ) {
    number = 0;
    $(numInput).val(number);
  } else if ($(numInput).val() > 0) {
    $(numInput).val(parseInt(number)-1);
  }
  numInput = null; number = 0; numInput = 0;
});