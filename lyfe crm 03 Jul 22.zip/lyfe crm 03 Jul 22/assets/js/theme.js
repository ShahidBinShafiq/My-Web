$(document).ready(function(){

  $(".password-toggle").click(function () {

    let passbtn = $('.password-toggle').html();

if(passbtn == "Show"){
 $('.password-toggle').html("Hide");
 console.log(passbtn)


}else{
  $('.password-toggle').html("Show");

}


});


$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
  var target = this.href.split('#');
  $('.nav a').filter('[href="#'+target[1]+'"]').tab('show');
})



  });