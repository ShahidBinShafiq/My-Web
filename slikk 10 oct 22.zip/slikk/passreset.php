<?php include 'incl/header.php'; ?>

    <main class="page__wrap">
        <div class="login-wrapper">
            <div class="login-inner">
                <div class="login-title">
                  <h1>Reset your password</h1>
                </div>

                <div class="login-pods">
                  <form action="">
               
                  <div class="fieldwd-icon mb-3">
                  <input type="password" class="form-control form-password-field"  placeholder="Password*">
                  <i class="icon-eye-view form-field-icon toggle-password"></i>
                  </div><!-- /.fieldwd-icon -->
              
                  <div class="fieldwd-icon mb-3">
                  <input type="password" class="form-control form-password-field"  placeholder="Re-enter Password*">
                  <i class="icon-eye-view form-field-icon toggle-password"></i>
                  </div><!-- /.fieldwd-icon -->
              

                </div><!-- /.login-credentials -->
                  <div class="login-footer">
                      <div class="login-btns">
                        <button type="submit" class="theme-btn btn-black-theme login-btn">Save</button>
                      </div>
                  </div><!-- /.login-footer -->
                  </form>
                </div>


            </div><!-- /.login-inner -->
        </div><!-- /.login-wrapper -->

    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>