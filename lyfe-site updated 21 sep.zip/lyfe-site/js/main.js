
$(document).ready(function(){

    $(".password-toggle").click(function () {

        let passbtn = $('.password-toggle').html();

        if(passbtn == "Show"){
            $('.password-toggle').html("Hide");
            $('#loginPass').attr('type','text');

        }else{
            $('.password-toggle').html("Show");
            $('#loginPass').attr('type','password');

        }
    });


    $(".c-password-toggle").click(function () {

        let passbtn = $('.c-password-toggle').html();

        if(passbtn == "Show"){
            $('.c-password-toggle').html("Hide");
            $('#confirmPass').attr('type','text');

        }else{
            $('.c-password-toggle').html("Show");
            $('#confirmPass').attr('type','password');

        }
    });

        $("#mega-nav-item1").hover(function(){
            $("#mega-nav").slideToggle(400);
         });

         $("#mega-nav-item2").hover(function(){
            $("#mega-nav2").slideToggle(400);
         });
    

         $('.owl-carousel').owlCarousel({
          loop:false,
          margin:10,
          nav:true,
          dots: false,
          mouseDrag: false,
          responsive:{
              0:{
                  items:1
              },
              600:{
                  items:1
              },
              1000:{
                  items:1
              }
          }
      })



    //   checkout stages
    $("#new-delivery-address").hide();
    $("#manual-delivery-address").hide();
      $("#new-billing-address").hide();
     
      $("#c-out-new-address").hide();

      $("#cOut-new-addressBtn").click(function(){
        $("#c-out-delivery-address").hide();
        $("#c-out-new-address").show();

      });


      $("#c-out-manual-address").hide();

      $("#cOut-manual-addressBtn").click(function(){
        $("#c-out-new-address").hide();
        $("#c-out-manual-address").show();

      });




      $("#c-out-step2").hide();

      $("#c-out-next1").click(function(){
        $("#c-out-step2").show();
        $("#c-out-next1").hide();

      });


      $("#c-out-step3").hide();

      $("#enter-othr-adrs").click(function(){
        $("#c-out-step3").show();
        $("#billing-address-pod").hide();
        $("#new-billing-adrs").show();
        $("#payment-pods").hide();

      });


      $("#use-delivery-address").click(function(){
        $("#billing-address-pod").show();
        $("#new-billing-adrs").hide();
        // $("#c-out-next3").hide();
        $("#c-out-step3").show();

      });




      $("#c-out-step4").hide();

      $("#c-out-next3").click(function(){
        $("#c-out-step3").hide();
        $("#billing-address-pod").hide();
        $("#c-out-step4").show();

      });




      $("#paypal-pay").click(function(){
        $("#card-pay").hide();

      });


      $("#credit-card-pay").click(function(){
        $("#card-pay").show();

      });

      $("#payment-pods").click(function(){
        $("#c-out-step4").show();
        $("#c-out-step2").hide();

      });







      // text fields number validation

      // Only allow number keys + number pad

$('input[name="num-field"]').keypress
(
    function(event)
    {
        if (event.keyCode == 46 || event.keyCode == 8)
        {
        //do nothing
        }
        else 
        {
            if (event.keyCode < 48 || event.keyCode > 57 ) 
            {
			    event.preventDefault();	
			}	
        }
    }
);








     
     
     
    });

    var numInput;
var number = 0;
var numberInput = 0;

$(".increment").on("click",function(){
  numInput = $(this).parent(".control-buttons").siblings("input");
  number = parseInt($(numInput).val());
  if (isNaN(number)){
    number = 0;
  }
  $(numInput).val(parseInt(number)+1);
  numInput = null; number = 0; numInput = 0;
});

$(".decrement").on("click",function(){
  numInput = $(this).parent(".control-buttons").siblings("input");
  number = parseInt($(numInput).val());

  if ( (isNaN(number) ) || (number < 0) ) {
    number = 0;
    $(numInput).val(number);
  } else if ($(numInput).val() > 0) {
    $(numInput).val(parseInt(number)-1);
  }
  numInput = null; number = 0; numInput = 0;
});




// checkout-page validation

// function formValidation() {
//     const submitButton = document.querySelector(".form-submit");
//     submitButton.addEventListener("click", function () {
//       validateFormonSubmit();
//     });
//     validateForm();
//   }
//   function inputValidate(target, input) {
//     const parent = target.parentElement;
//     const value = target.value;
//     const inputClasses = Array.from(input.classList);
//     const isRequired = inputClasses.find(function (cls) {
//       return cls === "field-required";
//     });
//     if (isRequired) {
//       if (value == "") {
//         parent.classList.add("error");
//       } else {
//         parent.classList.remove("error");
//         $("#c-out-next1").click(function(){
//           $(this).hide();
//           $("#c-out-step2").show();
  
//         });
//       }
//     }
//   }
//   function validateForm(params) {
//     const formPod = document.querySelector(".form-pod");
//     const inputs = formPod.getElementsByClassName("form-control");
//     if (inputs) {
//       const inputFields = Array.from(inputs);
//       inputFields.forEach(function (input) {
//         input.addEventListener("input", function (e) {
//           inputValidate(e.target, input);
//         });
//         input.addEventListener("blur", function (e) {
//           inputValidate(e.target, input);
//         });
//       });
//     }
//   }
//   function validateFormonSubmit(params) {
//     const formPod = document.querySelector(".form-pod");
//     const inputs = formPod.getElementsByClassName("form-control");
//     if (inputs) {
//       const inputFields = Array.from(inputs);
//       inputFields.forEach(function (input) {
//         inputValidate(input, input);
//       });
//     }
//   }
//   formValidation();