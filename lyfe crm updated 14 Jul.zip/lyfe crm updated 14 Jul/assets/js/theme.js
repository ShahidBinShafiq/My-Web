$(document).ready(function(){

  $(".password-toggle").click(function () {

    let passbtn = $('.password-toggle').html();

if(passbtn == "Show"){
 $('.password-toggle').html("Hide");
 $('#loginPass').attr('type','text');

}else{
  $('.password-toggle').html("Show");
  $('#loginPass').attr('type','password');

}
});




$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
  var target = this.href.split('#');
  const parentElement = $('#crm-tabs-content .tab-pane.active')
 parentElement.find('a.active').removeClass('active')

  $('.nav a').filter('[href="#'+target[1]+'"]').tab('show');
})


  var myMaxLength = 200, // textarea maxlength, set it to whatever you want
    myAlertTheshold = 95, // the threshold where the ARIA alert will start firing, don't set it too low
    maximum = $('#maximum'), // the maximum character count SPAN
    characterCounter = $('#characterCounter'),
    characterCountStart = 0; //the current character count

  /* initialise the character count area */
  $('#the-textarea').attr('maxlength', myMaxLength);
  $('#characterCounter').text(characterCountStart);
  $('#characterCounterDetails').text(myMaxLength);
  $('#maximum').text(myMaxLength);

  /* respond to each keydown by incrementing or decrementing the current character count */
  $('textarea').keydown(function() {

    var characterCount = $(this).val().length,
      charactersRemaining = 0;

    charactersRemaining = characterCountStart + characterCount;
    characterCounter.text(charactersRemaining);
    /* once characters entered reaches the predefined threshold, create a new aria-alert 
      	element so the screen reader receives the alert */

    /* creates the new element for each character up to the final one, so an alert happens for each keypress */

    if (characterCount > myAlertTheshold) {
      var newAlert = document.createElement("div"); /* using the native js because it's faster */
      newAlert.setAttribute("role", "alert");
      newAlert.setAttribute("id", "alert");
      newAlert.setAttribute("class", "sr-only");
      var msg = document.createTextNode(charactersRemaining + ' /' + myMaxLength);
      newAlert.appendChild(msg);
      document.body.appendChild(newAlert);
    }
  });








  });




  // $("#accordion1").on("hide.bs.collapse show.bs.collapse", e => {
  //   $(e.target)
  //     .prev()
  //     .find("i:last-child")
  //     .toggleClass("icon-plus-circle icon-minus-circle");
  // });