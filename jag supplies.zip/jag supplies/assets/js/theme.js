// side-bar-collapes



let sideToggleBtn = document.getElementById('sidebar-toggle');
let mainContent = document.getElementById('main');
let sideBar = document.getElementById('jagSidebar');

sideToggleBtn.addEventListener('click', function(){
    sideBar.classList.toggle('slide-toggle')
    mainContent.classList.toggle('main-content-padding')
})

// add active class to 

$(document).ready(function(){
    $('.copm-item').click(function(){
      $('.copm-item').removeClass("active");
      $(this).addClass("active");
  });
  formValidation();

});



// form validation

function formValidation() {

  const submitButton = document.querySelector(".form-submit");
  if(submitButton){
    submitButton.addEventListener("click", function () {
      validateFormonSubmit();
    });
  }

  validateForm();
}
function inputValidate(target, input) {
  const parent = target.parentElement;
  const value = target.value;
  const inputClasses = Array.from(input.classList);
  const isRequired = inputClasses.find(function (cls) {
    return cls === "field-required";
  });
  if (isRequired) {
    if (value == "") {
      parent.classList.add("error");
    } else {
      parent.classList.remove("error");
    }
  }
}
function validateForm(params) {
  const formPod = document.querySelector(".form-pod");
  if(formPod){
    const inputs = formPod.getElementsByClassName("form-control");
    if (inputs) {
      const inputFields = Array.from(inputs);
      inputFields.forEach(function (input) {
        input.addEventListener("input", function (e) {
          inputValidate(e.target, input);
        });
        input.addEventListener("blur", function (e) {
          inputValidate(e.target, input);
        });
      });
    }
  }

}
function validateFormonSubmit(params) {
  const formPod = document.querySelector(".form-pod");
  if(formPod){
    const inputs = formPod.getElementsByClassName("form-control");
    if (inputs) {
      const inputFields = Array.from(inputs);
      inputFields.forEach(function (input) {
        inputValidate(input, input);
      });
    }
  }

}


// accordions

$("#accordion1").on("hide.bs.collapse show.bs.collapse", e => {
  console.log(e.target)
  $(e.target)
  
  .prev()
  .find("i:last-child")
  .toggleClass("icon-plus icon-minus");
});




// custom calendar




// img Upload


const getImageDimension = (file) => {
  return new Promise((resolve, reject) => {
    //   if (!attrAccept({ name: file.name, type: file.type }, 'image/*')) {
    //     return resolve(file);
    //   }
    //   if (attrAccept({ name: file.name, type: file.type }, 'audio/*')) {
    //     return resolve(file);
    //   }

    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const image = new Image();
      image.src = event.target.result;
      image.onload = () => {
        Object.defineProperty(file, "width", {
          value: image.width,
          writable: false,
        });
        Object.defineProperty(file, "height", {
          value: image.height,
          writable: false,
        });
        resolve({ file, src: event.target.result });
      };
      reader.onerror = (err) => reject(err);
    };
  });
};

$("#upload-cv").change(function (e) {
  const fls = Array.from(e.target.files).concat(window.filestoupload || []);
  var empty = "";
  $("#upload-cv").val(empty);
  const maxFilesToupload = e.target.dataset?.maxfiles || 9999999;
  const isPreview = e.target.dataset?.preview !== "false";
  if (fls?.length > Number(maxFilesToupload)) {
    $("#input-msg")
      .addClass("error")
      .html(`Max Files upload limit is ${maxFilesToupload}`);
    return;
  }
  const files = fls.map((f, index) => {
    const uuid = new Date().getTime();
    if (f.id) {
      return { ...f, id: uuid + index };
    }
    return { file: f, id: uuid + index };
  });
  const updatedFiles = files;
  let isError = false;
  const errorFiles = [];
  files.forEach(function (f, index) {
    const file = f.file;
    var fileType = file.type;
    var fileSize = file.size;

    if (
      fileType != "image/png" &&
      fileType != "image/jpeg" &&
      fileType != "application/msword" &&
      fileType != "application/pdf" &&
      fileSize <= 102400
    ) {
      $("#input-msg").addClass("error").html("Please choose a valid file");
      $("#upload-cv").val(empty);
      f.errorMessage = "Please choose a valid file";
      updatedFiles.splice(index, 1);
      errorFiles.push(f);
      isError = true;
      // $('#uploaded-image').hide();
    } else if (fileSize > 102400) {
      f.errorMessage = "Maximum filesize should be less than 1mb";
      updatedFiles.splice(index, 1);
      errorFiles.push(f);

      $("#upload-cv").val(empty);
      isError = true;
      // $('#uploaded-image').hide();
    } else {
      isError = false;
      $("#upload-cv").val(empty);
      // $('.container').add('img').attr('src', file.name);
    }
    f.isError = isError;
  });
  window.filestoupload = updatedFiles;
  if (!errorFiles?.length) {
    $("#input-msg").removeClass("error").addClass("success");
    const errorselector = document.querySelector(".error-list");
    if (errorselector) {
      errorselector.remove();
    }
  } else {
    uploadErrorList(errorFiles, isPreview);
  }
  // if (!isError) {
  previewImages(updatedFiles, isPreview);
  // }
});

function previewImages(files = [], isPreview = true) {
  const containerId = "imgswrapper";
  const imgContinaer = document.getElementById(`${containerId}`);
  const prevImageList = imgContinaer.querySelector(".imglist");

  if(prevImageList){
    prevImageList.remove();
  }
  const imglist = document.createElement("ul");

  imglist.setAttribute("class", `imglist`);
  files.forEach(function (f) {
    if (isPreview) {
      getImageDimension(f.file).then((data) => {
        const img = document.createElement("img");
        img.setAttribute("src", data.src);
        // img.setAttribute("height", "100px");
        // img.setAttribute("width", "100px");
        appendtoList(f, imglist, imgContinaer, img);
      });
    } else {
      appendtoList(f, imglist, imgContinaer);
    }
  });
}

function uploadErrorList(files = []) {
  const containerId = "imgswrapper";
  const imgContinaer = document.getElementById(`${containerId}`);
  const prevImageList = imgContinaer.querySelector(".error-list");

  if(prevImageList){
    prevImageList.remove();
  }
  const errorlist = document.createElement("ul");
  errorlist.setAttribute("class", "error-list");
  files.forEach((f) => {
    const errorlistItem = document.createElement("li");
    const errorMessage = document.createElement("span");
    errorMessage.innerHTML = f.errorMessage;
    const fileName = document.createElement("p");
    fileName.innerHTML = f.file.name;
    errorlistItem.appendChild(fileName);
    errorlistItem.appendChild(errorMessage);
    errorlist.appendChild(errorlistItem);
  });

  // $("#input-msg").addClass("error").html(errorlist);
  imgContinaer.prepend(errorlist)
}
function appendtoList(file, imglist, imgContinaer, imgElement) {
  const imglistItem = document.createElement("li");

  // const imgitemcaption = document.createElement("label");
  // imgitemcaption.innerHTML = file.file.name;
  const dltImage = document.createElement("button");
  dltImage.classList.add('img-close')
  imglistItem.setAttribute("class", `imglistitem ${file.id}`);

  // imglistItem.appendChild(imgitemcaption);
  if (imgElement) {
    imglistItem.appendChild(imgElement);
  }
  imglistItem.appendChild(dltImage);
  imglist.appendChild(imglistItem);
  imgContinaer.appendChild(imglist);
  dltImage.addEventListener("click", function (e) {
    e.preventDefault();
    e.stopPropagation();
    imglist.removeChild(imglistItem);
    const newFilesToUpload = [];
    window.filestoupload.forEach(function (f) {
      if (f.id !== file.id) {
        newFilesToUpload.push(f);
      }
    });
    window.filestoupload = newFilesToUpload;
  });
}



// Tooltip

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})

// padding top

let topStrip = document.getElementById("main_top-strip");
let pgContent = document.getElementById('page-content');
let jagSidebar = document.getElementById('jagSidebar');
pgContent.style.paddingTop = topStrip.offsetHeight + "px";
jagSidebar.style.paddingTop = topStrip.offsetHeight + "px";
window.addEventListener('resize', function(){
   console.log(topStrip.offsetHeight)
   pgContent.style.paddingTop = topStrip.offsetHeight + "px";
   jagSidebar.style.paddingTop = topStrip.offsetHeight + "px";
})


