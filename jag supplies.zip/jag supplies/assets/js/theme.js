// side-bar-collapes

let sideToggleBtn = document.getElementById('sidebar-toggle');
let mainContent = document.getElementById('main');
let sideBar = document.getElementById('jagSidebar');

sideToggleBtn.addEventListener('click', function(){
    sideBar.classList.toggle('slide-toggle')
    mainContent.classList.toggle('main-content-padding')
})

// add active class to 

$(document).ready(function(){
    $('.copm-item').click(function(){
      $('.copm-item').removeClass("active");
      $(this).addClass("active");
  });
  });