import Banner from "../components/Banner"
import Header from "../components/Header"






const About =()=> {
  
  return (
    <div>
        <Header/>
        <Banner/>
        About
        </div>
  )

}

export default About