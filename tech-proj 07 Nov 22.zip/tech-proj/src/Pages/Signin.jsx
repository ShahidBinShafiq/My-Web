import Header from "../components/Header"






const Signin = ()=> {
  return (
    <div>
        <Header/>

        <div className="signin-wrapper">
          <div className="container-sm">
            <div className="signin-inner">
            <form>
              <div className="mb-3">
                <label for="exampleInputEmail1" class="form-label">Enter Your Email</label>
                <input type="email" className="form-control" aria-describedby="emailHelp" placeholder="Enter Email"/>
              </div>
              <div className="mb-3">
                <label class="form-label">Enter Your Password</label>
                <input type="password" className="form-control" placeholder="Enter Password"/>
              </div>
           
              <button type="submit" className="btn btn-primary w-100">Sign In</button>
            </form>
            </div>
          </div>
        </div>
        
        </div>
  )
}

export default Signin