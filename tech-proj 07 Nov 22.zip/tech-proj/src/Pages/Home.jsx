import Banner from "../components/Banner"
import Header from "../components/Header"
import TechItemsList from "../components/TechItemsList"





const Home = ()=> {
  return (
    <div className="page-wrapper">
        <Header/>
        <Banner/>
        <TechItemsList/>
        This is Home Page
    </div>
  )
}

export default Home