import {Link} from 'react-router-dom'


const  Logo = ()=> {

  return (

    <div className='brand-logo-wrap'>
     <Link to="/" className='brand-logo'> Tech Specialist</Link>
      </div>
      
  )

}

export default Logo