
import { useState } from "react"
import {Link } from 'react-router-dom'


const Navbar = ()=> {



  return (
    <div className="nav-wrap">
        <div className="nav-inner">
        <ul>
            <li>
               <Link to='/' className="nav-link-item"> Home</Link>
            </li>
            <li>
            <Link to='/about' className="nav-link-item">  About Us</Link>
               
            </li>
            <li>
            <Link to='/contact' className="nav-link-item">  Contact Us</Link>
            </li>
            <li>
            <Link to='/signin' className="site-btn">  Sign In</Link>

            </li>
            <li>
            <Link to='/signup' className="site-btn">  Sign Up</Link>

            </li>
            <li>
            <Link to='/cart' className="site-btn">  Cart</Link>

            </li>
        </ul>
        </div>
       
    </div>
  )
}

export default Navbar