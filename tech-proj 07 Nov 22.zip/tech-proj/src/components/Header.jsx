import Logo from "./Logo"
import Navbar from "./Navbar"





const Header = ()=> {
  return (
    <div className="header-wrapper">
        <div className="container">
       <div className="header-inner">
            <Logo/>
            <Navbar/>
       </div>
        </div>
    </div>
  )
}

export default Header