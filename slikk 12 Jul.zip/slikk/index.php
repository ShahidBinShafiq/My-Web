<?php include 'incl/header.php'; ?>

    <main class="page__wrap">
        <div class="home-page-banner">
        <div class="page-banner">
    <div class="container-md">
        <div class="page-banner-inner">
                <div class="banner-col banner-left-col">
                <div class="banner-title">
                <h1>Get your clothes cleaned & Delivered while you are studying</h1>
                <p>Sustainable & Eco-Friendly Laundry Collection Services</p>
                 <div class="search-box">
                    <input type="search" placeholder="enter your postcode" class="product-search">

                 
                 <!-- <form action=""> -->
                  
                 <a href="user_panel.php">

                    <button type="submit" class="icon">
                     <img src="assets/images/icons/search-ico.svg" alt="">
                 </button>
                 </a>

              
                    
                 <!-- </form> -->
                 </div><!-- /.search-box -->
                <p>We collect, clean & return at a time and location of your choice.</p>
            </div><!-- /.banner-title -->
                </div><!-- /.banner-col -->

                <div class="banner-col banner-right-col">
                        <div class="banner-figure">
                                <figure>
                                    <img src="assets/images/banner-img.png" alt="" class="banner-boy mb-hide">
                                </figure>
                        </div><!-- /.banner-figure -->
                </div><!-- /.banner-col -->

        </div><!-- /.page-banner-inner -->
    </div><!-- /.container -->
    </div><!-- /.page-banner -->
        </div><!-- /.home-page-banner -->

    <div class="work-section section-space">
        <div class="container-sm">
            <div class="work-section-inner">
                    <div class="section-title center-text">
                            <h4>How it works?</h4>
                    </div><!-- /.section-title -->

                <div class="flow-cols">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="flow-col box-shadow">
                              <figure>
                                <img src="assets/images/icons/home-ico1.svg" alt="">
                              </figure>
                              <figcaption>
                                <b>We collect</b>
                                <p>We collect your clothes from your premises on your selected date and time</p>
                              </figcaption>
                            </div><!-- /.flow-col -->
                        </div>

                        <div class="col-md-4">
                            <div class="flow-col box-shadow">
                              <figure>
                                <img src="assets/images/icons/home-ico2.svg" alt="">
                              </figure>
                              <figcaption>
                                <b>We wash</b>
                                <p>We clean your laundry in our state of the art machines and carefully iron them</p>
                              </figcaption>
                            </div><!-- /.flow-col -->
                        </div>


                        <div class="col-md-4">
                            <div class="flow-col box-shadow">
                              <figure>
                                <img src="assets/images/icons/home-ico3.svg" alt="">
                              </figure>
                              <figcaption>
                                <b>We deliver</b>
                                <p>We deliver your clothes in our Zero-emission delivery vehicles</p>
                              </figcaption>
                            </div><!-- /.flow-col -->
                        </div>

                    </div>
                </div><!-- /.flow-cols -->
            </div><!-- /.work-section-inner -->
        </div><!-- /.container-sm -->
    </div><!-- /.worksection -->


    <div class="packages-section bg-theme-lightblue">
            <div class="container">
                <div class="packages-section-inner">
                        <div class="row">
                            <div class="col-md-3">
                             <div class="title-col">
                             <div class="section-title">
                                        <h4>Famous laundry packages</h4>
                                        <p>Professional shoe cleaning and restoration services using our state of the art techniques</p>
                                </div>
                             </div>

                            </div>

                            <div class="col-md-3">
                                <div class="package-col box-shadow fig-col bg-white">
                                    <figure>
                                        <img src="assets/images/icons/home-ico4.svg" alt="">
                                    </figure>
                                    <figcaption>
                                        <b>Basic</b>
                                        <p class="fig-para">includes dry cleaning</p>
                                        <p class="price-tag">from £5</p>
                                    </figcaption>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="package-col box-shadow fig-col bg-white">
                                    <figure>
                                        <img src="assets/images/icons/home-ico5.svg" alt="">
                                    </figure>
                                    <figcaption>
                                        <b>Standard</b>
                                        <p class="fig-para">includes dry cleaning & ironing</p>
                                        <p class="price-tag">from £7.50</p>
                                    </figcaption>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="package-col box-shadow fig-col bg-white">
                                    <figure>
                                        <img src="assets/images/icons/home-ico6.svg" alt="">
                                    </figure>
                                    <figcaption>
                                        <b>Premium</b>
                                        <p class="fig-para">includes dry cleaning, ironing & fold</p>
                                        <p class="price-tag">from £10</p>
                                    </figcaption>
                                </div>
                            </div>
                        </div>
                </div><!-- /.packages-section-inner -->
            </div><!-- /.container -->
    </div><!-- /.packages-section -->



    <div class="reviews-section">
        <div class="container-md">
            <div class="reviews-section-inner">
                    <div class="section-title">
                        <h4>Excellent <br> Reviews</h4>
                        <img src="assets/images/icons/5-star.svg" alt="">
                    </div>
            </div> <!-- /.reviews-section-inner -->
        </div><!-- /.container -->
    </div><!-- /.reviews-section -->



    <div class="packages-section bg-theme-light">
            <div class="container">
                <div class="packages-section-inner">
                        <div class="row">
                            <div class="col-md-3">
                             <div class="package-col title-col">
                             <div class="section-title">
                                        <h4>Shoe care packages</h4>
                                        <p>Professional shoe cleaning and restoration services using our state of the art techniques</p>
                                </div>
                                <img src="assets/images/icons/green-star.svg" alt="" class="star-bg">

                             </div>

                            </div>

                            <div class="col-md-3">
                                <div class="package-col box-shadow fig-col bg-white">
                                    <figure>
                                        <img src="assets/images/icons/home-ico7.svg" alt="">
                                    </figure>
                                    <figcaption>
                                        <b>Basic</b>
                                        <p class="fig-para">All Brands Friendly</p>
                                        <p class="price-tag">from £5</p>
                                    </figcaption>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="package-col box-shadow fig-col bg-white">
                                    <figure>
                                        <img src="assets/images/icons/home-ico8.svg" alt="">
                                    </figure>
                                    <figcaption>
                                        <b>Standard</b>
                                        <p class="fig-para">Recommend For Designer Shoes</p>
                                        <p class="price-tag">from £7.50</p>
                                    </figcaption>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="package-col box-shadow fig-col bg-white">
                                    <figure>
                                        <img src="assets/images/icons/home-ico9.svg" alt="">
                                    </figure>
                                    <figcaption>
                                        <b>Premium</b>
                                        <p class="fig-para">The Ultimate Clean with Some Restoration Work</p>
                                        <p class="price-tag">from £10</p>
                                    </figcaption>
                                </div>
                            </div>
                        </div>
                </div><!-- /.packages-section-inner -->
            </div><!-- /.container -->
    </div><!-- /.packages-section -->
   

    <div class="price-banner-section">
            <div class="price-banner-inner">
            <div class="row">
                <div class="col-md-6">
                    <div class="price-col col-left">
                    <img src="assets/images/icons/best-price-banner.svg" alt="">
                    </div>
                </div>
                <div class="col-md-6">
                <div class="price-col col-right">
                        <div class="section-title">
                            <h4><small>Refer a friend</small>Get £5 off <span>Your second wash</span></h4>
                            <a href="#" class="theme-btn btn-green-theme">
                                <span>Book your rewash</span>
                                <img src="assets/images/icons/calendar-ico.svg" alt="">
                            </a>
                        </div><!-- /.section-title -->
                </div>
                </div>
            </div>
            </div><!-- /.price-banner-inner -->
    </div><!-- /.price-banner-section -->




    </main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>