import { useState } from "react";





const Header = ()=>{

    const [navitem, setNavitem] = useState([
        {
            home: "Home",
            about: "About",
            services: "Services",
            gallery: "Gallery",
            contacts: "Contacts"
        }
    ]);


    return(
       <div>
            {
                navitem.map((item, i)=>{
                    return(
                        <div className="hm-navbar">
                            <div className="container">
                            <div className="nav-inner">

                                <h1>{item.home}</h1>
                            <ul>
                                <li><a href="#">This is {i+ 1}<sup>th</sup> Item</a></li>
                                <li><a href="#">{item.about}</a></li>
                                <li><a href="#">{item.services}</a></li>
                                <li><a href="#">{item.gallery}</a></li>
                                <li><a href="#">{item.contacts}</a></li>
                            </ul>
                        </div>
                            </div>
                        </div>
                    )
                })
            }
       </div>
    )
}

export default Header;


