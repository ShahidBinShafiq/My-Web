<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no, user-scalable=no">

    <title>Site Space</title> 

    <!-- <link href="assets/images/favicon/apple-touch-icon.png" rel="apple-touch-icon" type="image/png" sizes="180x180">
    <link href="assets/images/favicon/favicon-32x32.png" rel="icon" type="image/png" sizes="32x32">
    <link href="assets/images/favicon/favicon-16x16.png" rel="icon" type="image/png" sizes="16x16">
    <link href="assets/images/favicon/manifest.json" rel="manifest">
    <link href="assets/images/favicon/favicon.ico" rel="shortcut icon"> -->

    <style>
        .site__wrapper {
            opacity: 0;
        }
    </style>

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/7.4.1/swiper-bundle.min.css"/>
        <link rel="stylesheet" href="assets/css/theme.css">

</head>

<body>

<div class="preload__wrap"></div>
       
<div class="site__wrapper">

<header class="header-wrapper" id="header-wrap">
    <!-- <canvas id="canvas"></canvas> -->
    <div class="container-lg">
        <div class="heare-wrapper-inner">
                <div class="header-inner">
                    <div class="social-media-links">
                        <ul>
                            <li>
                                <a class="social-link-item" href="#"> <i class="icon-linked-in"></i></a>
                            </li>
                            <li>
                                <a class="social-link-item" href="#"> <i class="icon-linked-in"></i></a>
                            </li>
                            <li>
                                <a class="social-link-item" href="#"> <i class="icon-twitter"></i></a>
                            </li>
                            <li>
                                <a class="social-link-item" href="#"> <i class="icon-facebook"></i></a>
                            </li>
                        </ul>
                    </div><!-- /.social-media-links -->


                    <div class="brand-logo" style="width:200px;">




<!-- Generator: Adobe Illustrator 24.0.1, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 120.1 47.7" style="enable-background:new 0 0 120.1 47.7;" xml:space="preserve">
<style type="text/css">
	.st0{fill:#CF6451;}
	.st1{fill:#2E2E2E;}
	.st2{fill:#4D95C1;}
	.st3{fill:none;stroke:url(#SVGID_1_);stroke-width:2;stroke-linecap:round;stroke-miterlimit:10;}
</style>
<g class="brand-logo-txt">
	<g>
		<path d="M9.7,18.1H1.5l-0.5,3.3h2.8v8.5h3.5v-8.5h2.8C10.1,21.4,9.7,18.1,9.7,18.1z"/>
	</g>
	<g>
		<path d="M18,18.1v4.1h-3.5v-4.1H11v11.8h3.5v-4.3H18v4.3h3.5V18.1H18z"/>
	</g>
	<g>
		<path d="M26.6,26.9v-1.4h3.3v-3h-3.3v-1.3h4.1l-0.4-3h-7.1v11.8h7.3l0.4-3C30.8,26.9,26.6,26.9,26.6,26.9z"/>
	</g>
	<g>
		<path d="M40.1,22.6l-0.7-0.2c-0.9-0.3-1.1-0.6-1.1-0.9s0.2-0.6,0.9-0.6c0.8,0,1.9,0.3,3.2,0.9l0.4-3.1c-1.3-0.5-2.4-0.8-3.5-0.8
			c-2.6,0-4.3,1.6-4.3,3.8c0,1.7,0.9,3,2.9,3.7l0.7,0.2c1,0.3,1.2,0.6,1.2,1c0,0.3-0.2,0.7-1,0.7c-1,0-2.2-0.4-3.6-1.3L34.8,29
			c1.1,0.6,2.5,1.2,4.1,1.2c3.1,0,4.3-2,4.3-3.9C43.2,24.8,42.4,23.3,40.1,22.6z"/>
	</g>
	<g>
		<path d="M44.6,18.1v11.8h3.5V18.1H44.6z"/>
	</g>
	<g>
		<path d="M57.7,18.1h-8.2l-0.4,3.3h2.8v8.5h3.5v-8.5h2.8L57.7,18.1z"/>
	</g>
	<g>
		<path d="M62.5,26.9v-1.4h3.3v-3h-3.3v-1.3h4.1l-0.4-3h-7.1v11.8h7.3l0.4-3C66.8,26.9,62.5,26.9,62.5,26.9z"/>
	</g>
	<g>
		<path d="M76,22.6l-0.7-0.2c-0.9-0.3-1.1-0.6-1.1-0.9s0.2-0.6,0.9-0.6c0.8,0,1.9,0.3,3.1,0.9l0.4-3.1c-1.3-0.5-2.4-0.8-3.5-0.8
			c-2.6,0-4.3,1.6-4.3,3.8c0,1.7,0.9,3,2.9,3.7l0.7,0.2c1,0.3,1.2,0.6,1.2,1c0,0.3-0.2,0.7-1,0.7c-1,0-2.2-0.4-3.6-1.3L70.7,29
			c1.1,0.6,2.5,1.2,4.1,1.2c3.1,0,4.3-2,4.3-3.9C79.1,24.8,78.3,23.3,76,22.6z"/>
	</g>
	<g>
		<path d="M84.9,18.1h-4.4v11.8H84v-3.1h0.9c2.7,0,4.6-1.8,4.6-4.4S87.6,18.1,84.9,18.1z M84.5,23.9H84v-2.8h0.5
			c0.9,0,1.6,0.6,1.6,1.4S85.4,23.9,84.5,23.9z"/>
	</g>
	<g>
		<path d="M99.5,25.6c-0.8,1-1.7,2-2.7,2.9l0.4,1.4h3.7C100.9,29.9,99.5,25.6,99.5,25.6z M97,18.1h-4.2L89,29.5
			c1.8-1.5,3.5-3.1,5-4.7l0.9-3.3l0.5,1.8c0.8-1,1.6-1.9,2.3-2.8L97,18.1z"/>
	</g>
	<g>
		<path d="M109.6,26.1c-0.9,0.5-1.7,0.7-2.4,0.7c-1.7,0-3-1.2-3-2.8s1.2-2.8,2.9-2.8c0.8,0,1.6,0.2,2.3,0.6l0.5-3.4
			c-0.8-0.3-1.8-0.6-2.8-0.6c-0.9,0-1.8,0.2-2.5,0.5l0,0c-0.3,0.5-0.6,1.1-1,1.7c-0.8,1.4-1.8,2.7-2.9,4.1c0.1,3.4,2.8,6,6.4,6
			c1,0,2.1-0.2,3.1-0.7L109.6,26.1L109.6,26.1z"/>
	</g>
	<g>
		<path d="M114.8,26.9v-1.4h3.3v-3h-3.3v-1.3h4.1l-0.4-3h-7.1v11.8h7.3l0.4-3L114.8,26.9L114.8,26.9z"/>
	</g>
</g>
<g>
	<g>
		<g id="Path_14401">
			<path class="st0" d="M62.9,10.5c0,1.7-1.4,3.1-3.1,3.1s-3.1-1.4-3.1-3.1c0-1.7,1.4-3.1,3.1-3.1l0,0C61.5,7.5,62.9,8.8,62.9,10.5"
				/>
		</g>
		<g id="Path_14402">
			<path class="st1" d="M67,7.3c0,0.6-0.5,1.1-1.1,1.1s-1.1-0.5-1.1-1s0.5-1.1,1.1-1.1S67,6.7,67,7.3L67,7.3"/>
		</g>
		<g id="Path_14403">
			<path class="st2" d="M64.2,2.8c0,0.9-0.7,1.6-1.6,1.6c-0.9,0-1.6-0.7-1.6-1.6c0-0.9,0.7-1.6,1.6-1.6l0,0
				C63.5,1.2,64.2,1.9,64.2,2.8"/>
		</g>
	</g>
	<linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="51.9664" y1="24.2802" x2="105.5644" y2="24.2802">
		<stop  offset="0" style="stop-color:#7164A3"/>
		<stop  offset="0.13" style="stop-color:#5885B7"/>
		<stop  offset="0.371" style="stop-color:#8C4C8D"/>
		<stop  offset="0.6226" style="stop-color:#C76158"/>
		<stop  offset="0.8636" style="stop-color:#EBCD2F"/>
		<stop  offset="1" style="stop-color:#EBCC2F"/>
	</linearGradient>
	<path class="st3" d="M71.4,15.1c0.7-0.5,1.4-1,2.1-1.5c1.7-1.2,3.5-2.4,5.4-3.5c2.4-1.4,4.8-2.7,7.3-3.8c2.5-1.1,5.2-2,8-2.4
		c3.2-0.5,8.2-0.4,9.9,3c1.5,3.1-0.2,7-1.7,9.7c-3.1,5.6-7.7,10.2-12.6,14.3c-5,4.1-10.5,7.6-16.3,10.3c-1,0.5-2,0.9-3,1.3
		c-3.2,1.3-6.5,2.3-9.9,2.2c-2.5,0-5.4-0.8-6.7-3.1c-1.4-2.5-0.5-5.5,0.6-7.9c0.5-1,1.1-2,1.7-3"/>
</g>
</svg>












                    </div>
                    <div class="hamburger">
                        <div class="hamburger-inner" id="nav-icon">
                            <span class="menu-line line-one"></span>
                            <span class="menu-line line-two"></span>
                            <span class="menu-line line-three"></span>
                        </div>
                    </div>
                </div>
         

        <div class="nav-bar" id="navBar">
           <div class="container-lg">
            <div class="nav-bar-inner">
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Courses</a></li>
                    <li><a href="#">Services</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
           </div>
        </div>
        </div><!-- /.heare-wrapper-inner -->
       

        </div><!-- /.container-md -->
    
</header>