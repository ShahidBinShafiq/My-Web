<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no, user-scalable=no">

    <title>Site Space</title> 

    <!-- <link href="assets/images/favicon/apple-touch-icon.png" rel="apple-touch-icon" type="image/png" sizes="180x180">
    <link href="assets/images/favicon/favicon-32x32.png" rel="icon" type="image/png" sizes="32x32">
    <link href="assets/images/favicon/favicon-16x16.png" rel="icon" type="image/png" sizes="16x16">
    <link href="assets/images/favicon/manifest.json" rel="manifest">
    <link href="assets/images/favicon/favicon.ico" rel="shortcut icon"> -->

    <style>
        .site__wrapper {
            opacity: 0;
        }
    </style>

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/7.4.1/swiper-bundle.min.css"/>
        <link rel="stylesheet" href="assets/css/theme.css">

</head>

<body>

<div class="preload__wrap"></div>
       
<div class="site__wrapper">

<header class="header-wrapper" id="header-wrap">
    <!-- <canvas id="canvas"></canvas> -->
    <div class="container-lg">
        <div class="heare-wrapper-inner">
                <div class="header-inner">
                    <div class="social-media-links">
                        <ul>
                            <li>
                                <a href="#"> <i class="icon-linked-in"></i></a>
                            </li>
                            <li>
                                <a href="#"> <i class="icon-linked-in"></i></a>
                            </li>
                            <li>
                                <a href="#"> <i class="icon-twitter"></i></a>
                            </li>
                            <li>
                                <a href="#"> <i class="icon-facebook"></i></a>
                            </li>
                        </ul>
                    </div><!-- /.social-media-links -->


                    <div class="brand-logo">
                       <img src="assets\images\brand-logo.svg" alt="" style="width:200px;">

                    </div>
                    <div class="hamburger">
                        <div class="hamburger-inner" id="nav-icon">
                            <span class="menu-line line-one"></span>
                            <span class="menu-line line-two"></span>
                            <span class="menu-line line-three"></span>
                        </div>
                    </div>
                </div>
         

        <div class="nav-bar" id="navBar">
           <div class="container-lg">
            <div class="nav-bar-inner">
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Courses</a></li>
                    <li><a href="#">Services</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
           </div>
        </div>
        </div><!-- /.heare-wrapper-inner -->
       

        </div><!-- /.container-md -->
    
</header>