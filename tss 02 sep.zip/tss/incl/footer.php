<footer class="footer__wrap aside_space">

<div class="footer-cols">
          
    </div><!-- /.footer-cols -->

   
</footer><!--/.footer__wrap-->

</div><!--/.site__wrapper-->

<script src="assets/js/jquery-3.5.1.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/dat-gui/0.6.2/dat.gui.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/7.4.1/swiper-bundle.min.js"></script>
<script src="assets/js/theme.js"></script>

<script>
        let headerWrap = document.getElementById('header-wrap');
        let nav_Bar = document.getElementById('navBar');
        let nav_icon = document.getElementById('nav-icon');

        nav_icon.addEventListener('click', function(){
            nav_Bar.classList.toggle('nav-toggle')
            nav_icon.classList.toggle('menu-icon-collapes')
            headerWrap.classList.toggle('header-wrap-toggle')       

        })



    </script>
</body>
</html>
