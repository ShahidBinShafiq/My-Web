$(document).ready(function(){

  $(".password-toggle").click(function () {

    let passbtn = $('.password-toggle').html();

if(passbtn == "Show"){
 $('.password-toggle').html("Hide");
 $('#loginPass').attr('type','text');

}else{
  $('.password-toggle').html("Show");
  $('#loginPass').attr('type','password');

}
});




$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
  var target = this.href.split('#');
  const parentElement = $('#crm-tabs-content .tab-pane.active')
 parentElement.find('a.active').removeClass('active')

  $('.nav a').filter('[href="#'+target[1]+'"]').tab('show');
})



  });

  $("#accordion").on("hide.bs.collapse show.bs.collapse", e => {
    $(e.target)
      .prev()
      .find("i:last-child")
      .toggleClass("icon-plus-circle icon-sort-down");
  });