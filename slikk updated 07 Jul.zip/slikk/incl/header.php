<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no, user-scalable=no">

    <title>Slikk</title> 

    <!-- <link href="assets/images/favicon/apple-touch-icon.png" rel="apple-touch-icon" type="image/png" sizes="180x180">
    <link href="assets/images/favicon/favicon-32x32.png" rel="icon" type="image/png" sizes="32x32">
    <link href="assets/images/favicon/favicon-16x16.png" rel="icon" type="image/png" sizes="16x16">
    <link href="assets/images/favicon/manifest.json" rel="manifest">
    <link href="assets/images/favicon/favicon.ico" rel="shortcut icon"> -->

    <style>
        .site__wrapper {
            opacity: 0;
        }
    </style>
    <link
  rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="assets/css/theme.css">

</head>

<body>

<div class="preload__wrap"></div>

<div class="site__wrapper">
<!-- <img src="./assets/images/home.png" alt="" class="home"> -->

    <header class="header__wrap">

    <div class="main-top-strip">
            <p>Book with SLIKK for 24h delivery and 5% off your first 2 orders.</p>
    </div><!-- /.main-top-strip -->

        <div class="hm-navbar">
        <div class="container">
            <div class="header__wrap-inner">
            <nav class="navbar navbar-expand-lg navbar-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">
            <img src="./assets/images/icons/brand-logo.svg" alt="">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span>
      <img src="./assets/images/icons/mobile-menu-icon.svg" alt="">
      </span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Packages</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="slikk.php">Why Slikk?</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Students</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="commercial.php">Commercial</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="#">Dashboard</a>
        </li>
      
      </ul>
    
    </div>
  </div>
</nav>

<div class="out-side-nav">
        <a href="login.php" class="theme-btn btn-black-theme"><span>Login</span> <img src="./assets/images/icons/user-ico.svg" alt=""></a>
</div><!-- /.out-side-nave -->
            </div><!-- /.header__wrap-inner -->
        </div><!-- /.container -->
        </div><!-- /.hm-navbar -->
<div class="header-cta-strip">
        <p> 
        <img src="./assets/images/icons/star.svg" alt="">
        5% student discount on all our packages
        <img src="./assets/images/icons/star.svg" alt="">
      </p>
        
</div><!-- /.header-cta-strip -->
    </header><!--/.header__wrap-->
