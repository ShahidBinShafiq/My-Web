import Headerstrip from "../header/Headerstrip"



const Contact = ()=> {
  return (
    <div className="site-contact">
        <div className="container">
            <div className="site-contact-inner">
            <Headerstrip/>
        <h1>This is Contact Page</h1>
            </div>
        </div>
    </div>
  )
}

export default Contact