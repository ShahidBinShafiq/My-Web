import Headerstrip from "../header/Headerstrip"




const Home = ()=> {
  return (
    <div className="site-home-page">
        <div className="container">
            <div className="site-home-page-inner">
                <Headerstrip/>
                <h1>This is Home Page</h1>
            </div>
        </div>
    </div>
  )
}

export default Home
