import Logo from "./Logo"
import Navbar from "./Navbar"



const Headerstrip = ()=> {
  return (
    <div className="header-strip">
        <div className="container">
            <div className="header-strip-inner">
           <Logo/>
           <Navbar/>

            </div>
        </div>
    </div>
  )
}

export default Headerstrip