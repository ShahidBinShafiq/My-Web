import { useState } from "react";
import { Link } from "react-router-dom";



const Navbar = ()=>{

const [navitem, setNavitem] = useState ([
    {
        home: "Home",
        contact: "Contact",
        services: "Services",
        gallery: "Gallery",
        blogs: "Blogs"
    }
])
 

    return(
        <div>
           {
            navitem.map((i, index)=>{
                return(
                    <div className="site-nav">
                        <ul>
                            <li>
                                <Link to="/">{i.home}</Link>
                            </li>
                            <li>
                            <Link to="/contact">{i.contact}</Link>
                            </li>
                            <li>
                            <Link to="/services">{i.services}</Link>
                            </li>
                            <li>
                            <Link to="/gallery">{i.gallery}</Link>
                            </li>
                            <li>
                            <Link to="/blogs">{i.blogs}</Link>
                            </li>
                        </ul>
                    </div>
                )
            })
           }
        </div>
    )
}


export default Navbar