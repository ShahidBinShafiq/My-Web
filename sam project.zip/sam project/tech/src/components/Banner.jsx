




const Banner = ()=> {
  return (
    <div>
      Banner
      </div>
  )
}

export default Banner