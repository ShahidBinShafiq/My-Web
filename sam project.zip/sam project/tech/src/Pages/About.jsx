import Header from "../components/Header"






const About =()=> {
  return (
    <div>
        <Header/>
        About
        </div>
  )
}

export default About