import Header from "../components/Header"






const Signin = ()=> {
  return (
    <div>
        <Header/>
        Signin</div>
  )
}

export default Signin