import Header from "../components/Header"





const Home = ()=> {
  return (
    <div className="page-wrapper">
        <Header/>
        This is Home Page
    </div>
  )
}

export default Home