function formValidation() {
  const submitButton = document.querySelector(".form-submit");
  submitButton.addEventListener("click", function () {
    validateFormonSubmit();
  });
  validateForm();
}
function inputValidate(target, input) {
  const parent = target.parentElement;
  const value = target.value;
  const inputClasses = Array.from(input.classList);
  const isRequired = inputClasses.find(function (cls) {
    return cls === "field-required";
  });
  if (isRequired) {
    if (value == "") {
      parent.classList.add("error");
    } else {
      parent.classList.remove("error");
    }
  }
}
function validateForm(params) {
  const formPod = document.querySelector(".form-pod");
  const inputs = formPod.getElementsByClassName("form-control");
  if (inputs) {
    const inputFields = Array.from(inputs);
    console.log({ inputs, inputFields });
    inputFields.forEach(function (input) {
      input.addEventListener("input", function (e) {
        inputValidate(e.target, input);
      });
      input.addEventListener("blur", function (e) {
        inputValidate(e.target, input);
      });
    });
  }
}
function validateFormonSubmit(params) {
  const formPod = document.querySelector(".form-pod");
  const inputs = formPod.getElementsByClassName("form-control");
  if (inputs) {
    const inputFields = Array.from(inputs);
    console.log({ inputs, inputFields });
    inputFields.forEach(function (input) {
      inputValidate(input, input);
    });
  }
}
formValidation();


 const getImageDimension =  (file => {
    return new Promise((resolve, reject) => {
    //   if (!attrAccept({ name: file.name, type: file.type }, 'image/*')) {
    //     return resolve(file);
    //   }
    //   if (attrAccept({ name: file.name, type: file.type }, 'audio/*')) {
    //     return resolve(file);
    //   }
  
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const image = new Image();
        image.src = event.target.result;
        image.onload = () => {
          Object.defineProperty(file, 'width', {
            value: image.width,
            writable: false,
          });
          Object.defineProperty(file, 'height', {
            value: image.height,
            writable: false,
          });
          console.log(file)
          resolve(file);
        };
        reader.onerror = (err) => reject(err);
      };
    });
  })
// upload cv or image


$('#upload-cv').change( function(e){
    console.log(e);
    const files = Array.from(e.target.files)
    files.forEach(function (file) {
        
        var fileType = file.type;
        var fileSize = file.size;
        var empty = '';
    
        if(fileType != 'image/png'
         && fileType != 'image/jpeg' 
         && fileType != 'application/msword'
         && fileType != 'application/pdf'
         && fileSize <= 5242880){
            $('#input-msg').addClass('error').html('Please choose a valid file');
            $('#upload-cv').val(empty);
            // $('#uploaded-image').hide();
        }else if(fileSize > 5242880){
            $('#input-msg').addClass('error').html('Maximum filesize should be less than 5mbs');
            $('#upload-cv').val(empty);
            // $('#uploaded-image').hide();
        }else{
            $('#input-msg').removeClass('error').addClass('success').html(file.name);
            // $('.container').add('img').attr('src', file.name);
              getImageDimension(file).then(data => {
               console.log(data)
    
               const img = document.createElement('img');
               img.setAttribute('src',  URL.createObjectURL(data));
               document.body.appendChild(img)
           })
        }
    })
});
